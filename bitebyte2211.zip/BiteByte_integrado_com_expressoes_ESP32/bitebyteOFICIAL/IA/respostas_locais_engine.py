"""
Motor de respostas locais do ChefBot.

Objetivo: responder NA HORA (sem Ollama, sem backend) tudo o que já é
conhecido pelo sistema, mesmo que a mensagem venha com erro de digitação
ou alongamento ("oii", "oiiii", "obrigadooo", "xicra", "tchaaau"...).

Cada resposta devolve também a EXPRESSÃO FACIAL que o BiteByte deve fazer
(FELIZ, TRISTE, SUSTO, APAIXONADO, BRAVO, NEUTRO, ERRO), usando o mesmo
contrato que o Ollama usa no marcador [[BITEBYTE_FACE:...]]. Como cada
variação de texto tem a sua própria expressão, o robô (tela e ESP32) não
faz sempre a mesma carinha mesmo quando a resposta é local.

Só usa a biblioteca padrão do Python.
"""

import random
import re
import unicodedata
from dataclasses import dataclass
from typing import Optional

EXPRESSOES_VALIDAS = {"NEUTRO", "FELIZ", "TRISTE", "BRAVO", "APAIXONADO", "ERRO", "SUSTO"}


@dataclass
class RespostaLocal:
    texto: str
    expressao: str
    origem: str      # "casual" | "conhecimento"
    chave: str       # intenção casual ou pergunta cadastrada que casou
    score: float = 1.0


# ============================================================
# NORMALIZAÇÃO TOLERANTE A ERROS
# ============================================================

# Abreviações de internet -> forma completa.
ALIASES = {
    "vc": "voce", "vcs": "voces", "ce": "voce", "tb": "tambem", "tbm": "tambem",
    "blz": "beleza", "vlw": "valeu", "vlww": "valeu", "obg": "obrigado",
    "brigado": "obrigado", "brigada": "obrigada", "obgd": "obrigado",
    "flw": "falou", "fui": "tchau", "xau": "tchau", "chau": "tchau",
    "pq": "porque", "q": "que", "eh": "e", "td": "tudo", "tdo": "tudo",
    "tds": "todos", "n": "nao", "ta": "esta", "to": "estou", "tá": "esta",
    "oie": "oi", "oiee": "oi", "ola": "oi", "olar": "oi", "alo": "oi",
    "hey": "oi", "hello": "oi", "hi": "oi", "eai": "e ai", "eae": "e ai",
    "bomdia": "bom dia", "boatarde": "boa tarde", "boanoite": "boa noite",
    "bdia": "bom dia", "btarde": "boa tarde", "bnoite": "boa noite",
    "msm": "mesmo", "mt": "muito", "mto": "muito", "oq": "o que", "cmo": "como",
    "qm": "quem", "qual": "qual",
}

# Palavras que só endereçam o bot ("oi chat", "ola chefbot"); são ignoradas.
ENDERECAMENTO = {
    "chat", "chefbot", "chefbote", "bitebyte", "bite", "byte", "bot", "chef",
    "robo", "ia", "amigo", "amigao", "amiga", "gente", "pessoal", "galera",
}

# Palavras sem valor para identificar uma pergunta de conhecimento.
STOP_CONHECIMENTO = {
    "o", "a", "os", "as", "um", "uma", "uns", "umas", "de", "do", "da", "dos", "das",
    "e", "que", "para", "pra", "pro", "por", "no", "na", "nos", "nas", "em", "se",
    "qual", "quais", "quanto", "quantos", "quanta", "quantas", "como", "quando",
    "onde", "porque", "quem", "eh", "ao", "aos", "me", "diga", "fale", "explique",
    "pode", "poderia", "voce", "favor", "ola", "oi", "ai", "tem", "ter", "ser",
}


def _sem_acentos(texto):
    texto = unicodedata.normalize("NFD", str(texto or "").lower())
    return "".join(c for c in texto if unicodedata.category(c) != "Mn")


def _compactar(token):
    """Colapsa letras repetidas: 'oii'/'oiii' -> 'oi', 'obrigadooo' -> 'obrigado'."""
    return re.sub(r"(.)\1+", r"\1", token)


def _tokens_brutos(texto):
    texto = _sem_acentos(texto)
    texto = re.sub(r"[^a-z0-9\s]", " ", texto)
    return texto.split()


def tokens_casuais(texto):
    """Tokens normalizados: sem acento, abreviações expandidas, letras repetidas colapsadas."""
    saida = []
    for token in _tokens_brutos(texto):
        # alias antes E depois de compactar ('oieee' -> 'oie' -> 'oi')
        for candidato in (token, _compactar(token)):
            if candidato in ALIASES:
                saida.extend(ALIASES[candidato].split())
                break
        else:
            saida.append(_compactar(token))
    return saida


_NOMES_DO_BOT = ("bitebyte", "chefbot", "chefbote")


def _e_enderecamento(token):
    """'chat', 'bitebyte' e também com erro: 'butebyte', 'chefbto'."""
    if token in ENDERECAMENTO:
        return True
    return len(token) >= 5 and any(tokens_parecidos(token, nome) for nome in _NOMES_DO_BOT)


def _sem_enderecamento(tokens):
    filtrados = [t for t in tokens if not _e_enderecamento(t)]
    return filtrados or tokens


def _limite_erros(tamanho):
    """Quantos erros de digitação aceitamos conforme o tamanho da palavra."""
    if tamanho <= 3:
        return 0
    if tamanho <= 7:
        return 1
    return 2


def _distancia(a, b, limite):
    """Damerau-Levenshtein (com transposição) com corte em `limite`."""
    if abs(len(a) - len(b)) > limite:
        return limite + 1
    anterior2 = None
    anterior = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        atual = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            custo = 0 if a[i - 1] == b[j - 1] else 1
            atual[j] = min(anterior[j] + 1, atual[j - 1] + 1, anterior[j - 1] + custo)
            if (
                anterior2 is not None and i > 1 and j > 1
                and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]
            ):
                atual[j] = min(atual[j], anterior2[j - 2] + 1)
        if min(atual) > limite:
            return limite + 1
        anterior2, anterior = anterior, atual
    return anterior[-1]


def tokens_parecidos(a, b):
    if a == b:
        return True
    limite = _limite_erros(min(len(a), len(b)))
    if limite == 0:
        return False
    return _distancia(a, b, limite) <= limite


# ============================================================
# CONVERSA CASUAL (INTENÇÕES) — cada variação tem a sua expressão
# ============================================================
# Formato: (texto, EXPRESSÃO)

INTENCOES_CASUAIS = [
    {
        "nome": "saudacao",
        "frases": ["oi", "oi oi", "e ai", "salve", "opa", "fala", "fala ai", "bom te ver", "oi tudo", "oi pessoal"],
        "abertura": ["👨‍🍳 Olá!", "😄 Oi!", "👋 Opa!"],
        "respostas": [
            ("👨‍🍳 Olá! Eu sou o ChefBot. Posso te ajudar com receitas, ingredientes, preparo e ideias para cozinhar.", "FELIZ"),
            ("😄 Oi! Que bom te ver por aqui! O que vamos cozinhar hoje?", "FELIZ"),
            ("👋 Opa, chegou na hora certa! Me conta: bate fome de quê?", "APAIXONADO"),
            ("👀 Oh! Apareceu alguém na cozinha! Oi! Em que posso te ajudar?", "SUSTO"),
            ("🍳 Oie! Tô com o fogão ligado e a curiosidade também. O que você quer preparar?", "FELIZ"),
            ("👨‍🍳 Olá, chef! Pronto para uma receita, uma dica ou uma ideia de prato?", "NEUTRO"),
        ],
    },
    {
        "nome": "bom_dia",
        "frases": ["bom dia", "bom dia pessoal", "bom diaa"],
        "abertura": ["☀️ Bom dia!"],
        "respostas": [
            ("☀️ Bom dia! O que vamos cozinhar hoje?", "FELIZ"),
            ("🥐 Bom dia! Já pensou no café da manhã? Posso sugerir algo gostoso.", "APAIXONADO"),
            ("🌞 Bom dia! A cozinha já está de pé. Qual é o plano de hoje?", "FELIZ"),
            ("☕ Bom dia! Ainda estou acordando, mas já dá pra pensar em receita. Vamos?", "NEUTRO"),
        ],
    },
    {
        "nome": "boa_tarde",
        "frases": ["boa tarde", "boa tarde pessoal"],
        "abertura": ["🌤️ Boa tarde!"],
        "respostas": [
            ("🌤️ Boa tarde! O que você gostaria de preparar?", "FELIZ"),
            ("🍝 Boa tarde! Já sabe o que vai ser o almoço ou o lanche?", "APAIXONADO"),
            ("😄 Boa tarde! Estou à disposição para qualquer dúvida de cozinha.", "FELIZ"),
            ("👨‍🍳 Boa tarde! Me diga o que tem na geladeira que eu ajudo.", "NEUTRO"),
        ],
    },
    {
        "nome": "boa_noite",
        "frases": ["boa noite", "boa noite pessoal"],
        "abertura": ["🌙 Boa noite!"],
        "respostas": [
            ("🌙 Boa noite! Quer uma receita ou alguma sugestão para hoje?", "FELIZ"),
            ("🍲 Boa noite! Que tal um jantar gostoso? Posso ajudar a escolher.", "APAIXONADO"),
            ("😴 Boa noite! Estou meio sonolento, mas ainda dá pra cozinhar um pouquinho. O que você precisa?", "NEUTRO"),
            ("✨ Boa noite! A cozinha nunca fecha pra quem tem fome. Vamos?", "FELIZ"),
        ],
    },
    {
        "nome": "como_vai",
        "frases": [
            "tudo bem", "tudo bom", "tudo certo", "tudo joia", "tudo tranquilo", "como vai", "como vai voce",
            "como voce esta", "como esta", "como voce vai", "tudo bem com voce", "e voce", "e com voce",
            "como voce ta", "oi tudo bem", "oi tudo bom", "e ai tudo bem", "e ai tudo bom", "e ai como vai",
            "como vai voce hoje", "como esta voce", "como foi seu dia", "como esta seu dia",
        ],
        "abertura": [],
        "respostas": [
            ("😊 Tudo ótimo por aqui! Estou pronto para cozinhar com você.", "FELIZ"),
            ("😄 Tudo bem sim, obrigado por perguntar! E você, já pensou no que vai comer?", "FELIZ"),
            ("🥰 Melhor agora que você apareceu! Vamos fazer algo gostoso?", "APAIXONADO"),
            ("🙂 Tranquilo por aqui, só esperando um pedido de receita. Qual vai ser?", "NEUTRO"),
        ],
    },
    {
        "nome": "agradecimento",
        "frases": [
            "obrigado", "obrigada", "muito obrigado", "muito obrigada", "valeu", "muito valeu",
            "valeu mesmo", "obrigado mesmo", "obrigadao", "agradeco", "grato", "grata",
            "obrigado chefbot", "mil obrigados", "valeu demais", "obrigado pela ajuda",
        ],
        "abertura": [],
        "respostas": [
            ("😊 Por nada! Quando precisar, é só chamar o ChefBot.", "FELIZ"),
            ("😄 De nada! Vamos cozinhar.", "FELIZ"),
            ("🥰 Imagina, foi um prazer ajudar! Bom apetite!", "APAIXONADO"),
            ("👨‍🍳 Sempre às ordens, chef! Se der dúvida no meio da receita, me chama.", "FELIZ"),
            ("🙌 Tamo junto na cozinha! Qualquer coisa, estou por aqui.", "FELIZ"),
        ],
    },
    {
        "nome": "despedida",
        "frases": [
            "tchau", "ate mais", "ate logo", "ate amanha", "ate breve", "ate a proxima", "falou",
            "tchau tchau", "adeus", "fui", "boa noite ate amanha",
        ],
        "abertura": [],
        "respostas": [
            ("👋 Até mais! Bom apetite!", "FELIZ"),
            ("👋 Até logo!", "FELIZ"),
            ("🥺 Já vai? Volte logo, tá? A cozinha fica vazia sem você.", "TRISTE"),
            ("🍽️ Tchau! Aproveite a refeição e me conte como ficou!", "APAIXONADO"),
            ("😌 Até a próxima receita! Estarei por aqui.", "NEUTRO"),
        ],
    },
    {
        "nome": "quem_e_voce",
        "frases": [
            "quem e voce", "quem voce e", "quem e", "qual seu nome", "qual e o seu nome", "qual o seu nome",
            "como voce se chama", "se apresente", "apresente se", "quem te criou", "voce e quem",
            "voce e um robo", "voce e o chefbot", "voce e real",
        ],
        "abertura": [],
        "respostas": [
            ("👨‍🍳 Eu sou o ChefBot, seu assistente virtual de culinária.", "FELIZ"),
            ("🤖 Sou o ChefBot, o gênio da cozinha do BiteByte! Receitas, técnicas e dicas são comigo.", "FELIZ"),
            ("🍳 Prazer! Sou o ChefBot. Meu negócio é te ajudar a cozinhar melhor.", "APAIXONADO"),
        ],
    },
    {
        "nome": "ajuda",
        "frases": [
            "o que voce faz", "o que voce sabe fazer", "o que voce pode fazer", "para que voce serve",
            "pra que voce serve", "no que voce pode ajudar", "como voce pode me ajudar", "me ajuda",
            "ajuda", "preciso de ajuda", "help", "o que voce sabe", "como funciona", "o que da pra fazer aqui",
        ],
        "abertura": [],
        "respostas": [
            ("🍳 Eu posso ajudar com receitas, ingredientes, técnicas de cozinha e sugestões de pratos.", "FELIZ"),
            ("👨‍🍳 Sei sugerir receitas, explicar técnicas, tirar dúvidas de medidas e tempos de preparo. É só pedir!", "FELIZ"),
            ("🥘 Posso sugerir pratos com o que você tem em casa, passar receitas passo a passo e explicar termos de cozinha.", "NEUTRO"),
        ],
    },
    {
        "nome": "elogio",
        "frases": [
            "legal", "massa", "top", "show", "perfeito", "otimo", "excelente", "muito bom", "muito legal",
            "gostei", "adorei", "amei", "incrivel", "parabens", "voce e demais", "que bom", "maravilhoso",
            "sensacional", "gostei muito", "muito show", "ficou otimo", "que legal", "boa", "mandou bem",
        ],
        "abertura": [],
        "respostas": [
            ("🥰 Que bom que gostou! Isso me deixa muito feliz.", "APAIXONADO"),
            ("😄 Uhul! Fico feliz em ajudar. Vamos para a próxima?", "FELIZ"),
            ("🤩 Nossa, assim eu fico até sem graça! Obrigado!", "APAIXONADO"),
            ("😊 Ótimo! Se quiser mais dicas ou outra receita, é só pedir.", "FELIZ"),
        ],
    },
    {
        "nome": "confirmacao",
        "frases": [
            "ok", "okay", "certo", "beleza", "entendi", "combinado", "fechado", "entendido", "ta bom",
            "esta bom", "ta certo", "esta certo", "sim entendi", "ok entendi", "ok obrigado", "pode ser",
            "blz", "tranquilo", "joia",
        ],
        "abertura": [],
        "respostas": [
            ("👍 Perfeito! Qualquer dúvida, é só chamar.", "FELIZ"),
            ("😌 Certo! Estou por aqui se precisar de mais alguma coisa.", "NEUTRO"),
            ("🙂 Combinado! Quer ver mais alguma receita?", "FELIZ"),
        ],
    },
    {
        "nome": "desculpa",
        "frases": ["desculpa", "desculpe", "foi mal", "perdao", "me perdoa", "sorry", "perdoa"],
        "abertura": [],
        "respostas": [
            ("😅 Sem problema nenhum! Vamos em frente. O que você precisa?", "FELIZ"),
            ("🙂 Tudo bem, acontece! Me diga como posso ajudar.", "NEUTRO"),
        ],
    },
]

RISADA = re.compile(r"^(k{2,}|(ha){2,}h?|(he){2,}h?|(hi){2,}h?|(rs){2,}|(ks)+k*|(sk)+s*)$")
RESPOSTAS_RISADA = [
    ("😄 Hahaha! Gostei da risada. Vamos cozinhar algo gostoso?", "FELIZ"),
    ("🤭 Rindo aqui também! O que você quer preparar?", "FELIZ"),
    ("😂 Boa! Quando quiser, me conta qual receita vai ser.", "SUSTO"),
]

# ============================================================
# EXPRESSÃO PARA RESPOSTAS DE CONHECIMENTO / FORA DO ESCOPO
# ============================================================

EXPRESSOES_CONHECIMENTO_PADRAO = ["FELIZ", "NEUTRO"]
EXPRESSOES_POR_EMOJI = {
    "🤨": ["BRAVO", "NEUTRO"], "🙄": ["BRAVO", "NEUTRO"], "😒": ["BRAVO"],
    "🚨": ["SUSTO"], "💀": ["SUSTO"], "🤡": ["SUSTO", "BRAVO"], "👀": ["SUSTO"],
    "😕": ["TRISTE"], "😢": ["TRISTE"], "🥲": ["TRISTE"], "😞": ["TRISTE"],
    "😌": ["NEUTRO"], "🙃": ["NEUTRO", "FELIZ"], "💅": ["NEUTRO", "BRAVO"],
    "😊": ["FELIZ"], "😄": ["FELIZ"], "🥰": ["APAIXONADO"], "😍": ["APAIXONADO"],
}


def expressao_por_emoji(texto, padrao=None, aleatorio=random):
    """Escolhe a expressão pelo emoji inicial da resposta; sem emoji conhecido usa `padrao`."""
    inicio = str(texto or "").strip()[:4]
    for emoji, opcoes in EXPRESSOES_POR_EMOJI.items():
        if emoji in inicio:
            return aleatorio.choice(opcoes)
    if padrao:
        return aleatorio.choice(padrao) if isinstance(padrao, (list, tuple)) else padrao
    return None


# ============================================================
# MEMÓRIA CURTA PARA NÃO REPETIR A MESMA VARIAÇÃO
# ============================================================

_ultimas_variacoes = {}
_LIMITE_MEMORIA = 2000


def _escolher_variacao(chave_memoria, variacoes, aleatorio=random):
    if len(variacoes) == 1:
        return variacoes[0]
    ultimo = _ultimas_variacoes.get(chave_memoria)
    indices = [i for i in range(len(variacoes)) if i != ultimo]
    escolhido = aleatorio.choice(indices)
    if len(_ultimas_variacoes) >= _LIMITE_MEMORIA:
        _ultimas_variacoes.clear()
    _ultimas_variacoes[chave_memoria] = escolhido
    return variacoes[escolhido]


def _sem_emoji_inicial(texto):
    return re.sub(r"^[^\wÀ-ÿ]+", "", texto).strip()


# ============================================================
# CASAMENTO CASUAL
# ============================================================

def _frase_casa(tokens_msg, frase):
    tokens_frase = tokens_casuais(frase)
    if len(tokens_msg) != len(tokens_frase):
        return False
    return all(tokens_parecidos(m, f) for m, f in zip(tokens_msg, tokens_frase))


def _intencao_casual(tokens):
    for intencao in INTENCOES_CASUAIS:
        if any(_frase_casa(tokens, frase) for frase in intencao["frases"]):
            return intencao
    return None


def _por_nome(nome):
    return next(i for i in INTENCOES_CASUAIS if i["nome"] == nome)


def encontrar_casual(mensagem, chave_usuario="", aleatorio=random):
    """Saudação, agradecimento, despedida etc. com tolerância a erros."""
    bruto = _sem_acentos(mensagem)
    sem_espacos = re.sub(r"[^a-z]", "", bruto)

    if sem_espacos and len(bruto.split()) <= 3 and RISADA.match(sem_espacos):
        texto, face = _escolher_variacao((chave_usuario, "risada"), RESPOSTAS_RISADA, aleatorio)
        return RespostaLocal(texto, face, "casual", "risada")

    tokens = _sem_enderecamento(tokens_casuais(mensagem))
    if not tokens or len(tokens) > 6:
        return None

    intencao = _intencao_casual(tokens)

    # Combinação: "bom dia, tudo bem?" / "oi, tudo bom?" -> cumprimento + como vai
    if not intencao and len(tokens) >= 3:
        saudacoes = ("saudacao", "bom_dia", "boa_tarde", "boa_noite")
        for corte in range(1, len(tokens)):
            esq, dir_ = tokens[:corte], tokens[corte:]
            a, b = _intencao_casual(esq), _intencao_casual(dir_)
            if a and b and a["nome"] in saudacoes and b["nome"] == "como_vai":
                abertura = aleatorio.choice(a["abertura"])
                texto, face = _escolher_variacao(
                    (chave_usuario, "como_vai"), b["respostas"], aleatorio
                )
                return RespostaLocal(
                    f"{abertura} {_sem_emoji_inicial(texto)}", face, "casual",
                    f"{a['nome']}+como_vai",
                )

    if not intencao:
        return None

    texto, face = _escolher_variacao(
        (chave_usuario, intencao["nome"]), intencao["respostas"], aleatorio
    )
    return RespostaLocal(texto, face, "casual", intencao["nome"])


# ============================================================
# CASAMENTO DE CONHECIMENTO (respostas_locais.json)
# ============================================================

def _tokens_conteudo(texto):
    return [
        t for t in tokens_casuais(texto)
        if t not in STOP_CONHECIMENTO and t not in ENDERECAMENTO and len(t) > 1
    ]


def _pontuar(tokens_chave, tokens_msg):
    """Retorna score 0-1 ou 0 se a mensagem não for a mesma pergunta."""
    if not tokens_chave:
        return 0.0

    nao_usados = list(tokens_msg)
    achados = 0
    for tk in tokens_chave:
        for tm in nao_usados:
            if tokens_parecidos(tk, tm):
                nao_usados.remove(tm)
                achados += 1
                break

    cobertura = achados / len(tokens_chave)
    extras = len(nao_usados)

    # Todas as palavras que definem a pergunta precisam aparecer. Se a chave tem
    # muitas palavras, tolera uma ausente (a pergunta continua igual).
    if len(tokens_chave) >= 6:
        if cobertura < 0.83:
            return 0.0
    elif cobertura < 1.0:
        return 0.0

    # Chave de 1 palavra só casa se a mensagem for praticamente só ela
    # ("maillard"), para não responder "como evitar maillard" com a definição.
    if len(tokens_chave) == 1 and extras > 0:
        return 0.0
    if extras > 2:
        return 0.0

    return cobertura - 0.08 * extras


def _normalizar_entrada(valor):
    """Aceita string simples ou objeto {resposta|respostas, expressao, alias}."""
    if isinstance(valor, str):
        return {"respostas": [valor], "expressao": None, "alias": []}
    if isinstance(valor, dict):
        respostas = valor.get("respostas") or valor.get("variacoes")
        if not respostas and valor.get("resposta"):
            respostas = [valor["resposta"]]
        if isinstance(respostas, str):
            respostas = [respostas]
        if not respostas:
            return None
        expressao = valor.get("expressao") or valor.get("expressoes")
        alias = valor.get("alias") or valor.get("sinonimos") or []
        return {"respostas": list(respostas), "expressao": expressao, "alias": list(alias)}
    return None


def _expressao_da_entrada(entrada, texto, aleatorio):
    configurada = entrada["expressao"]
    if isinstance(configurada, str):
        configurada = [configurada]
    if configurada:
        validas = [e.upper() for e in configurada if str(e).upper() in EXPRESSOES_VALIDAS]
        if validas:
            return aleatorio.choice(validas)
    return aleatorio.choice(EXPRESSOES_CONHECIMENTO_PADRAO)


class BaseDeConhecimento:
    """Pré-processa o JSON uma vez para a busca ser instantânea."""

    def __init__(self, dados):
        self.itens = []
        if isinstance(dados, dict):
            for pergunta, valor in dados.items():
                entrada = _normalizar_entrada(valor)
                if not entrada:
                    continue
                for frase in [pergunta, *entrada["alias"]]:
                    tokens = _tokens_conteudo(frase)
                    if tokens:
                        self.itens.append((pergunta, tokens, entrada))

    def buscar(self, mensagem, chave_usuario="", aleatorio=random):
        tokens_msg = _tokens_conteudo(mensagem)
        if not tokens_msg or len(tokens_msg) > 12:
            return None

        melhor = None
        melhor_score = 0.0
        for pergunta, tokens_chave, entrada in self.itens:
            score = _pontuar(tokens_chave, tokens_msg)
            if score > melhor_score:
                melhor, melhor_score = (pergunta, entrada), score

        if not melhor:
            return None

        pergunta, entrada = melhor
        texto = _escolher_variacao((chave_usuario, "kb:" + pergunta), entrada["respostas"], aleatorio)
        face = _expressao_da_entrada(entrada, texto, aleatorio)
        return RespostaLocal(texto, face, "conhecimento", pergunta, melhor_score)


# ============================================================
# API PÚBLICA
# ============================================================

def responder_local(mensagem, base, chave_usuario="", aleatorio=random) -> Optional[RespostaLocal]:
    """Casual primeiro (mais barato e mais comum), depois conhecimento local."""
    resposta = encontrar_casual(mensagem, chave_usuario, aleatorio)
    if resposta:
        return resposta
    if base is not None:
        return base.buscar(mensagem, chave_usuario, aleatorio)
    return None