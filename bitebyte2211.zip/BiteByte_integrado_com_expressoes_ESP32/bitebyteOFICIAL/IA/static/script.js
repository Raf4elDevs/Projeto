// ======================================================
// CHEFBOT - script da página de conversa
// ------------------------------------------------------
// - Histórico guardado em sessionStorage: permite rolar
//   a conversa e sobrevive a recarregar a página, mas é
//   apagado quando a aba/site é fechado.
// - Logo sempre retorna à página inicial do BiteByte.
// - Perfil abre a página de perfil do site.
// ======================================================

const CHAVE_HISTORICO = "chefbotHistorico:";
const SITE_PADRAO = "http://localhost:3000/html/index.html";

const MENSAGEM_BOAS_VINDAS =
    "Olá! Eu sou o **Chef IA** do BiteByte 🍳\n\n" +
    "Me diga o que você tem na geladeira ou o que quer cozinhar, " +
    "e eu te ajudo com receitas e dicas.";

let historico = [];


// ======================================================
// UTILITÁRIOS
// ======================================================

function emailAtual() {
    const campo = document.getElementById("email");
    return (campo?.value || localStorage.getItem("usuarioLogado") ||
        localStorage.getItem("emailUsuario") || "visitante@bitebyte.local").trim().toLowerCase();
}


function rolarParaFim() {
    const chat = document.getElementById("chat");
    chat.scrollTop = chat.scrollHeight;
}


function urlHttpValida(url) {
    try {
        const u = new URL(url);
        return u.protocol === "http:" || u.protocol === "https:";
    } catch (e) {
        return false;
    }
}


// ======================================================
// HISTÓRICO (sessionStorage)
// ======================================================

function carregarHistorico() {
    try {
        const salvo = sessionStorage.getItem(
            CHAVE_HISTORICO + emailAtual()
        );
        historico = salvo ? JSON.parse(salvo) : [];
    } catch (e) {
        historico = [];
    }
}


function salvarHistorico() {
    try {
        sessionStorage.setItem(
            CHAVE_HISTORICO + emailAtual(),
            JSON.stringify(historico)
        );
    } catch (e) {
        console.error("Não foi possível salvar o histórico:", e);
    }
}


// ======================================================
// RENDERIZAÇÃO
// ======================================================

function criarMensagemUsuario(texto) {
    const div = document.createElement("div");
    div.className = "user-message";
    div.textContent = texto;
    return div;
}


function criarMensagemBot(markdown) {
    const div = document.createElement("div");
    div.className = "bot-message";
    div.innerHTML =
        "<strong>ChefBot:</strong> " +
        (markdown ? marked.parse(markdown) : "");
    return div;
}


function renderizarHistorico() {
    const chat = document.getElementById("chat");
    chat.innerHTML = "";

    chat.appendChild(criarMensagemBot(MENSAGEM_BOAS_VINDAS));

    for (const msg of historico) {
        chat.appendChild(
            msg.role === "user"
                ? criarMensagemUsuario(msg.text)
                : criarMensagemBot(msg.text)
        );
    }

    // rola direto para a última mensagem (sem animação)
    chat.style.scrollBehavior = "auto";
    rolarParaFim();
    chat.style.scrollBehavior = "";
}


// ======================================================
// INICIALIZAÇÃO
// ======================================================

document.addEventListener("DOMContentLoaded", function () {

    const params = new URLSearchParams(window.location.search);


    // ---------- IDENTIFICAÇÃO AUTOMÁTICA ----------
    const emailInput = document.getElementById("email");
    const emailSalvo = params.get("email") || localStorage.getItem("usuarioLogado") ||
        localStorage.getItem("emailUsuario") || "visitante@bitebyte.local";
    emailInput.value = emailSalvo;
    // Não exibe nem pede e-mail. A identificação vem da navegação do site.


    // ---------- NÍVEL (mantido internamente, sem seletor visual) ----------
    const nivelURL = params.get("nivel");
    const nivelInterno = document.getElementById("nivel");
    const nivelSalvo = localStorage.getItem("usuarioHabilidade") || localStorage.getItem("chefbotNivel");
    const niveisValidos = ["iniciante", "intermediario", "avancado"];
    if (niveisValidos.includes(nivelURL)) {
        nivelInterno.value = nivelURL;
        localStorage.setItem("chefbotNivel", nivelURL);
    } else if (niveisValidos.includes(nivelSalvo)) nivelInterno.value = nivelSalvo;

    // ---------- NAVEGAÇÃO ----------
    // URLs explícitas para que funcionem mesmo com o chat no Flask (porta 5000)
    // e o site principal no Node (porta 3000).
    const host = window.location.hostname || "localhost";
    const destinoHome = `http://${host}:3000/html/index.html`;
    const destinoPerfil = `http://${host}:3000/html/perfil.html`;
    const logo = document.getElementById("logo-home");
    if (logo) logo.href = destinoHome;
    const perfilLink = document.getElementById("perfil-link");
    if (perfilLink) perfilLink.href = destinoPerfil;


    // ---------- HISTÓRICO ----------
    carregarHistorico();
    renderizarHistorico();


    // ---------- ENTER ----------
    document.getElementById("mensagem").addEventListener(
        "keypress",
        function (event) {
            if (event.key === "Enter") {
                event.preventDefault();
                enviar();
            }
        }
    );

});


// ======================================================

// ======================================================
// BITEBYTE VIRTUAL: expressões oficiais do SVG de page.zip
// ======================================================
const robotExpressions = [
  'neutro','neutro2','feliz','triste','bravo','apaixonado',
  'erro','susto','sonolento','dormindo','piscada'
];
const robotExpressionLabels = {
  neutro:'Neutro', neutro2:'Atento', feliz:'Feliz', triste:'Triste',
  bravo:'Bravo', apaixonado:'Apaixonado', erro:'Erro', susto:'Surpreso',
  sonolento:'Sonolento', dormindo:'Dormindo', piscada:'Piscada'
};
// Correspondência exata com processarComando() no firmware da ESP32.
// neutro2 é apenas o estado visual de atenção; na placa ele equivale a NEUTRO.
// piscada é animada localmente pelo firmware, portanto não gera comando serial.
const robotSerialCommands = {
  neutro:'NEUTRO', neutro2:'NEUTRO', feliz:'FELIZ', triste:'TRISTE',
  bravo:'BRAVO', apaixonado:'APAIXONADO', erro:'ERRO', susto:'SUSTO',
  sonolento:'SONOLENTO', dormindo:'DORMINDO'
};
const robotFacesFromAI = {
  NEUTRO:'neutro', FELIZ:'feliz', TRISTE:'triste', BRAVO:'bravo',
  APAIXONADO:'apaixonado', ERRO:'erro', SUSTO:'susto'
};
let robotBlinkTimer = null;
let robotBlinkInterval = null;
let robotIdleTimers = [];
let robotCurrentExpression = 'neutro';
let espPort = null;
let espWriter = null;

async function conectarESP32() {
  const status = document.getElementById('esp-status');
  const button = document.getElementById('esp-connect');
  if (!('serial' in navigator)) {
    status.textContent = 'Seu navegador não oferece Web Serial. Use Chrome ou Edge em localhost/HTTPS.';
    return;
  }
  try {
    espPort = await navigator.serial.requestPort();
    await espPort.open({ baudRate: 115200 });
    espWriter = espPort.writable.getWriter();
    status.textContent = 'ESP32 conectada — sincronizando expressões';
    button.innerHTML = '<i class="fas fa-check-circle"></i> ESP32 conectada';
    button.classList.add('connected');
    // A abertura da porta pode reiniciar a ESP32; aguarda o firmware iniciar.
    await new Promise(resolve => setTimeout(resolve, 1500));
    enviarExpressaoESP32(robotCurrentExpression);
    status.textContent = 'ESP32 conectada — expressões sincronizadas';
  } catch (error) {
    status.textContent = error?.name === 'NotFoundError' ? 'Conexão cancelada. Modo virtual continua ativo.' : 'Não foi possível conectar. Modo virtual continua ativo.';
    console.warn('Conexão ESP32:', error);
    espWriter = null;
  }
}

function enviarExpressaoESP32(key) {
  if (!espWriter) return;
  const comando = robotSerialCommands[key];
  if (!comando) return;
  const bytes = new TextEncoder().encode(`${comando}\n`);
  espWriter.write(bytes).catch(error => {
    console.warn('Falha ao enviar expressão ao ESP32:', error);
    const status = document.getElementById('esp-status');
    if (status) status.textContent = 'ESP32 desconectada — modo virtual';
    espWriter = null;
  });
}

function aplicarExpressaoDaIA(expressao) {
  const key = robotFacesFromAI[String(expressao || '').trim().toUpperCase()];
  if (key) {
    resetarInatividadeRobot();
    setExpression(key);
  }
}

// Espelha os tempos do firmware: sonolento aos 4min30 e dormindo aos 5min.
function resetarInatividadeRobot() {
  robotIdleTimers.forEach(timer => clearTimeout(timer));
  robotIdleTimers = [
    setTimeout(() => setExpression('sonolento'), 270000),
    setTimeout(() => setExpression('dormindo'), 300000)
  ];
}

function setExpression(key) {
  if (!robotExpressions.includes(key)) return;
  if (robotBlinkTimer) { clearTimeout(robotBlinkTimer); robotBlinkTimer = null; }
  robotCurrentExpression = key;
  robotExpressions.forEach(expr => {
    const layer = document.getElementById('expr-' + expr);
    if (layer) {
      // .hidden usa display:none!important; portanto controlamos a classe.
      layer.classList.toggle('hidden', expr !== key);
      layer.style.display = '';
    }
  });
  const badge = document.getElementById('robot-status-badge');
  if (badge) {
    badge.textContent = robotExpressionLabels[key];
    const isError = key === 'erro';
    const isHeart = key === 'apaixonado';
    badge.style.background = isError ? '#fee2e2' : isHeart ? '#fce7f3' : '#e0f2fe';
    badge.style.color = isError ? '#dc2626' : isHeart ? '#be185d' : '#0284c7';
    badge.style.borderColor = isError ? '#fecaca' : isHeart ? '#fbcfe8' : '#bae6fd';
  }
  const sleepBubble = document.getElementById('sleep-bubble');
  if (sleepBubble) sleepBubble.classList.toggle('hidden', !['sonolento','dormindo'].includes(key));
  const gaze = document.getElementById('eyes-gaze-group');
  if (gaze) gaze.classList.toggle('neutral-gaze', key === 'neutro');
  const head = document.getElementById('robot-head');
  if (head) {
    head.style.transform = ({feliz:'rotate(-3deg)',sonolento:'rotate(2deg)',dormindo:'rotate(3deg)',triste:'rotate(-3deg)'})[key] || 'rotate(0deg)';
    if (key === 'erro') { head.classList.remove('error-shake'); void head.offsetWidth; head.classList.add('error-shake'); }
  }
  const led = document.getElementById('base-led');
  if (led) {
    const ledColor = key === 'erro' ? '#ff2a2a' : key === 'apaixonado' ? '#f472b6' : key === 'bravo' ? '#fb923c' : key === 'dormindo' ? '#075985' : '#2bb3ff';
    led.style.background = ledColor;
    led.style.boxShadow = key === 'dormindo' ? 'none' : `0 0 8px ${ledColor}`;
  }
  enviarExpressaoESP32(key);
  const caption = document.getElementById('robot-caption');
  if (caption) caption.textContent = ({
    neutro:'Estou pronto para conversar!', neutro2:'Estou pensando na sua mensagem…',
    feliz:'Que bom! Vamos nessa 😊', triste:'Poxa, vamos resolver isso.',
    bravo:'Isso merece atenção. Vamos resolver!', apaixonado:'Essa receita me conquistou! 💗',
    susto:'Uau! Que surpresa!', sonolento:'Um pouquinho cansado…',
    dormindo:'Zzz…', erro:'Ops! Algo deu errado.', piscada:'* piscadinha *'
  })[key];
  if (key === 'piscada') robotBlinkTimer = setTimeout(() => setExpression('neutro'), 650);
  if (key === 'susto') robotBlinkTimer = setTimeout(() => {
    if (robotCurrentExpression === 'susto') setExpression('neutro');
  }, 1000);
}
function blinkRobot(duration=220) {
  if (robotBlinkTimer || !['neutro','neutro2','feliz'].includes(robotCurrentExpression)) return;
  const previous = robotCurrentExpression;
  const gaze = document.getElementById('eyes-gaze-group');
  if (gaze) gaze.classList.remove('neutral-gaze');
  robotExpressions.forEach(expr => {
    const layer=document.getElementById('expr-'+expr);
    if (layer) {
      layer.classList.toggle('hidden', expr !== 'piscada');
      layer.style.display = '';
    }
  });
  // O firmware da ESP32 controla as piscadas independentemente.
  robotBlinkTimer=setTimeout(() => {
    robotBlinkTimer=null;
    if (robotCurrentExpression===previous) setExpression(previous);
  },duration);
}
function expressForConversation(userText, responseText, failed=false, final=false) {
  if (failed) return setExpression('erro');
  const text=(String(userText||'')+' '+String(responseText||'')).toLowerCase();
  const normalized = text.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  // Expressões empáticas têm prioridade sobre expressões positivas.
  if (/(sinto muito|lamento|que pena|nao deu certo|nao consegui|falha|erro|problema|estrag|queimou|perdeu)/.test(normalized)) return setExpression('triste');
  if (/(obrigad|valeu|amei|perfeito|adorei|legal|muito bom|excelente|😊|😁|😄|😂|❤|❤)/.test(text)) return setExpression('feliz');
  if (/(bom dia|boa tarde|boa noite|ola|oi!|bem-vind|vamos la|vamos nessa|com prazer|ficou delicioso)/.test(normalized)) return setExpression('feliz');
  if (/(receita|ingrediente|como fazer|preparo|cozin|sugest|opcao|dica|explica|passo|temper|massa|bolo|sopa|quantidade)/.test(normalized)) return setExpression(final ? 'feliz' : 'neutro2');
  return setExpression(final ? 'neutro' : 'neutro2');
}

document.addEventListener('DOMContentLoaded', () => {
  setExpression('neutro');
  resetarInatividadeRobot();
  robotBlinkInterval=setInterval(()=>blinkRobot(220),4300);
});

// ENVIAR MENSAGEM
// ======================================================

async function enviar() {

    let inputMensagem = document.getElementById("mensagem");
    let nivelSelect = document.getElementById("nivel");
    let mensagem = inputMensagem.value.trim();
    let nivel = nivelSelect.value || "iniciante";
    let email = emailAtual();
    document.getElementById("email").value = email;

    // ---------- VALIDAR MENSAGEM ----------
    if (mensagem === "") {
        return;
    }


    // ---------- SALVAR EMAIL ----------
    localStorage.setItem("emailUsuario", email);


    let chat = document.getElementById("chat");
    setExpression("neutro2");
    resetarInatividadeRobot();


    // ---------- MENSAGEM DO USUÁRIO ----------
    chat.appendChild(criarMensagemUsuario(mensagem));

    historico.push({ role: "user", text: mensagem });
    salvarHistorico();

    inputMensagem.value = "";


    // ---------- RESPOSTA DO CHEFBOT ----------
    let respostaDiv = criarMensagemBot("");
    chat.appendChild(respostaDiv);
    rolarParaFim();

    let textoFinal = "";
    let textoErro = "";
    let recebeuExpressaoDaIA = false;


    try {

        // ---------- ENVIAR PARA FLASK ----------
        let response = await fetch("/chat", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                email: email,
                mensagem: mensagem,
                nivel: nivel
            })

        });


        if (!response.ok) {
            throw new Error("Erro HTTP: " + response.status);
        }


        // ---------- STREAM ----------
        const reader = response.body.getReader();
        const decoder = new TextDecoder("utf-8");

        let buffer = "";

        while (true) {

            const { done, value } = await reader.read();

            if (done) {
                break;
            }

            buffer += decoder.decode(value, { stream: true });


            // separar eventos SSE
            let linhas = buffer.split("\n\n");
            buffer = linhas.pop();


            for (let linha of linhas) {

                linha = linha.trim();

                if (!linha.startsWith("data: ")) {
                    continue;
                }

                try {

                    let dados = JSON.parse(linha.substring(6));


                    // Expressão escolhida pela IA (ou pelo fallback do backend).
                    if (dados.expressao) {
                        aplicarExpressaoDaIA(dados.expressao);
                        recebeuExpressaoDaIA = true;
                    }

                    // erro do Flask
                    if (dados.error) {

                        textoErro = "❌ " + dados.error;
                        setExpression('erro');
                        recebeuExpressaoDaIA = true;

                        respostaDiv.innerHTML =
                            "<strong>ChefBot:</strong> " + textoErro;

                        continue;

                    }


                    // token
                    if (dados.token) {

                        textoFinal += dados.token;

                        respostaDiv.innerHTML =
                            "<strong>ChefBot:</strong> " +
                            marked.parse(textoFinal);

                        rolarParaFim();

                    }

                }
                catch (erroJSON) {

                    console.error(
                        "Erro ao interpretar JSON:",
                        erroJSON
                    );

                }

            }

        }

    }
    catch (erro) {

        textoErro = "❌ Erro ao conectar com a IA.";
        setExpression('erro');
        recebeuExpressaoDaIA = true;

        respostaDiv.innerHTML =
            "<strong>ChefBot:</strong> " + textoErro;

        console.error("Erro:", erro);

    }


    // Fallback para respostas de servidor antigas que não enviem metadado facial.
    if (!recebeuExpressaoDaIA) {
      expressForConversation(mensagem, textoFinal, !!textoErro, true);
    }

    // ---------- GUARDAR RESPOSTA NO HISTÓRICO ----------
    const textoParaSalvar = textoFinal || textoErro;

    if (textoParaSalvar) {
        historico.push({ role: "bot", text: textoParaSalvar });
        salvarHistorico();
    }

}
