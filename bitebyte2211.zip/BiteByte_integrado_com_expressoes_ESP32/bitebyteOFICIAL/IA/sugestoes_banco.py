"""
Sugestões inteligentes a partir das receitas do banco do BiteByte.

Entende pedidos como:
  - "quero algo doce"                                   -> categoria doces
  - "receita com ovos, farinha e leite sendo algo doce" -> categoria + ingredientes
  - "o que posso fazer com frango e batata?"            -> só ingredientes
  - "algo salgado e rápido, até 30 minutos"             -> exclui doces + tempo
  - "e coisas fritas?" / "mais gelado"                  -> REFINA o pedido anterior

Funções puras (sem Flask, sem rede): o app.py busca as receitas no Spring Boot
e usa estas funções para interpretar o pedido e ranquear os resultados.
"""

import copy
import random
import re
import unicodedata
from dataclasses import dataclass, field
from typing import List, Optional

from respostas_locais_engine import tokens_parecidos


# ============================================================
# CATEGORIAS (iguais às do cadastro: massas, doces, fitness, sopas,
# vegetarianas, carnes)
# ============================================================

CATEGORIAS = {
    "doces": {"emoji": "🍰", "rotulo": "doces",
              "palavras": {"doce", "sobremesa", "docinho", "confeitaria", "adocicado", "doceria"}},
    "massas": {"emoji": "🍝", "rotulo": "massas",
               "palavras": {"massa", "macarrao", "espaguete", "talharim"}},
    "fitness": {"emoji": "🥗", "rotulo": "fitness",
                "palavras": {"fitness", "saudavel", "light", "fit", "lowcarb", "proteico", "dieta", "leve"}},
    "sopas": {"emoji": "🍲", "rotulo": "sopas",
              "palavras": {"sopa", "caldo", "canja"}},
    "vegetarianas": {"emoji": "🥦", "rotulo": "vegetarianas",
                     "palavras": {"vegetariano", "vegetariana", "vegano", "vegana", "veggie"}},
    "carnes": {"emoji": "🥩", "rotulo": "carnes",
               "palavras": {"carne", "churrasco", "churrasquinho"}},
}

# "salgado" não é uma categoria do banco: significa "tudo, menos doces".
PALAVRAS_SALGADO = {"salgado", "salgada", "salgados", "salgadas"}

DIFICULDADES = {
    "facil": {"facil", "facilzinho", "facilzinha", "simples", "iniciante", "descomplicado", "descomplicada"},
    "medio": {"medio", "intermediario", "mediano"},
    "dificil": {"dificil", "desafiador", "desafio", "avancado", "elaborado"},
}
ROTULO_DIFICULDADE = {"facil": "fáceis", "medio": "de dificuldade média", "dificil": "mais elaboradas"}

PALAVRAS_RAPIDO = {"rapido", "rapida", "rapidinho", "rapidinha", "rapidos", "rapidas", "expresso", "pratico", "pratica"}
TEMPO_RAPIDO_MIN = 30

# Técnica / temperatura de servir. O banco não tem esse campo, então procuramos
# no texto da receita (título, resumo e modo de preparo).
TECNICAS = {
    "frito": {
        "rotulo": "frituras",
        "palavras": {"frito", "fritos", "frita", "fritas", "fritura", "frituras", "fritar"},
        "regex": re.compile(r"\bfrit|\bfrigi|oleo (?:bem )?quente|oleo abundante"),
        "nega": None,
    },
    "assado": {
        "rotulo": "assados no forno",
        "palavras": {"assado", "assados", "assada", "assadas"},
        "regex": re.compile(r"\bforno|\bassa(?:r|d)"),
        "nega": None,
    },
    "grelhado": {
        "rotulo": "grelhados",
        "palavras": {"grelhado", "grelhados", "grelhada", "grelhadas"},
        "regex": re.compile(r"\bgrelh|\bchapa|\bgrill|churrasqueira"),
        "nega": None,
    },
    "gelado": {
        "rotulo": "servidos gelados",
        "palavras": {"gelado", "gelada", "gelados", "geladas", "geladinho", "geladinha", "frio", "fria",
                     "frios", "frias", "fresquinho", "fresquinha", "refrescante", "refrescantes"},
        "regex": re.compile(r"\bgelad|\bgelar|geladeira|refriger|freezer|resfri|\bsorvete|\bsalada|ceviche|"
                            r"carpaccio|\bfrio\b|\bfria\b|congel"),
        "nega": re.compile(r"\bmorn|\bquente|\bsopa|\bassad|\bfrit|\bgrelh|\bbife"),
    },
    "sem_forno": {
        "rotulo": "sem forno",
        "palavras": set(),
        "regex": None,   # tratado à parte: nenhuma menção a forno/assar
        "nega": None,
    },
}

# Qualificadores que fazem parte do nome do ingrediente anterior: "leite condensado", "carne moída".
QUALIFICADORES_INGREDIENTE = {
    "condensado", "condensada", "moido", "moida", "ralado", "ralada", "picado", "picada",
    "fatiado", "fatiada", "integral", "desnatado", "desnatada", "cremoso", "cremosa",
    "fresco", "fresca", "cozido", "cozida", "defumado", "defumada",
}

# "<ingrediente> de <X>" que muda de identidade: "leite de coco", "farinha de rosca", "creme de leite".
COMPOSTOS = {
    "leite": {"coco", "amendoa", "amendoas", "aveia", "soja", "arroz", "castanha"},
    "farinha": {"rosca", "mandioca", "milho", "aveia", "amendoa", "arroz", "tapioca", "coco", "trigo"},
    "creme": {"leite", "coco"},
    "doce": {"leite", "abobora", "goiaba", "banana"},
    "molho": {"tomate", "soja", "pimenta"},
    "pasta": {"amendoim", "alho"},
    "caldo": {"carne", "galinha", "legumes", "frango"},
    "acucar": {"confeiteiro", "mascavo"},
    "oleo": {"coco"},
}
# Qualificadores que, na RECEITA, fazem "leite" deixar de ser leite comum etc.
# (o pedido "leite" simples não casa com "leite de coco" nem "leite condensado").
ESPECIFICOS_NA_RECEITA = {
    "leite": COMPOSTOS["leite"] | {"condensado", "po"},
    "farinha": COMPOSTOS["farinha"] - {"trigo"},
    "acucar": COMPOSTOS["acucar"],
    "oleo": COMPOSTOS["oleo"],
}

# Palavras de medida/corte: não são o ingrediente, apenas o descrevem
# ("1 xícara de leite", "peito de frango", "suco de limão").
UNIDADES = {
    "xicara", "xicaras", "colher", "colheres", "copo", "copos", "lata", "latas", "caixa", "caixas",
    "pacote", "pacotes", "pote", "potes", "sache", "saches", "tablete", "tabletes", "litro", "litros",
    "l", "ml", "g", "kg", "mg", "grama", "gramas", "pitada", "pitadas", "dente", "dentes", "fatia",
    "fatias", "unidade", "unidades", "maco", "macos", "ramo", "ramos", "folha", "folhas", "gota",
    "gotas", "punhado", "porcao", "porcoes", "cubo", "cubos", "tira", "tiras", "pedaco", "pedacos",
    "posta", "postas", "file", "files", "peito", "peitos", "coxa", "coxas", "sobrecoxa", "sobrecoxas",
    "lombo", "costela", "costelas", "bife", "bifes", "raspa", "raspas", "suco", "casca", "cascas",
    "rodela", "rodelas", "gomo", "gomos", "cabeca", "cabecas", "talo", "talos", "sopa", "cha",
    "sobremesa", "meia", "meio", "pouco", "pouca", "bastante", "generosa", "cheia", "rasa",
    "grande", "grandes", "pequeno", "pequena", "pequenos", "medio", "media", "maduro", "madura",
    "bom", "boa", "inteiro", "inteira", "temperatura", "ambiente",
}
PULAR_NA_LINHA = {"de", "do", "da", "dos", "das", "e", "a", "o", "os", "as", "um", "uma", "em", "para",
                  "gosto", "opcional", "se", "quiser", "ou", "com", "sem", "no", "na"}

# Palavras que nunca são ingrediente (ao ler o pedido).
STOP_INGREDIENTE = {
    "o", "a", "os", "as", "um", "uma", "uns", "umas", "de", "do", "da", "dos", "das", "e", "ou",
    "com", "sem", "para", "pra", "pro", "em", "no", "na", "nos", "nas", "por", "que", "se",
    "algo", "alguma", "algum", "coisa", "coisas", "bem", "muito", "muita", "pouco", "pouca", "bastante",
    "tambem", "aqui", "casa", "geladeira", "despensa", "hoje", "agora", "sendo", "ser", "seja",
    "receita", "receitas", "prato", "pratos", "opcao", "opcoes", "ideia", "ideias", "sugestao",
    "sugestoes", "quero", "queria", "gostaria", "fazer", "preparar", "cozinhar", "gostoso",
    "gostosa", "gostosos", "gostosas", "ingrediente", "ingredientes", "tenho", "tem", "temos",
    "mais", "tipo", "assim", "meu", "minha", "seu", "sua", "so", "apenas", "somente", "tudo",
    "usando", "utilizando", "leve", "leva", "tenha", "base", "minutos", "minuto", "hora", "horas",
    "min", "ate", "menos", "maximo", "pode", "posso", "possa", "poderia", "favor", "ai",
    "ola", "oi", "mim", "me", "eu", "voce", "vc", "outro", "outra", "outros", "outras", "servido",
    "servida", "verdade", "melhor", "prefiro",
}


# ============================================================
# TEXTO
# ============================================================

def _sem_acentos(texto):
    texto = unicodedata.normalize("NFD", str(texto or "").lower())
    return "".join(c for c in texto if unicodedata.category(c) != "Mn")


def _radical(palavra):
    """Plural simples: ovos->ovo, limões->limao, pães->pao."""
    if len(palavra) > 4 and (palavra.endswith("oes") or palavra.endswith("aes")):
        return palavra[:-3] + "ao"
    if len(palavra) > 3 and palavra.endswith("s"):
        return palavra[:-1]
    return palavra


def _palavras(texto):
    return re.findall(r"[a-z]+", _sem_acentos(texto))


def _campo(item, *nomes):
    for nome in nomes:
        valor = item.get(nome)
        if valor is not None and str(valor).strip() != "":
            return valor
    return ""


def tempo_em_minutos(tempo):
    """'45 min' -> 45, '1h30' -> 90, '2 horas' -> 120; None se não entender."""
    texto = _sem_acentos(tempo)
    total, achou = 0, False
    for valor, unidade in re.findall(r"(\d+)\s*(h|hora|horas|min|m|minuto|minutos)?", texto):
        v = int(valor)
        total += v * 60 if unidade.startswith("h") else v
        achou = True
    return total if achou else None


# ============================================================
# INTERPRETAÇÃO DO PEDIDO
# ============================================================

@dataclass
class Pedido:
    categoria: Optional[str] = None            # chave de CATEGORIAS
    sem_doces: bool = False                    # "salgado"
    tempo_max: Optional[int] = None
    dificuldade: Optional[str] = None
    tecnica: Optional[str] = None              # chave de TECNICAS
    # ingredientes pedidos: (como o usuário escreveu, radical normalizado)
    ingredientes: List[tuple] = field(default_factory=list)

    @property
    def tem_filtro(self):
        return bool(
            self.categoria or self.sem_doces or self.tempo_max or self.dificuldade
            or self.tecnica or self.ingredientes
        )


_TERMINADORES = re.compile(
    r"\b(sendo|seja|mas|porem|para|pra|quero|queria|gostaria|preciso|o que|oque|qual|quais|"
    r"que posso|que eu posso|me de|me da|me sugira|me indica|me diga|e algo|e uma|e um|e que|"
    r"so que|sem|nao|ate|em ate|em menos|rapido|rapida|facil|simples|na verdade|mais)\b|[?!.;]"
)
_GATILHO_INGREDIENTE = re.compile(
    r"\b(com|tenho|temos|tendo|usando|utilizando|que leve|que leva|que tenha|que use|"
    r"a base de|so tenho|sobrou|sobraram)\b"
)


def _categoria_do_texto(texto_norm):
    """Primeira categoria citada. 'doce de leite', 'massa de pizza' NÃO contam (é nome de receita)."""
    palavras = texto_norm.split()
    for i, palavra in enumerate(palavras):
        radical = _radical(palavra)
        seguinte = palavras[i + 1] if i + 1 < len(palavras) else ""
        for chave, dados in CATEGORIAS.items():
            if radical in dados["palavras"] or palavra in dados["palavras"]:
                if seguinte in {"de", "do", "da", "dos", "das"} and chave in {"doces", "massas", "carnes", "sopas"}:
                    continue
                return chave
    return None


def _tempo_do_texto(texto_norm):
    m = re.search(
        r"\b(?:ate|em ate|no maximo|menos de|em)\s*(\d+)\s*(h|hora|horas|min|minuto|minutos)\b", texto_norm
    )
    if m:
        valor = int(m.group(1))
        return valor * 60 if m.group(2).startswith("h") else valor
    if any(p in PALAVRAS_RAPIDO for p in texto_norm.split()):
        return TEMPO_RAPIDO_MIN
    return None


def _dificuldade_do_texto(texto_norm):
    palavras = set(texto_norm.split())
    for chave, termos in DIFICULDADES.items():
        if palavras & termos:
            return chave
    return None


def _tecnica_do_texto(texto_norm):
    if "sem forno" in texto_norm:
        return "sem_forno"
    palavras = set(texto_norm.split())
    for chave, dados in TECNICAS.items():
        if palavras & dados["palavras"]:
            return chave
    return None


def _palavra_de_filtro(norma):
    return (
        bool(_categoria_do_texto(norma)) or norma in PALAVRAS_SALGADO or norma in PALAVRAS_RAPIDO
        or any(norma in t for t in DIFICULDADES.values())
        or any(norma in d["palavras"] for d in TECNICAS.values())
    )


def _ingredientes_do_texto(mensagem):
    """Extrai a lista após 'com', 'tenho', 'usando'... até um terminador."""
    original = str(mensagem or "").lower()
    # remover acentos não muda o tamanho de cada caractere: os índices coincidem.
    norm = _sem_acentos(original)
    gatilho = _GATILHO_INGREDIENTE.search(norm)
    if not gatilho:
        return []

    resto_norm = norm[gatilho.end():]
    resto_orig = original[gatilho.end():]
    fim = _TERMINADORES.search(resto_norm)
    if fim:
        resto_norm, resto_orig = resto_norm[:fim.start()], resto_orig[:fim.start()]

    pares = list(zip(re.findall(r"[a-z]+", resto_norm), re.findall(r"[a-zà-ÿ]+", resto_orig)))
    encontrados, vistos = [], set()
    i = 0
    while i < len(pares):
        norma, escrita = pares[i]
        # "leite de coco", "creme de leite", "farinha de rosca": nome composto
        if (
            norma in COMPOSTOS and i + 2 < len(pares) and pares[i + 1][0] in {"de", "do", "da"}
            and _radical(pares[i + 2][0]) in COMPOSTOS[norma]
        ):
            composto = (f"{escrita} de {pares[i + 2][1]}", f"{_radical(norma)} {_radical(pares[i + 2][0])}")
            if composto[1] not in vistos:
                vistos.add(composto[1])
                encontrados.append(composto)
            i += 3
            continue
        i += 1

        if norma in STOP_INGREDIENTE or len(norma) < 3:
            continue
        if _palavra_de_filtro(norma):
            continue
        rad = _radical(norma)
        if norma in QUALIFICADORES_INGREDIENTE and encontrados:
            anterior_escrita, anterior_rad = encontrados[-1]
            if rad not in anterior_rad.split():
                encontrados[-1] = (f"{anterior_escrita} {escrita}", f"{anterior_rad} {rad}")
            continue
        if rad in vistos:
            continue
        vistos.add(rad)
        encontrados.append((escrita, rad))
    return encontrados


def interpretar_pedido(mensagem):
    norm = " ".join(_palavras(mensagem))
    pedido = Pedido()
    pedido.categoria = _categoria_do_texto(norm)
    pedido.sem_doces = any(p in PALAVRAS_SALGADO for p in norm.split())
    pedido.tempo_max = _tempo_do_texto(norm)
    pedido.dificuldade = _dificuldade_do_texto(norm)
    pedido.tecnica = _tecnica_do_texto(norm)
    pedido.ingredientes = _ingredientes_do_texto(mensagem)
    return pedido


# ============================================================
# MEMÓRIA DE CONVERSA: refinar o pedido anterior
# ============================================================

_MARCADOR_REFINAMENTO = re.compile(
    r"^(e|mas|ou|agora|entao)\b|\b(na verdade|mais|outro|outra|em vez|ao inves|prefiro|melhor|so que|que seja|pode ser)\b"
)


def mesclar_pedidos(base, novo, substituir_ingredientes=False):
    """Aplica `novo` por cima de `base`. Categoria/técnica novas substituem as antigas."""
    if base is None:
        return copy.deepcopy(novo)
    r = copy.deepcopy(base)
    if novo.categoria:
        r.categoria, r.sem_doces = novo.categoria, False
    if novo.sem_doces:
        r.sem_doces, r.categoria = True, None
    if novo.tempo_max:
        r.tempo_max = novo.tempo_max
    if novo.dificuldade:
        r.dificuldade = novo.dificuldade
    if novo.tecnica:
        r.tecnica = novo.tecnica
    if novo.ingredientes:
        if substituir_ingredientes:
            r.ingredientes = list(novo.ingredientes)
        else:
            existentes = {rad for _, rad in r.ingredientes}
            r.ingredientes += [i for i in novo.ingredientes if i[1] not in existentes]
    return r


# ============================================================
# É UM PEDIDO DE SUGESTÃO POR FILTRO?
# ============================================================

_NAO_E_SUGESTAO = re.compile(
    r"\b(como (?:fazer|faco|se faz|preparar)|passo a passo|modo de preparo|quanto tempo|"
    r"qual a temperatura|substitu\w+|o que e|o que significa|quer dizer|por que|porque)\b"
)
_CUE_CATEGORIA = re.compile(
    r"\b(quero|queria|gostaria|preciso|vontade|me (?:de|da|indica|indique|sugira|recomenda|mostra|mostre)|"
    r"tem|alguma|algum|algo|sugest\w*|sugira|ideias?|indica\w*|recomend\w*|opcoes|opcao|receitas?|"
    r"o que (?:posso|eu posso|da pra|da para|fazer|cozinhar|preparar)|que tal)\b"
)
_CUE_ABERTO = re.compile(
    r"\b(algo|alguma coisa|alguma receita|algumas receitas|coisas|receitas|receita com|tenho|sobrou|sobraram|"
    r"o que (?:posso|eu posso|da pra|da para|fazer|cozinhar|preparar)|sugest\w*|sugira|ideias?|indica\w*)\b"
)
_RECEITA_ESPECIFICA = re.compile(r"\breceitas? (?:de|do|da|dos|das)\b")
_QUERO_FAZER_ESPECIFICO = re.compile(
    r"\b(quero fazer|vou fazer|vamos fazer|queria fazer|gostaria de fazer)\s+(?!algo|alguma|um doce|uma sobremesa)"
)


def e_pedido_de_sugestao_filtrada(mensagem):
    norm = " ".join(_palavras(mensagem))
    if not norm or _NAO_E_SUGESTAO.search(norm):
        return False

    pedido = interpretar_pedido(mensagem)
    if pedido.categoria or pedido.sem_doces:
        # "quero fazer um doce" é pedido aberto; "quero fazer brigadeiro" não chega aqui (sem categoria)
        return bool(_CUE_CATEGORIA.search(norm))

    if _RECEITA_ESPECIFICA.search(norm) or _QUERO_FAZER_ESPECIFICO.search(norm):
        return False
    if pedido.ingredientes or pedido.tecnica or pedido.tempo_max or pedido.dificuldade:
        return bool(_CUE_ABERTO.search(norm))
    return False


def e_refinamento(mensagem):
    """'e coisas fritas?', 'na verdade salgado', 'mais gelado': ajusta o pedido anterior."""
    norm = " ".join(_palavras(mensagem))
    if not norm or _NAO_E_SUGESTAO.search(norm):
        return False
    pedido = interpretar_pedido(mensagem)
    if not pedido.tem_filtro:
        return False
    if _MARCADOR_REFINAMENTO.search(norm):
        return True
    return not _CUE_CATEGORIA.search(norm) and len(norm.split()) <= 5


# ============================================================
# RANKING
# ============================================================

def _analisar_linha(linha):
    """'1 caixa de creme de leite' -> ('creme', {'leite'}, {'creme','leite'}).

    A "cabeça" é o ingrediente de verdade; medidas e cortes são ignorados.
    """
    texto = re.sub(r"\(.*?\)", " ", _sem_acentos(linha))
    uteis = [p for p in re.findall(r"[a-z]+", texto) if p not in PULAR_NA_LINHA]
    if not uteis:
        return None
    idx = next((i for i, p in enumerate(uteis) if p not in UNIDADES), len(uteis) - 1)
    return (
        _radical(uteis[idx]),
        {_radical(p) for p in uteis[idx + 1:]},
        {_radical(p) for p in uteis},
    )


def _linhas_ingredientes(receita):
    texto = str(_campo(receita, "ingredientes", "ingredients"))
    partes = re.split(r"[\n;,]|\s+e\s+", texto)
    return [a for a in (_analisar_linha(p) for p in partes) if a]


def _mesma_palavra(a, b):
    if a == b:
        return True
    if min(len(a), len(b)) >= 5:
        return a.startswith(b) or b.startswith(a) or tokens_parecidos(a, b)
    return False


def _ingrediente_casa(pedido_rad, linhas):
    partes = pedido_rad.split()
    cabeca, qualificadores = partes[0], partes[1:]
    for head, quals, todos in linhas:
        if not _mesma_palavra(cabeca, head):
            continue
        if qualificadores:
            if all(any(_mesma_palavra(q, t) for t in todos) for q in qualificadores):
                return True
        elif not (quals & ESPECIFICOS_NA_RECEITA.get(head, set())):
            return True
    return False


def _texto_busca(receita):
    return _sem_acentos(" ".join(str(_campo(receita, c)) for c in ("titulo", "nome", "resumo", "passos")))


def _passa_tecnica(receita, tecnica):
    texto = _texto_busca(receita)
    if tecnica == "sem_forno":
        return bool(str(_campo(receita, "passos")).strip()) and not re.search(r"\bforno|\bassa(?:r|d)", texto)
    dados = TECNICAS[tecnica]
    if not dados["regex"].search(texto):
        return False
    titulo = _sem_acentos(_campo(receita, "titulo", "nome"))
    return not (dados["nega"] and dados["nega"].search(titulo))


@dataclass
class Resultado:
    itens: list                                   # [{"receita", "usa"}]
    ingredientes_pedidos: list                    # como o usuário escreveu
    sem_receita: list                             # ingredientes que nenhuma receita da categoria usa
    n_completas: int                              # quantas usam TODOS os ingredientes pedidos
    relaxados: list                               # filtros ignorados por falta de resultado

    @property
    def cobertura_total(self):
        return bool(self.ingredientes_pedidos) and self.n_completas > 0


def _passa_filtros(receita, pedido, usar_tempo=True, usar_dificuldade=True, usar_tecnica=True):
    categoria = _sem_acentos(_campo(receita, "categoria", "category"))
    if pedido.categoria and _sem_acentos(pedido.categoria) not in categoria:
        return False
    if pedido.sem_doces and "doce" in categoria:
        return False
    if usar_tempo and pedido.tempo_max:
        minutos = tempo_em_minutos(_campo(receita, "tempo", "tempo_preparo"))
        if minutos is not None and minutos > pedido.tempo_max:
            return False
    if usar_dificuldade and pedido.dificuldade:
        if pedido.dificuldade not in _sem_acentos(_campo(receita, "dificuldade", "difficulty")):
            return False
    if usar_tecnica and pedido.tecnica and not _passa_tecnica(receita, pedido.tecnica):
        return False
    return True


_ORDEM_RELAXAMENTO = [
    (), ("tecnica",), ("tempo",), ("dificuldade",),
    ("tecnica", "tempo"), ("tecnica", "dificuldade"), ("tempo", "dificuldade"),
    ("tecnica", "tempo", "dificuldade"),
]
MINIMO_COM_PARCIAIS = 5


def ranquear(receitas, pedido, aleatorio=random):
    """Filtra e ordena por quantos ingredientes pedidos a receita usa (linha a linha)."""
    receitas = [r for r in receitas if isinstance(r, dict) and str(_campo(r, "titulo", "nome", "title")).strip()]
    pedidos = pedido.ingredientes
    pedidos_ativos = {"tecnica": bool(pedido.tecnica), "tempo": bool(pedido.tempo_max),
                      "dificuldade": bool(pedido.dificuldade)}
    linhas = {id(r): _linhas_ingredientes(r) for r in receitas}

    def com_uso(r):
        return {"receita": r, "usa": [e for e, rad in pedidos if _ingrediente_casa(rad, linhas[id(r)])]}

    base = [r for r in receitas if _passa_filtros(r, pedido, False, False, False)]
    sem_receita = [
        e for e, rad in pedidos if not any(_ingrediente_casa(rad, linhas[id(r)]) for r in base)
    ]

    itens, relaxados = [], []
    for combo in _ORDEM_RELAXAMENTO:
        if any(not pedidos_ativos[c] for c in combo):
            continue
        cands = [
            r for r in base
            if _passa_filtros(r, pedido, "tempo" not in combo, "dificuldade" not in combo, "tecnica" not in combo)
        ]
        itens = [com_uso(r) for r in cands]
        if pedidos:
            itens = [i for i in itens if i["usa"]]
        if itens:
            relaxados = list(combo)
            break

    aleatorio.shuffle(itens)  # variedade entre empates (o sort abaixo é estável)
    itens.sort(key=lambda i: -len(i["usa"]))

    n = len(pedidos)
    n_completas = len([i for i in itens if len(i["usa"]) == n]) if n else 0
    if n > 1 and itens:
        melhor = len(itens[0]["usa"])
        nucleo = [i for i in itens if len(i["usa"]) == melhor]
        if len(nucleo) < MINIMO_COM_PARCIAIS:
            extra = [i for i in itens if i not in nucleo and len(i["usa"]) * 2 >= n]
            nucleo += extra[:MINIMO_COM_PARCIAIS - len(nucleo)]
        itens = nucleo

    return Resultado(itens, [e for e, _ in pedidos], sem_receita, n_completas, relaxados)


# ============================================================
# TEXTO DA RESPOSTA
# ============================================================

def _lista_natural(palavras):
    palavras = list(palavras)
    if len(palavras) <= 1:
        return "".join(palavras)
    return ", ".join(palavras[:-1]) + " e " + palavras[-1]


def descrever_filtros(pedido):
    partes = []
    if pedido.categoria:
        partes.append(CATEGORIAS[pedido.categoria]["rotulo"])
    elif pedido.sem_doces:
        partes.append("salgadas")
    if pedido.tecnica:
        partes.append(TECNICAS[pedido.tecnica]["rotulo"])
    if pedido.dificuldade:
        partes.append(ROTULO_DIFICULDADE[pedido.dificuldade])
    if pedido.tempo_max:
        partes.append(f"em até {pedido.tempo_max} min")
    if pedido.ingredientes:
        partes.append("com " + _lista_natural([e for e, _ in pedido.ingredientes]))
    return partes


def montar_titulo(pedido, resultado):
    emoji = CATEGORIAS[pedido.categoria]["emoji"] if pedido.categoria else "🍽️"
    titulo = f"{emoji} Sugestões"
    if pedido.categoria:
        titulo += f" de {CATEGORIAS[pedido.categoria]['rotulo']}"
    elif pedido.sem_doces:
        titulo += " salgadas"
    usados = [i for i in resultado.ingredientes_pedidos if i not in resultado.sem_receita]
    if usados:
        titulo += f" com {_lista_natural(usados)}"
    extras = []
    if pedido.tecnica and "tecnica" not in resultado.relaxados:
        extras.append(TECNICAS[pedido.tecnica]["rotulo"])
    if pedido.dificuldade and "dificuldade" not in resultado.relaxados:
        extras.append(ROTULO_DIFICULDADE[pedido.dificuldade])
    if pedido.tempo_max and "tempo" not in resultado.relaxados:
        extras.append(f"em até {pedido.tempo_max} min")
    if extras:
        titulo += " (" + ", ".join(extras) + ")"
    return titulo + ":"


def montar_nota(pedido, resultado):
    """Avisos honestos: o que não foi possível atender. Vazio quando tudo foi atendido."""
    notas = []
    if resultado.sem_receita:
        onde = f"de {CATEGORIAS[pedido.categoria]['rotulo']} " if pedido.categoria else ""
        notas.append(f"Não encontrei receitas {onde}com {_lista_natural(resultado.sem_receita)} no BiteByte.")
    usados = [i for i in resultado.ingredientes_pedidos if i not in resultado.sem_receita]
    if len(usados) > 1 and resultado.itens:
        if resultado.n_completas == 0:
            notas.append("Nenhuma receita usa todos os ingredientes que você citou; "
                         "estas são as que mais se aproximam.")
        elif resultado.n_completas < len(resultado.itens):
            qtd = resultado.n_completas
            notas.append(
                f"Só {qtd} receita{'s' if qtd > 1 else ''} usa{'m' if qtd > 1 else ''} todos os ingredientes; "
                "completei com as que usam parte deles."
            )
    if "tecnica" in resultado.relaxados and pedido.tecnica:
        notas.append(f"Não encontrei opções {TECNICAS[pedido.tecnica]['rotulo']} no BiteByte, "
                     "então mostrei outras também.")
    if "tempo" in resultado.relaxados:
        notas.append(f"Não achei opções em até {pedido.tempo_max} min, então mostrei outras também.")
    if "dificuldade" in resultado.relaxados:
        notas.append("Não achei opções com essa dificuldade, então mostrei outras também.")
    return " ".join(notas)


def formatar_sugestoes_filtradas(itens, titulo, nota="", total_pedidos=0):
    """Mesmo formato '1. **Nome** / Resumo / Tempo' que o resto do sistema já sabe ler."""
    linhas = [titulo, ""]
    if nota:
        linhas += [f"ℹ️ {nota}", ""]
    for indice, item in enumerate(itens, 1):
        linhas.append(f"{indice}. **{item['nome']}**")
        linhas.append(f"   **Resumo:** {item['descricao']}")
        linhas.append(f"   **Tempo:** {item['tempo']}")
        if item.get("usa"):
            linhas.append(f"   **Usa o que você tem:** {_lista_natural(item['usa'])}"
                          + (f" ({len(item['usa'])}/{total_pedidos})" if total_pedidos > 1 else ""))
        linhas.append("")
    if linhas[-1] == "":
        linhas.pop()
    return "\n".join(linhas)