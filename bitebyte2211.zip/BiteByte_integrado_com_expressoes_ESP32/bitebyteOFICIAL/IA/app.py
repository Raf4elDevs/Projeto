from flask import Flask, render_template, request, Response
import requests
import json
import os
import unicodedata
import re
import hashlib
import time

import threading
import random

from respostas_locais_engine import (
    BaseDeConhecimento,
    responder_local,
    encontrar_casual,
    expressao_por_emoji,
)
from sugestoes_banco import (
    Pedido,
    interpretar_pedido,
    mesclar_pedidos,
    e_refinamento,
    e_pedido_de_sugestao_filtrada,
    ranquear,
    montar_titulo,
    montar_nota,
    formatar_sugestoes_filtradas,
    descrever_filtros,
)
from referencias_web import (
    buscar_referencias_culinarias,
    buscar_referencia_receita,
    detalhar_referencia,
    resumir_referencias_para_modelo,
)

app = Flask(__name__)

# ============================================================
# CONFIGURAÇÃO
# ============================================================

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/chat")
MODELO = os.getenv("CHEFBOT_MODEL", "chefbot:latest")
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8080")
NUM_CTX = int(os.getenv("CHEFBOT_NUM_CTX", "6144"))
USAR_REFERENCIA_WEB = os.getenv("CHEFBOT_REFERENCIA_WEB", "true").lower() in {"1", "true", "sim", "yes"}

# Depois que uma mesma pergunta aparecer 3 vezes, ela pode virar
# conhecimento global APENAS se passar pela validação automática.
LIMITE_FREQUENCIA = 3

# Cache curto para não consultar a base de conhecimento em toda mensagem.
CACHE_ENSINAMENTOS_TTL = 20
_cache_ensinamentos = []
_cache_ensinamentos_em = 0.0

# ============================================================
# ARQUIVOS LOCAIS
# ============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

CAMINHO_RESPOSTAS_LOCAIS = os.path.join(BASE_DIR, "respostas_locais.json")
CAMINHO_RESPOSTAS_FORA = os.path.join(BASE_DIR, "respostas_fora.json")
CAMINHO_PALAVRAS_FORA = os.path.join(BASE_DIR, "palavras_fora_culinaria.json")


def carregar_json(caminho):
    try:
        with open(caminho, "r", encoding="utf-8") as arquivo:
            return json.load(arquivo)
    except FileNotFoundError:
        print(f"[ChefBot] Arquivo não encontrado: {caminho}")
    except json.JSONDecodeError as erro:
        print(f"[ChefBot] JSON inválido em {caminho}: {erro}")
    return {}


respostas_locais = carregar_json(CAMINHO_RESPOSTAS_LOCAIS)
respostas_fora = carregar_json(CAMINHO_RESPOSTAS_FORA)
palavras_fora = carregar_json(CAMINHO_PALAVRAS_FORA)


# ============================================================
# CONVERSA CASUAL / SAUDAÇÕES
# ============================================================
# A lógica vive em respostas_locais_engine.py: tolera "oii", "oiii",
# "obrigadooo", "vlw" etc. e devolve texto + expressão facial variados.

def buscar_resposta_casual(mensagem):
    resposta = encontrar_casual(mensagem)
    return resposta.texto if resposta else None


# ============================================================
# TEXTO / NORMALIZAÇÃO
# ============================================================

def normalizar_texto(texto):
    texto = str(texto or "").lower().strip()
    texto = unicodedata.normalize("NFD", texto)
    texto = "".join(
        caractere
        for caractere in texto
        if unicodedata.category(caractere) != "Mn"
    )
    texto = re.sub(r"\s+", " ", texto)
    return texto


def tokenizar(texto):
    return re.findall(r"[a-z0-9]+", normalizar_texto(texto))


STOPWORDS = {
    "a", "o", "as", "os", "um", "uma", "uns", "umas", "de", "da",
    "do", "das", "dos", "em", "no", "na", "nos", "nas", "por", "para",
    "com", "sem", "e", "ou", "que", "como", "qual", "quais", "me", "te",
    "se", "eu", "voce", "voces", "uma", "um", "ao", "aos", "e",
}

QUALIFICADORES_RECEITA = {
    "facil", "facilmente", "rapido", "rapida", "rapidos", "rapidas", "caseiro",
    "caseira", "caseiros", "caseiras", "tradicional", "tradicionalmente",
    "especial", "delicioso", "deliciosa", "cremoso", "cremosa", "simples",
    "classico", "classica", "classicos", "classicas", "perfeito", "perfeita",
    "economico", "economica", "fit", "light", "gourmet", "irresistivel",
}


def tokens_importantes(texto):
    return {
        token
        for token in tokenizar(texto)
        if token not in STOPWORDS and len(token) > 2
    }


def nomes_representam_mesma_receita(nome_a, nome_b):
    """Deduplicação conservadora de nomes de receitas.

    Não trata apenas variações como 'Bolo de Chocolate' e
    'Bolo de Chocolate Cremoso' como receitas diferentes.
    """
    a = normalizar_texto(nome_a)
    b = normalizar_texto(nome_b)

    if not a or not b:
        return False

    if a == b:
        return True

    ta = tokens_importantes(a) - QUALIFICADORES_RECEITA
    tb = tokens_importantes(b) - QUALIFICADORES_RECEITA

    if len(ta) < 2 or len(tb) < 2:
        return False

    menor, maior = (ta, tb) if len(ta) <= len(tb) else (tb, ta)

    # Um nome-base inteiro dentro do outro é praticamente a mesma receita.
    if menor.issubset(maior):
        return True

    intersecao = len(ta & tb)
    uniao = len(ta | tb)

    return intersecao >= 2 and (intersecao / max(uniao, 1)) >= 0.75


def contem_termo(texto, termo):
    texto = normalizar_texto(texto)
    termo = normalizar_texto(termo)

    if not texto or not termo:
        return False

    return re.search(rf"(?<!\w){re.escape(termo)}(?!\w)", texto) is not None


# ============================================================
# PROMPT PRINCIPAL
# ============================================================

PROMPT_BASE = """

Você é o ChefBot.

Você é um assistente especializado em culinária,
gastronomia, cozinha, alimentos, receitas e preparo.

============================================================
REGRA ABSOLUTA
============================================================

Você deve obedecer à intenção definida pelo sistema.

O sistema informará se o usuário quer:

SUGESTÃO
NOVAS_SUGESTÕES
RECEITA
PERGUNTA

Você NÃO deve trocar a intenção.

============================================================
MODO SUGESTÃO
============================================================

Quando o sistema informar:

MODO = SUGESTÃO

O usuário quer APENAS IDEIAS.

É PROIBIDO fornecer:

- ingredientes
- quantidades
- modo de preparo
- temperatura
- tempo de forno
- etapas
- instruções
- receita completa

Apresente entre 3 e 5 opções.

============================================================
MODO NOVAS_SUGESTÕES
============================================================

Quando o sistema informar:

MODO = NOVAS_SUGESTÕES

O usuário quer outras receitas.

NÃO repita receitas que já apareceram no histórico.

NOVAS_SUGESTÕES continua sendo apenas sugestão.

É PROIBIDO fornecer ingredientes, quantidades,
preparo, temperatura, tempo ou instruções.

============================================================
MODO RECEITA
============================================================

Somente quando o sistema informar:

MODO = RECEITA

Você pode fornecer a receita completa.

Use:

🍳 Receita:
🧂 Ingredientes:
👨‍🍳 Modo de preparo:
💡 Dica:

============================================================
PADRÃO OBRIGATÓRIO PARA O MODO DE PREPARO
============================================================

Quando uma receita for apresentada, cada etapa deve possuir
UM ÚNICO número.

O número identifica a etapa, e não cada linha do texto.

Uma etapa é formada por:

NÚMERO + TÍTULO DA ETAPA
DESCRIÇÃO DA ETAPA

Exemplo correto:

1. PREPARAR OS INGREDIENTES
Separe todos os ingredientes antes de iniciar o preparo.

2. INICIAR A MISTURA
Coloque os ingredientes na panela e misture bem.

3. COZINHAR
Ligue o fogo baixo e mexa continuamente.

Nunca transforme a descrição de uma etapa em uma nova etapa.

NÃO faça:

1. PREPARAR OS INGREDIENTES
2. Separe todos os ingredientes.
3. INICIAR A MISTURA
4. Coloque os ingredientes na panela.

Quando uma receita vier do banco de dados, considere os dados
do banco como a fonte oficial da receita.

NÃO invente, substitua ou altere:

- ingredientes
- quantidades
- tempos
- temperaturas
- etapas
- modo de preparo

Você pode apenas organizar a apresentação sem alterar
as informações originais.

============================================================
MODO PERGUNTA
============================================================

Responda somente à dúvida culinária apresentada.

Se a pergunta não pedir receita, não invente uma receita.

============================================================
FORA DA CULINÁRIA
============================================================

Não responda assuntos fora da culinária.

============================================================
CONTROLE FACIAL DO ROBÔ BITEBYTE
============================================================

Além de escrever a resposta, escolha a expressão facial mais adequada ao
contexto emocional da conversa. A escolha deve considerar a mensagem atual,
a intenção do usuário, o histórico e o tom da resposta — não apenas palavras
isoladas.

A PRIMEIRA COISA da sua saída deve ser exatamente um destes marcadores,
sem introdução, sem Markdown e sem qualquer texto antes dele:

[[BITEBYTE_FACE:NEUTRO]]
[[BITEBYTE_FACE:FELIZ]]
[[BITEBYTE_FACE:TRISTE]]
[[BITEBYTE_FACE:BRAVO]]
[[BITEBYTE_FACE:APAIXONADO]]
[[BITEBYTE_FACE:ERRO]]
[[BITEBYTE_FACE:SUSTO]]

Depois do marcador, coloque uma quebra de linha e escreva a resposta normal
ao usuário. O marcador é um comando interno: nunca o explique nem o repita
no corpo da resposta.

Critérios de escolha:
- NEUTRO: explicações, orientações e respostas informativas sem emoção forte.
- FELIZ: cumprimento caloroso, agradecimento, conquista, elogio ou conversa positiva.
- TRISTE: empatia diante de frustração, perda, erro culinário ou situação difícil.
- BRAVO: indignação claramente justificada no contexto; use com moderação,
  sem hostilidade ao usuário.
- APAIXONADO: entusiasmo carinhoso e genuíno por comida, receitas ou resultados.
- ERRO: falha real do sistema ou impossibilidade técnica, não apenas uma
  resposta fora do escopo culinário.
- SUSTO: surpresa genuína diante de algo inesperado, raro ou impressionante.

Na dúvida, escolha NEUTRO. Não force emoções em toda resposta.
Não escolha DORMINDO nem SONOLENTO: esses estados são controlados pelo
firmware da ESP32 após períodos sem interação.
"""


# ============================================================
# PROMPTS DOS NÍVEIS
# ============================================================

PROMPTS_NIVEL = {
    "iniciante": """
O usuário é iniciante na cozinha.
Use linguagem simples e fácil de entender.
Evite termos técnicos desnecessários.
""",
    "intermediario": """
O usuário possui conhecimento intermediário.
Pode utilizar termos culinários comuns.
Se necessário, explique rapidamente.
""",
    "avancado": """
O usuário possui conhecimento avançado.
Pode utilizar terminologia culinária técnica quando isso for útil.
"""
}


# ============================================================
# CLASSIFICAÇÃO CULINÁRIA — ANTES DA BUSCA EXTERNA
# ============================================================

PALAVRAS_CULINARIAS = {
    # ações e preparo
    "cozinhar", "cozinhei", "cozinha", "preparar", "preparo", "fazer",
    "assar", "assado", "fritar", "frito", "refogar", "ferver", "cozer",
    "cortar", "bater", "misturar", "temperar", "marinar", "grelhar",
    "caramelizar", "congelar", "descongelar", "assar",
    # receita/estrutura
    "receita", "ingrediente", "ingredientes", "modo", "preparo", "porcao",
    "porções", "rendimento", "sobremesa", "almoço", "almoco", "jantar",
    "lanche", "cafe", "café", "comida", "prato", "culinaria", "culinária",
    "gastronomia", "cozinha", "cozinha", "tempero", "molho", "massa",
    # utensílios/equipamentos
    "forno", "fogao", "fogão", "panela", "frigideira", "liquidificador",
    "batedeira", "airfryer", "microondas", "micro-ondas", "assadeira",
    "forma", "faca", "espátula", "espatula", "peneira",
    # alimentos comuns
    "arroz", "feijao", "feijão", "macarrao", "macarrão", "lasanha", "pizza",
    "bolo", "torta", "pudim", "brigadeiro", "brownie", "biscoito",
    "cookie", "pao", "pão", "sanduiche", "sanduíche", "sopa", "salada",
    "carne", "frango", "peixe", "salmao", "salmão", "camarao", "camarão",
    "bacon", "ovo", "ovos", "leite", "queijo", "manteiga", "creme",
    "chantilly", "chocolate", "morango", "banana", "maca", "maçã", "limao",
    "limão", "abacaxi", "coco", "cenoura", "batata", "tomate", "cebola",
    "alho", "milho", "aveia", "farinha", "fermento", "gelatina",
    "canela", "baunilha", "acucar", "açúcar", "sal", "azeite", "oleo",
    "óleo", "vinagre", "mostarda", "ketchup",
}


def parece_pedido_culinario(mensagem, intencao=None, historico=None):
    """Evita consultar a referência web para mensagens que não são culinárias."""
    texto = normalizar_texto(mensagem)

    if buscar_resposta_casual(mensagem):
        return False

    if intencao in {"SUGESTÃO", "NOVAS_SUGESTÕES", "RECEITA"}:
        return True

    if precisa_de_contexto_anterior(mensagem):
        return True

    tokens = set(tokenizar(texto))
    if tokens & {normalizar_texto(p) for p in PALAVRAS_CULINARIAS}:
        return True

    # Perguntas muito curtas e ambíguas não devem ser enviadas ao site.
    if len(tokens) <= 2:
        return False

    return False


def resposta_fora_escopo_culinario():
    return (
        "🍳 Eu sou o ChefBot e fui feito para culinária. "
        "Posso ajudar com receitas, ingredientes, preparo, técnicas e ideias de pratos. "
        "Me diga o que você gostaria de cozinhar."
    )


# ============================================================
# BACKEND / PERFIL / HISTÓRICO
# ============================================================

def buscar_preferencias_usuario(email):
    try:
        resposta = requests.get(
            f"{BACKEND_URL}/user/preferences/{email}",
            timeout=8,
        )
        if resposta.status_code == 200:
            dados = resposta.json()
            return dados if isinstance(dados, dict) else None

        print(
            f"[ChefBot] Erro ao buscar preferências: "
            f"HTTP {resposta.status_code}"
        )
    except requests.exceptions.RequestException as erro:
        print(f"[ChefBot] Backend de preferências indisponível: {erro}")
    return None


def ordenar_historico_recente_primeiro(historico):
    """O backend entrega findTop10...OrderByDataHoraDesc (mais recente primeiro).

    Todo o código de "última consulta / última lista" depende disso, então a ordem
    é garantida aqui, mesmo que o backend mude.
    """
    def chave(item):
        if not isinstance(item, dict):
            return ("", 0)
        return (str(item.get("dataHora") or item.get("data_hora") or ""), int(item.get("id") or 0))

    if any(isinstance(i, dict) and (i.get("dataHora") or i.get("data_hora") or i.get("id")) for i in historico):
        return sorted(historico, key=chave, reverse=True)
    return list(historico)


def buscar_historico_usuario(email):
    try:
        resposta = requests.get(
            f"{BACKEND_URL}/chat/history/{email}",
            timeout=8,
        )
        if resposta.status_code == 200:
            dados = resposta.json()
            return ordenar_historico_recente_primeiro(dados) if isinstance(dados, list) else []

        print(
            f"[ChefBot] Erro ao buscar histórico: "
            f"HTTP {resposta.status_code}"
        )
    except requests.exceptions.RequestException as erro:
        print(f"[ChefBot] Backend de histórico indisponível: {erro}")
    return []


def salvar_historico_usuario(email, mensagem, resposta, intencao):
    try:
        dados = {
            "email": email,
            "mensagem": mensagem,
            "resposta": resposta,
            "intencao": intencao,
        }

        resposta_backend = requests.post(
            f"{BACKEND_URL}/chat/history",
            json=dados,
            timeout=8,
        )

        if resposta_backend.status_code in [200, 201]:
            print("[ChefBot] Histórico salvo no MySQL.")
            return True

        print(
            "[ChefBot] Erro ao salvar histórico:",
            resposta_backend.status_code,
            resposta_backend.text,
        )
    except requests.exceptions.RequestException as erro:
        print(f"[ChefBot] Erro ao salvar histórico: {erro}")

    return False


# ============================================================
# BASE DE CONHECIMENTO
# ============================================================

def invalidar_cache_ensinamentos():
    global _cache_ensinamentos, _cache_ensinamentos_em
    _cache_ensinamentos = []
    _cache_ensinamentos_em = 0.0


def buscar_ensinamentos_aprovados(force=False):
    global _cache_ensinamentos, _cache_ensinamentos_em

    agora = time.time()
    if (
        not force
        and _cache_ensinamentos
        and agora - _cache_ensinamentos_em < CACHE_ENSINAMENTOS_TTL
    ):
        return _cache_ensinamentos

    try:
        resposta = requests.get(
            f"{BACKEND_URL}/chat/teachings/approved",
            timeout=8,
        )

        if resposta.status_code == 200:
            dados = resposta.json()
            if isinstance(dados, list):
                _cache_ensinamentos = dados
                _cache_ensinamentos_em = agora
                return dados

        print(
            f"[ChefBot] Erro ao buscar conhecimentos aprovados: "
            f"HTTP {resposta.status_code}"
        )
    except requests.exceptions.RequestException as erro:
        print(f"[ChefBot] Base de conhecimento indisponível: {erro}")

    return []


def buscar_ensinamento_relevante(mensagem, intencao):
    """Busca conhecimento global com regras conservadoras.

    Exato sempre pode entrar.
    Similaridade parcial só é aceita para PERGUNTA e quando a frase
    cadastrada é claramente uma extensão/subconjunto da pergunta atual.
    Isso evita arrastar uma receita ou assunto antigo para outra conversa.
    """
    alvo = normalizar_texto(mensagem)
    if not alvo:
        return None

    ensinamentos = buscar_ensinamentos_aprovados()

    # 1) Correspondência exata.
    for item in ensinamentos:
        pergunta = normalizar_texto(item.get("pergunta", ""))
        if pergunta and pergunta == alvo:
            return item

    # 2) Correspondência conservadora para dúvidas culinárias.
    if intencao != "PERGUNTA":
        return None

    alvo_tokens = tokens_importantes(alvo)
    if len(alvo_tokens) < 2:
        return None

    melhor = None
    melhor_score = 0.0

    for item in ensinamentos:
        pergunta = normalizar_texto(item.get("pergunta", ""))
        tokens_pergunta = tokens_importantes(pergunta)

        if len(tokens_pergunta) < 2:
            continue

        intersecao = len(alvo_tokens & tokens_pergunta)
        if intersecao < 2:
            continue

        # Caso uma pergunta seja claramente uma versão mais detalhada da outra.
        if tokens_pergunta.issubset(alvo_tokens) or alvo_tokens.issubset(tokens_pergunta):
            score = intersecao / max(len(alvo_tokens), len(tokens_pergunta))
            if score >= 0.65 and score > melhor_score:
                melhor = item
                melhor_score = score

    return melhor


def contar_ocorrencias_pergunta(historico, mensagem):
    alvo = normalizar_texto(mensagem)
    return sum(
        1
        for item in historico
        if normalizar_texto(item.get("mensagem", "")) == alvo
    )


TERMOS_NAO_APRENDER_GLOBALMENTE = [
    "alergia", "alergico", "alergica", "intolerancia", "intolerante",
    "diabetes", "doenca", "doença", "remedio", "remédio", "medicacao",
    "medicação", "medicamento", "celiaco", "celíaco", "pressao alta",
    "pressão alta", "pressao baixa", "pressão baixa",
]


def pode_aprender_globalmente(mensagem, intencao, resposta):
    if intencao != "PERGUNTA":
        return False

    texto = normalizar_texto(mensagem)

    if any(contem_termo(texto, termo) for termo in TERMOS_NAO_APRENDER_GLOBALMENTE):
        return False

    resposta_normalizada = normalizar_texto(resposta)
    if len(resposta_normalizada) < 30:
        return False

    if len(resposta_normalizada) > 5000:
        return False

    return True


def avaliar_resposta_para_ensino(mensagem, resposta):
    """Validação automática antes de transformar uma resposta em conhecimento.

    O avaliador é usado apenas quando a mesma pergunta já apareceu várias vezes.
    Ele precisa responder um JSON simples. Se a validação falhar, o conhecimento
    NÃO é salvo automaticamente.
    """
    avaliacao_prompt = f"""
Você é um revisor interno do ChefBot.

Avalie a resposta abaixo ANTES que ela vire conhecimento permanente.

Pergunta do usuário:
{mensagem}

Resposta do ChefBot:
{resposta}

Critérios obrigatórios:
1. O assunto é culinário.
2. A resposta realmente responde à pergunta.
3. Não há mistura de outro idioma.
4. Não há invenção evidente de contexto pessoal.
5. Não há instruções perigosas ou absurdas.
6. A resposta está razoavelmente clara.

Responda SOMENTE em JSON válido:
{{"aprovar": true, "motivo": "..."}}
ou
{{"aprovar": false, "motivo": "..."}}
"""

    messages = [
        {
            "role": "system",
            "content": (
                "Você é um avaliador culinário interno. "
                "Não reescreva a resposta. Apenas avalie. "
                "Responda somente com JSON válido."
            ),
        },
        {"role": "user", "content": avaliacao_prompt},
    ]

    try:
        texto = chamar_ollama(
            messages,
            "PERGUNTA",
            num_predict=180,
            temperature=0.10,
        )

        trecho = texto.strip()
        inicio = trecho.find("{")
        fim = trecho.rfind("}")

        if inicio < 0 or fim <= inicio:
            return False, "avaliador não retornou JSON"

        dados = json.loads(trecho[inicio:fim + 1])
        aprovado = bool(dados.get("aprovar", False))
        motivo = str(dados.get("motivo", ""))
        return aprovado, motivo

    except Exception as erro:
        print(f"[ChefBot] Falha na validação do ensinamento: {erro}")
        return False, "falha na validação"


def criar_ensinamento_automaticamente(email, mensagem, resposta, intencao, historico):
    """Aprendizado global por repetição + validação.

    Importante: isso não altera os pesos do modelo. Ele cria uma memória
    de conhecimento no backend, para reutilização nas próximas conversas.
    """
    if not pode_aprender_globalmente(mensagem, intencao, resposta):
        return

    ocorrencias = contar_ocorrencias_pergunta(historico, mensagem)
    print(f"[ChefBot] Frequência da pergunta: {ocorrencias}")

    if ocorrencias < LIMITE_FREQUENCIA:
        return

    alvo = normalizar_texto(mensagem)

    try:
        resposta_busca = requests.get(
            f"{BACKEND_URL}/chat/teachings",
            timeout=8,
        )
        if resposta_busca.status_code == 200:
            todos = resposta_busca.json()
            if isinstance(todos, list):
                for item in todos:
                    if normalizar_texto(item.get("pergunta", "")) == alvo:
                        return
    except requests.exceptions.RequestException as erro:
        print(f"[ChefBot] Não foi possível verificar conhecimentos existentes: {erro}")
        return

    aprovado, motivo = avaliar_resposta_para_ensino(mensagem, resposta)
    print(f"[ChefBot] Validação do conhecimento: {aprovado} — {motivo}")

    if not aprovado:
        return

    dados = {
        "pergunta": mensagem,
        "resposta": resposta,
        "categoria": "pergunta",
        "aprovado": True,
    }

    try:
        resposta_backend = requests.post(
            f"{BACKEND_URL}/chat/teachings",
            json=dados,
            timeout=8,
        )

        if resposta_backend.status_code in [200, 201]:
            invalidar_cache_ensinamentos()
            print("[ChefBot] ⭐ Novo conhecimento aprovado e salvo automaticamente.")
        else:
            print(
                "[ChefBot] Erro ao salvar novo conhecimento:",
                resposta_backend.status_code,
                resposta_backend.text,
            )
    except requests.exceptions.RequestException as erro:
        print(f"[ChefBot] Erro ao registrar conhecimento: {erro}")


# ============================================================
# PERFIL
# ============================================================

def normalizar_nivel(valor):
    valor = normalizar_texto(valor)
    mapa = {
        "intermediário": "intermediario",
        "avançado": "avancado",
    }
    return mapa.get(valor, valor)


def montar_contexto_usuario(preferencias):
    if not preferencias:
        return "PERFIL DO USUÁRIO: nenhum perfil cadastrado."

    return f"""PERFIL DO USUÁRIO:
- Tempo para cozinhar: {preferencias.get('tempoCozinhar', 'não informado')}
- Habilidade culinária: {preferencias.get('habilidade', 'não informado')}
- Orçamento: {preferencias.get('orcamento', 'não informado')}
- Preferência de sabor: {preferencias.get('preferenciaSabor', 'não informado')}
- Experimentar novos pratos: {preferencias.get('experimentarNovos', 'não informado')}
- Estilo de receita: {preferencias.get('styleReceita', 'não informado')}
- Culinária favorita: {preferencias.get('culinariaFavorita', 'não informado')}
- Dieta: {preferencias.get('dieta', 'não informado')}
- Objetivo alimentar: {preferencias.get('objetivoAlimentar', 'não informado')}
- Paladar: {preferencias.get('paladar', 'não informado')}
- Alergias: {preferencias.get('alergias', 'não informado')}

REGRAS DO PERFIL:
- Use o perfil somente quando ele tiver relação direta com o pedido atual.
- Nunca mencione banco de dados, backend ou mecanismo interno.
- Nunca invente uma preferência que não esteja aqui.
- Respeite alergias e restrições quando forem relevantes.
"""


# ============================================================
# CONTEXTO ANTERIOR — SOMENTE REFERÊNCIA EXPLÍCITA
# ============================================================

TERMOS_DE_REFERENCIA = {
    "essa", "esse", "isso", "isto", "aquela", "aquele", "anterior",
    "anteriores", "opcao", "opção", "sugestao", "sugestão", "receita",
    "primeira", "primeiro", "segunda", "segundo", "terceira", "terceiro",
    "quarta", "quarto", "quinta", "quinto", "ultima", "última",
    "que voce falou", "que você falou", "que voce sugeriu", "que você sugeriu",
    "que voce disse", "que você disse",
}


def precisa_de_contexto_anterior(mensagem):
    texto = normalizar_texto(mensagem)
    tokens = set(tokenizar(texto))

    if tokens & TERMOS_DE_REFERENCIA:
        return True

    return any(
        frase in texto
        for frase in [
            "da primeira", "da segunda", "da terceira", "da quarta",
            "da quinta", "da ultima", "da última", "dessa receita",
            "desse prato", "essa receita", "esse prato", "aquela receita",
            "aquele prato", "que voce sugeriu", "que você sugeriu",
        ]
    )


def limpar_titulo(titulo):
    """'**Brigadeiro** (20 min) — doce...' -> 'Brigadeiro'."""
    titulo = str(titulo or "")
    titulo = re.split(r"\s+[—–]\s+", titulo)[0]
    titulo = titulo.replace("*", "")
    titulo = re.sub(r"\s*\([^)]*\)\s*$", "", titulo)
    return titulo.strip(" -•:")


def extrair_titulo_receita(resposta):
    for linha_bruta in str(resposta).splitlines():
        m = re.match(r"^\s*🍳\s*\*\*(.+?)\*\*", linha_bruta)
        if m:
            return m.group(1).strip()
        if linha_bruta.strip():
            break

    linhas = [linha.strip(" -*•:") for linha in str(resposta).splitlines() if linha.strip()]

    for i, linha in enumerate(linhas):
        normal = normalizar_texto(linha)
        if normal.startswith("🍳 receita"):
            if i + 1 < len(linhas):
                proxima = linhas[i + 1].strip(" -*•:")
                if proxima:
                    return proxima

        if "receita:" in normal and len(linha) < 60:
            resto = linha.split(":", 1)[1].strip()
            if resto:
                return resto

    return ""


def extrair_sugestoes_de_historico_item(item):
    if item.get("intencao") not in ["SUGESTÃO", "NOVAS_SUGESTÕES"]:
        return []

    resposta = str(item.get("resposta", ""))
    resultado = []

    for linha in resposta.splitlines():
        linha = linha.strip()
        if not linha:
            continue

        nome, descricao, tempo = parsear_linha_sugestao(linha)
        if not nome:
            continue

        if any(nome.startswith(prefixo) for prefixo in [
            "🍽️", "algumas ", "outras ", "qual ", "aqui ", "claro"
        ]):
            continue

        if all(not nomes_representam_mesma_receita(nome, antigo) for antigo in resultado):
            resultado.append(nome)

    return resultado


def obter_ultima_lista_de_sugestoes(historico):
    for item in historico:  # mais recente primeiro
        receitas = extrair_sugestoes_de_historico_item(item)
        if receitas:
            return receitas
    return []


def resolver_referencia_receita(mensagem, historico):
    """Resolve 'a primeira', 'essa receita', 'quero essa' etc. usando o histórico.

    Retorna o título limpo da receita, ou None quando não dá para saber
    (ex.: 'essa' logo depois de uma lista com várias opções).
    """
    texto = normalizar_texto(mensagem)
    tem_pronome = re.search(r"(?<!\w)(essa|esse|essa mesma|esse mesmo|ela)(?!\w)", texto)

    tem_numero = re.search(r"(?:opcao|numero|a|o)?\s*\d\s*$", texto) and identificar_pedido_de_fazer(mensagem)

    if not precisa_de_contexto_anterior(mensagem) and not tem_pronome and not tem_numero:
        return None

    lista = [limpar_titulo(t) for t in obter_ultima_lista_de_sugestoes(historico)]

    ordens = {
        "primeira": 0, "primeiro": 0, "segunda": 1, "segundo": 1,
        "terceira": 2, "terceiro": 2, "quarta": 3, "quarto": 3,
        "quinta": 4, "quinto": 4,
    }
    for palavra, indice in ordens.items():
        if re.search(rf"(?<!\w){palavra}(?!\w)", texto) and indice < len(lista):
            return lista[indice]

    # Número digitado: "quero a 2", "opção 3"
    m = re.search(r"(?:opcao|numero|n|a|o)?\s*(\d)\s*$", texto)
    if m and 0 < int(m.group(1)) <= len(lista):
        return lista[int(m.group(1)) - 1]

    # Última interação foi uma receita completa -> "essa receita" = ela.
    for item in historico:  # mais recente primeiro
        if item.get("intencao") == "RECEITA":
            titulo = extrair_titulo_receita(item.get("resposta", ""))
            if titulo:
                return titulo
            break
        if item.get("intencao") in ("SUGESTÃO", "NOVAS_SUGESTÕES"):
            break

    # Só uma opção na última lista -> não há ambiguidade.
    if len(lista) == 1:
        return lista[0]

    return None


def montar_contexto_de_referencia(receita_referenciada):
    if not receita_referenciada:
        return ""

    return f"""REFERÊNCIA EXPLÍCITA DO USUÁRIO:
O usuário está se referindo especificamente à receita: {receita_referenciada}

Use SOMENTE essa receita como referência.
Não importe ingredientes, assuntos ou objetivos de outras conversas.
"""


# ============================================================
# REFERÊNCIAS EXTERNAS — TUDO GOSTOSO
# ============================================================

def obter_ultima_consulta_de_sugestao(historico):
    for item in historico:  # mais recente primeiro
        if item.get("intencao") in ["SUGESTÃO", "NOVAS_SUGESTÕES"]:
            mensagem = str(item.get("mensagem", "")).strip()
            # "me dá mais opções" não é uma consulta: continua procurando a original.
            if mensagem and not identificar_mais_opcoes(mensagem):
                return mensagem
    return ""


def consulta_para_sugestoes(mensagem, intencao, historico):
    if intencao == "NOVAS_SUGESTÕES":
        base = obter_ultima_consulta_de_sugestao(historico)
        if base:
            return base
    return mensagem


def buscar_referencias_para_sugestoes(mensagem, intencao, historico, limite=30):
    consulta = consulta_para_sugestoes(mensagem, intencao, historico)
    if not consulta:
        return []

    return buscar_referencias_culinarias(
        consulta,
        limite=limite,
        detalhar=False,
        somente_receitas=True,
    )


def selecionar_referencias_para_sugestoes(referencias, quantidade, proibidas, preferencias, mensagem):
    """Seleciona apenas referências reais. O modelo não cria nomes."""
    candidatos = []
    termos_pedido = tokens_importantes(mensagem)

    for item in referencias:
        titulo = str(item.get("titulo") or item.get("titulo_busca") or "").strip()
        if not titulo:
            continue
        if any(nomes_representam_mesma_receita(titulo, nome) for nome in proibidas):
            continue

        texto_busca = tokens_importantes(titulo)
        inter = len(termos_pedido & texto_busca)
        score = inter / max(len(termos_pedido), 1)
        # Ingrediente detectado no pedido aparece no título/descrição -> bônus.
        descricao = tokens_importantes(str(item.get("descricao") or ""))
        if termos_pedido & descricao:
            score += 0.20
        if item.get("tipo") == "themealdb":
            score += 0.05

        candidatos.append((score, titulo, item))

    candidatos.sort(key=lambda x: (-x[0], normalizar_texto(x[1])))

    selecionados = []
    nomes = []
    for _, titulo, item in candidatos:
        if any(nomes_representam_mesma_receita(titulo, nome) for nome in nomes):
            continue
        selecionados.append(item)
        nomes.append(titulo)
        if len(selecionados) >= quantidade:
            break

    return selecionados


def enriquecer_referencias_selecionadas(referencias):
    return [detalhar_referencia(dict(item)) for item in referencias]


def montar_contexto_referencias_web(referencias, incluir_receita_completa=False):
    if not referencias:
        return ""

    blocos = []
    for i, item in enumerate(referencias, 1):
        titulo = item.get("titulo") or item.get("titulo_busca") or "Referência"
        bloco = [
            f"REFERÊNCIA {i}: {titulo}",
            f"FONTE: {item.get('fonte', 'Fonte culinária')}",
            f"URL: {item.get('url', '')}",
        ]

        descricao = str(item.get("descricao") or "").strip()
        if descricao:
            bloco.append(f"DESCRIÇÃO: {descricao[:1000]}")

        if incluir_receita_completa:
            ingredientes = item.get("ingredientes") or []
            instrucoes = item.get("instrucoes") or []
            if ingredientes:
                bloco.append("INGREDIENTES DA FONTE:\n- " + "\n- ".join(ingredientes[:50]))
            if instrucoes:
                bloco.append("INSTRUÇÕES DA FONTE:\n" + "\n".join(f"{n+1}. {texto}" for n, texto in enumerate(instrucoes[:30])))

        blocos.append("\n".join(bloco))

    return "\n\n".join(blocos)


def buscar_referencia_receita_web(nome_receita):
    if not nome_receita:
        return None

    referencias = buscar_referencia_receita(nome_receita, limite=8)
    if not referencias:
        return None

    alvo = normalizar_texto(nome_receita)
    for item in referencias:
        titulo = normalizar_texto(item.get("titulo") or item.get("titulo_busca") or "")
        if titulo == alvo:
            return item

    for item in referencias:
        titulo = normalizar_texto(item.get("titulo") or item.get("titulo_busca") or "")
        if titulo and (alvo in titulo or titulo in alvo):
            return item

    return referencias[0]


# ============================================================
# INTENÇÃO
# ============================================================

def identificar_mais_opcoes(mensagem):
    texto = normalizar_texto(mensagem)
    frases_exatas = {
        "mais", "mais opcoes", "mais opções", "outras opcoes", "outras opções",
        "mais ideias", "mais sugestoes", "mais sugestões", "quero mais",
        "quero mais opcoes", "quero mais opções", "quero outras opções",
        "quero outras opcoes", "me de mais opcoes", "me dê mais opções",
        "me da mais sugestoes", "me dá mais sugestões", "me de mais sugestoes",
        "me dê mais sugestões", "me da mais sugestoes", "me dá mais sugestões",
        "tem mais", "tem mais opcoes", "tem mais opções",
    }

    if texto in {normalizar_texto(x) for x in frases_exatas}:
        return True

    return texto.startswith((
        "me de mais ", "me dê mais ", "me da mais ", "me dá mais ",
        "quero mais ", "quero outras ", "me de outras ", "me dê outras ",
        "me da outras ", "me dá outras ",
    ))


def identificar_sugestao(mensagem):
    texto = normalizar_texto(mensagem)

    frases = [
        "quero uma sugestao", "quero sugestoes", "me de sugestoes",
        "me da sugestoes", "me dê sugestões", "me de uma sugestao",
        "me da uma sugestao", "me dê uma sugestão", "quero uma ideia",
        "quero ideias", "me de ideias", "me da ideias", "me dê ideias",
        "o que posso cozinhar", "o que eu posso cozinhar",
        "quero algo doce", "queria algo doce", "quero algo salgado",
        "queria algo salgado", "ideia para jantar", "ideias para jantar",
        "o que fazer para jantar", "ideia de sobremesa", "ideias de sobremesa",
        "o que posso fazer de sobremesa", "me sugira uma receita",
        "me sugira receitas", "sugira uma receita", "sugira receitas",
        "quero fazer algo", "queria fazer algo", "vamos fazer algo",
        "quero cozinhar algo", "fazer alguma coisa", "quero fazer alguma coisa",
        "quero preparar algo", "quero preparar alguma coisa",
    ]

    return any(frase in texto for frase in frases)


def identificar_receita(mensagem):
    texto = normalizar_texto(mensagem)
    frases = [
        "me passe a receita", "me passa a receita", "passa a receita",
        "passe a receita", "quero a receita", "me de a receita",
        "me da a receita", "receita do ", "receita da ", "receita de ",
        "como faco", "como fazer", "me ensine a fazer", "me ensina a fazer",
        "modo de preparo", "ingredientes do ", "ingredientes da ",
        "quais os ingredientes", "quais sao os ingredientes",
    ]
    if any(frase in texto for frase in frases):
        return True

    # "quero fazer brigadeiro", "vamos fazer essa", "quero a primeira"...
    return identificar_pedido_de_fazer(mensagem) and not identificar_sugestao(mensagem)


VERBOS_PEDIDO_FAZER = [
    "quero fazer", "queria fazer", "gostaria de fazer", "vou fazer", "vamos fazer",
    "bora fazer", "pretendo fazer", "quero preparar", "queria preparar",
    "gostaria de preparar", "vou preparar", "vamos preparar", "quero cozinhar",
    "vou cozinhar", "vamos cozinhar", "me passa o", "me passa a", "me passe o",
    "me passe a", "me manda o", "me manda a", "me mostra o", "me mostra a",
    "me ensina o", "me ensina a", "me ensine o", "me ensine a",
    "quero essa", "quero esse", "quero a primeira", "quero a segunda",
    "quero a terceira", "quero a quarta", "quero a quinta", "quero o primeiro",
    "quero o segundo", "quero o terceiro", "quero o quarto", "quero o quinto",
    "vou de", "pode ser a", "pode ser o", "essa mesma", "esse mesmo",
    "essa mesmo", "vamos nessa", "quero a opcao", "quero o numero", "quero a numero",
]


def identificar_pedido_de_fazer(mensagem):
    texto = normalizar_texto(mensagem)
    if re.search(r"(?<!\w)(quero|vou de|pode ser)\s+(a|o)?\s*(opcao|numero)?\s*\d\s*$", texto):
        return True
    return any(re.search(rf"(?<!\w){re.escape(normalizar_texto(v))}", texto) for v in VERBOS_PEDIDO_FAZER)


_INTENCOES_SUGESTAO = ("SUGESTÃO", "NOVAS_SUGESTÕES")


def sessao_de_sugestao_recente(historico, janela=4):
    """True se uma das últimas mensagens foi um pedido de sugestão (sem receita no meio).

    `historico` vem do mais recente para o mais antigo.
    """
    for item in (historico or [])[:janela]:
        intencao = str(item.get("intencao", ""))
        if intencao in _INTENCOES_SUGESTAO:
            return True
        if intencao == "RECEITA":
            return False
    return False


def identificar_intencao(mensagem, historico=None):
    if identificar_mais_opcoes(mensagem):
        return "NOVAS_SUGESTÕES"
    # "quero algo doce", "receita com ovos, farinha e leite sendo doce"...
    if e_pedido_de_sugestao_filtrada(mensagem):
        return "SUGESTÃO"
    # "e coisas fritas?", "na verdade quero salgado": continua o pedido anterior
    if historico and sessao_de_sugestao_recente(historico) and e_refinamento(mensagem):
        return "SUGESTÃO"
    if identificar_receita(mensagem):
        return "RECEITA"
    if identificar_sugestao(mensagem):
        return "SUGESTÃO"
    return "PERGUNTA"


# ============================================================
# FORA DA CULINÁRIA / RESPOSTAS LOCAIS
# ============================================================

def obter_termos_fora():
    if isinstance(palavras_fora, list):
        return palavras_fora

    termos = []
    if isinstance(palavras_fora, dict):
        for lista in palavras_fora.values():
            if isinstance(lista, list):
                termos.extend(lista)
    return termos


def verificar_palavra_fora(mensagem):
    return any(contem_termo(mensagem, termo) for termo in obter_termos_fora())


def resposta_fora_deterministica(mensagem):
    if isinstance(respostas_fora, list) and respostas_fora:
        indice = int(hashlib.sha256(normalizar_texto(mensagem).encode("utf-8")).hexdigest(), 16)
        return respostas_fora[indice % len(respostas_fora)]

    if isinstance(respostas_fora, dict):
        for chave, resposta in respostas_fora.items():
            if contem_termo(mensagem, chave):
                return resposta

    return (
        "🍳 Eu sou o ChefBot e meu território é a cozinha. "
        "Pergunte sobre receitas, ingredientes, técnicas ou preparo."
    )


_base_conhecimento = BaseDeConhecimento(respostas_locais)
_base_conhecimento_mtime = (
    os.path.getmtime(CAMINHO_RESPOSTAS_LOCAIS)
    if os.path.exists(CAMINHO_RESPOSTAS_LOCAIS) else 0.0
)


def _recarregar_respostas_locais_se_mudou():
    """Editou o respostas_locais.json? Vale na próxima mensagem, sem reiniciar o Flask."""
    global respostas_locais, _base_conhecimento, _base_conhecimento_mtime
    try:
        mtime = os.path.getmtime(CAMINHO_RESPOSTAS_LOCAIS)
    except OSError:
        return
    if mtime != _base_conhecimento_mtime:
        respostas_locais = carregar_json(CAMINHO_RESPOSTAS_LOCAIS)
        _base_conhecimento = BaseDeConhecimento(respostas_locais)
        _base_conhecimento_mtime = mtime
        print("[ChefBot] respostas_locais.json recarregado.")


def buscar_resposta_local(mensagem, chave_usuario=""):
    """Resposta instantânea (casual + conhecimento local), tolerante a erros de digitação.

    Retorna um RespostaLocal (texto, expressao, origem, chave) ou None.
    """
    _recarregar_respostas_locais_se_mudou()
    return responder_local(mensagem, _base_conhecimento, chave_usuario)


def buscar_resposta_fora(mensagem):
    return resposta_fora_deterministica(mensagem)


def salvar_historico_em_segundo_plano(email, mensagem, resposta, intencao):
    """Salvar no MySQL não pode atrasar a resposta local."""
    threading.Thread(
        target=salvar_historico_usuario,
        args=(email, mensagem, resposta, intencao),
        daemon=True,
    ).start()


def precisa_de_referencia_web(mensagem, intencao, historico=None):
    if intencao not in {"PERGUNTA", "RECEITA"}:
        return False
    return parece_pedido_culinario(mensagem, intencao, historico)


# ============================================================
# OLLAMA
# ============================================================

def chamar_ollama(messages, intencao, num_predict=None, temperature=None):
    opcoes = {
        "temperature": 0.40 if temperature is None else temperature,
        "repeat_penalty": 1.20,
        "repeat_last_n": 128,
        "top_p": 0.90,
        "top_k": 40,
        "num_ctx": NUM_CTX,
        "num_predict": num_predict or (750 if intencao == "RECEITA" else 450),
    }

    resposta = requests.post(
        OLLAMA_URL,
        json={
            "model": MODELO,
            "messages": messages,
            "stream": False,
            "options": opcoes,
        },
        timeout=300,
    )
    resposta.raise_for_status()
    dados = resposta.json()
    return str(dados.get("message", {}).get("content", "")).strip()


EXPRESSOES_FACIAIS = {
    "NEUTRO", "FELIZ", "TRISTE", "BRAVO", "APAIXONADO", "ERRO", "SUSTO"
}
PADRAO_EXPRESSAO_FACIAL = re.compile(
    r"\[\[BITEBYTE_FACE:(NEUTRO|FELIZ|TRISTE|BRAVO|APAIXONADO|ERRO|SUSTO)\]\]",
    re.IGNORECASE,
)


def classificar_expressao_fallback(mensagem="", resposta="", falha=False):
    """Fallback para respostas locais e modelos que não emitirem o marcador."""
    if falha:
        return "ERRO"

    texto = normalizar_texto(f"{mensagem or ''} {resposta or ''}")

    # Situações empáticas têm prioridade sobre sinais positivos.
    if re.search(
        r"\b(sinto muito|lamento|que pena|triste|frustrad|deu errado|nao deu certo|queimou|estragou|perdeu|dificil|complicad)\b",
        texto,
    ):
        return "TRISTE"

    if re.search(r"\b(que raiva|absurdo|injusto|indignad|irritad)\b", texto):
        return "BRAVO"

    if re.search(
        r"\b(uau|caramba|inacreditavel|surpreendente|surpresa|nao esperava|impressionante)\b",
        texto,
    ):
        return "SUSTO"

    if re.search(
        r"\b(apaixonad|amo|adoro|delicia|delicioso|maravilhoso|perfeito|sensacional)\b",
        texto,
    ):
        return "APAIXONADO"

    if re.search(
        r"\b(oi|ola|bom dia|boa tarde|boa noite|obrigad|valeu|obrigad\w*|parabens|conseguimos|excelente|muito bom|feliz|adorei|com prazer|que bom)\b|[😊😁😄😂❤💙🥰🎉]",
        texto,
    ):
        return "FELIZ"

    return "NEUTRO"


def _evento_sse(dados):
    return "data: " + json.dumps(dados, ensure_ascii=False) + "\n\n"


def stream_resposta(messages, intencao, mensagem_usuario=""):
    try:
        resposta = requests.post(
            OLLAMA_URL,
            json={
                "model": MODELO,
                "messages": messages,
                "stream": True,
                "options": {
                    "temperature": 0.40,
                    "repeat_penalty": 1.20,
                    "repeat_last_n": 128,
                    "top_p": 0.90,
                    "top_k": 40,
                    "num_ctx": NUM_CTX,
                    "num_predict": 750 if intencao == "RECEITA" else 500,
                },
            },
            stream=True,
            timeout=300,
        )

        if resposta.status_code != 200:
            yield _evento_sse({"expressao": "ERRO"})
            yield _evento_sse({"error": f"Erro no Ollama: {resposta.text}"})
            return

        texto_completo = ""
        prefixo_pendente = ""
        expressao_enviada = False
        limite_prefixo = 240

        for linha in resposta.iter_lines():
            if not linha:
                continue

            try:
                conteudo = json.loads(linha.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue

            token = conteudo.get("message", {}).get("content", "")
            if token:
                if not expressao_enviada:
                    prefixo_pendente += token
                    marcador = PADRAO_EXPRESSAO_FACIAL.search(prefixo_pendente)

                    if marcador:
                        expressao = marcador.group(1).upper()
                        yield _evento_sse({"expressao": expressao})
                        # O marcador e apenas espaços/quebras antes dele são internos.
                        antes = prefixo_pendente[:marcador.start()]
                        depois = prefixo_pendente[marcador.end():]
                        texto_visivel = (antes + depois).lstrip("\r\n\t ")
                        if texto_visivel:
                            texto_completo += texto_visivel
                            yield _evento_sse({"token": texto_visivel})
                        prefixo_pendente = ""
                        expressao_enviada = True

                    elif len(prefixo_pendente) >= limite_prefixo:
                        expressao = classificar_expressao_fallback(
                            mensagem_usuario, prefixo_pendente
                        )
                        yield _evento_sse({"expressao": expressao})
                        texto_completo += prefixo_pendente
                        yield _evento_sse({"token": prefixo_pendente})
                        prefixo_pendente = ""
                        expressao_enviada = True

                else:
                    # Proteção adicional: marcadores repetidos nunca aparecem no chat.
                    texto_visivel = PADRAO_EXPRESSAO_FACIAL.sub("", token)
                    if texto_visivel:
                        texto_completo += texto_visivel
                        yield _evento_sse({"token": texto_visivel})

            if conteudo.get("done"):
                break

        if not expressao_enviada:
            expressao = classificar_expressao_fallback(
                mensagem_usuario, prefixo_pendente
            )
            yield _evento_sse({"expressao": expressao})
            if prefixo_pendente:
                # Remove marcador caso o modelo o tenha emitido sem completar
                # a sequência no mesmo fragmento/token.
                texto_visivel = PADRAO_EXPRESSAO_FACIAL.sub("", prefixo_pendente).strip()
                if texto_visivel:
                    texto_completo += texto_visivel
                    yield _evento_sse({"token": texto_visivel})

        yield _evento_sse({"done": True})
        yield _evento_sse({"historico": texto_completo})

    except requests.exceptions.ConnectionError:
        yield _evento_sse({"expressao": "ERRO"})
        yield _evento_sse({
            "error": "Não foi possível conectar ao Ollama. Verifique se ele está aberto."
        })
    except requests.exceptions.RequestException as erro:
        yield _evento_sse({"expressao": "ERRO"})
        yield _evento_sse({"error": f"Erro de comunicação com o Ollama: {erro}"})
    except Exception as erro:
        yield _evento_sse({"expressao": "ERRO"})
        yield _evento_sse({"error": str(erro)})


def stream_local(resposta, mensagem_usuario="", expressao=None):
    """Entrega respostas determinísticas com o mesmo contrato facial da IA."""
    face = expressao or classificar_expressao_fallback(mensagem_usuario, resposta)
    yield _evento_sse({"expressao": face})
    yield _evento_sse({"token": resposta})
    yield _evento_sse({"done": True})
    yield _evento_sse({"historico": resposta})


# ============================================================
# SUGESTÕES — GARANTIA DE 5 / 10 E SEM REPETIÇÃO
# ============================================================

def parsear_linha_sugestao(linha):
    linha = linha.strip()
    if not linha:
        return "", "", ""

    linha = re.sub(r"^\s*(?:[-•*]|\d+[.)-])\s*", "", linha)

    partes = [parte.strip() for parte in linha.split("||")]
    if len(partes) >= 2:
        nome = partes[0].strip(" -—:")
        descricao = partes[1].strip()
        tempo = partes[2].strip() if len(partes) >= 3 else ""
        return nome, descricao, tempo

    # Fallback para o formato natural "Nome — descrição (X min)".
    if "—" in linha:
        nome, resto = linha.split("—", 1)
        nome = nome.strip(" -:")
        resto = resto.strip()
        tempo = ""
        match = re.search(r"\(([^)]*(?:min|minutos|h|horas)[^)]*)\)", resto, re.I)
        if match:
            tempo = match.group(1).strip()
            resto = resto[:match.start()].strip(" -")
        return nome, resto, tempo

    return "", "", ""


def extrair_sugestoes_da_resposta(resposta):
    """Lê as listas de sugestões salvas no histórico, inclusive o novo formato."""
    itens = []
    atual = None

    for linha_bruta in str(resposta).splitlines():
        linha = linha_bruta.strip()
        if not linha:
            continue

        # Novo formato:
        # 1. **Título**
        m_titulo = re.match(r"^\s*\d+[.)-]\s*\*\*(.+?)\*\*\s*$", linha)
        if m_titulo:
            nome = m_titulo.group(1).strip()
            if nome and len(nome.split()) <= 10:
                atual = {"nome": nome, "descricao": "", "tempo": ""}
                if not any(
                    nomes_representam_mesma_receita(nome, antigo["nome"])
                    for antigo in itens
                ):
                    itens.append(atual)
                else:
                    atual = None
            continue

        if atual:
            m_resumo = re.match(r"^\*\*Resumo:\*\*\s*(.+)$", linha, re.I)
            if m_resumo:
                atual["descricao"] = m_resumo.group(1).strip()
                continue

            m_tempo = re.match(r"^\*\*Tempo:\*\*\s*(.+)$", linha, re.I)
            if m_tempo:
                atual["tempo"] = m_tempo.group(1).strip()
                continue

        # Compatibilidade com o formato antigo:
        # 1. Nome — descrição (tempo)
        nome, descricao, tempo = parsear_linha_sugestao(linha)
        if not nome or len(nome.split()) > 10:
            continue

        nome = nome.replace("**", "").strip()
        if normalizar_texto(nome).startswith((
            "algumas ideias", "outras ideias", "outras opcoes", "outras sugestoes",
            "qual dessas", "aqui estao", "claro", "sugestoes",
        )):
            continue

        if any(nomes_representam_mesma_receita(nome, antigo["nome"]) for antigo in itens):
            continue

        itens.append({
            "nome": nome,
            "descricao": descricao or "Uma opção culinária para variar o cardápio.",
            "tempo": tempo or "tempo variável",
        })

    return itens



def obter_sugestoes_anteriores(historico):
    """Extrai os nomes das receitas já sugeridas no histórico.

    A função é usada exclusivamente para impedir repetições entre listas
    de sugestões. Ela entende o formato atual do ChefBot e alguns formatos
    anteriores para manter compatibilidade com o histórico já salvo.
    """
    if not isinstance(historico, list) or not historico:
        return []

    nomes = []

    for item in historico:
        if not isinstance(item, dict):
            continue

        intencao = normalizar_texto(item.get("intencao", ""))
        if intencao not in {
            normalizar_texto("SUGESTÃO"),
            normalizar_texto("NOVAS_SUGESTÕES"),
        }:
            continue

        resposta = str(item.get("resposta", ""))
        if not resposta.strip():
            continue

        # Primeiro, usa o parser oficial das sugestões do sistema.
        itens = extrair_sugestoes_da_resposta(resposta)

        for sugestao in itens:
            nome = str(sugestao.get("nome", "")).strip()
            if not nome:
                continue

            if not any(nomes_representam_mesma_receita(nome, antigo) for antigo in nomes):
                nomes.append(nome)

        # Compatibilidade com formatos antigos que não possuíam "—".
        if not itens:
            for linha in resposta.splitlines():
                linha = linha.strip()
                if not linha:
                    continue

                if normalizar_texto(linha).startswith((
                    "🍽️", "qual dessas", "fontes de referencia",
                    "fontes de referência", "fontes de referencia:",
                    "fontes de referência:",
                )):
                    continue

                match = re.match(r"^\s*(?:[-•*]|\d+[.)-])\s*(.+?)\s*$", linha)
                if not match:
                    continue

                nome = match.group(1).strip(" .,:;!?-")
                if "—" in nome:
                    nome = nome.split("—", 1)[0].strip()
                elif " - " in nome:
                    nome = nome.split(" - ", 1)[0].strip()

                if not nome or len(nome.split()) > 10:
                    continue

                nome_norm = normalizar_texto(nome)
                if nome_norm.startswith((
                    "algumas ideias", "outras ideias", "outras opcoes",
                    "outras sugestoes", "sugestoes", "sugestões",
                )):
                    continue

                if not any(nomes_representam_mesma_receita(nome, antigo) for antigo in nomes):
                    nomes.append(nome)

    return nomes


def gerar_sugestoes(mensagem, intencao, preferencias, historico):
    quantidade = 5 if intencao == "SUGESTÃO" else 10
    anteriores = obter_sugestoes_anteriores(historico)

    referencias = buscar_referencias_seguras(
        mensagem,
        intencao,
        historico,
        limite=max(30, quantidade * 4),
    )

    selecionadas = selecionar_referencias_para_sugestoes(
        referencias,
        quantidade,
        anteriores,
        preferencias,
        mensagem,
    )

    # Segunda tentativa com busca mais ampla, caso a primeira lista não tenha
    # encontrado candidatos suficientes sem repetir sugestões anteriores.
    if len(selecionadas) < quantidade:
        try:
            referencias_extra = buscar_referencias_culinarias(
                consulta_para_sugestoes(mensagem, intencao, historico),
                limite=50,
                detalhar=False,
                somente_receitas=True,
            ) if USAR_REFERENCIA_WEB else []
        except Exception as erro:
            print(f"[ChefBot] Falha ao buscar referências extra de sugestões: {erro}")
            referencias_extra = []

        existentes = {
            normalizar_texto(item.get("titulo") or item.get("titulo_busca", ""))
            for item in referencias
        }
        for item in referencias_extra:
            titulo = item.get("titulo") or item.get("titulo_busca") or ""
            if normalizar_texto(titulo) not in existentes:
                referencias.append(item)

        selecionadas = selecionar_referencias_para_sugestoes(
            referencias,
            quantidade,
            anteriores,
            preferencias,
            mensagem,
        )

    selecionadas = validar_sugestoes(selecionadas, quantidade, anteriores)
    if len(selecionadas) < quantidade:
        faltantes = quantidade - len(selecionadas)
        selecionadas.extend(preencher_sugestoes_fallback(faltantes, anteriores + [item.get("nome") for item in selecionadas]))
        selecionadas = validar_sugestoes(selecionadas, quantidade, anteriores)

    selecionadas = enriquecer_referencias_selecionadas(selecionadas[:quantidade])

    resultados = []
    for item in selecionadas:
        nome = item.get("titulo") or item.get("titulo_busca") or ""
        if not nome:
            continue
        descricao = str(item.get("descricao", "")).strip()
        if not descricao:
            descricao = "Receita encontrada na base de referência do TudoGostoso."
        resultados.append({
            "nome": nome,
            "descricao": descricao[:220],
            "tempo": item.get("tempo_preparo") or "",
            "fonte": item.get("fonte", "TudoGostoso"),
            "url": item.get("url", ""),
        })

    resultados = validar_sugestoes(resultados, quantidade, anteriores)
    if len(resultados) < quantidade:
        faltantes = quantidade - len(resultados)
        resultados.extend(preencher_sugestoes_fallback(faltantes, anteriores + [item.get("nome") for item in resultados]))
        resultados = validar_sugestoes(resultados, quantidade, anteriores)

    return resultados[:quantidade]


def formatar_sugestoes(sugestoes, quantidade):
    sugestoes = validar_sugestoes(sugestoes, quantidade)
    if len(sugestoes) < quantidade:
        return (
            "⚠️ Não encontrei referências confiáveis suficientes para entregar "
            f"{quantidade} sugestões novas sem inventar ou repetir receitas. "
            "Tente reformular o pedido ou pedir mais opções depois."
        )

    titulo = "🍽️ 5 sugestões:" if quantidade == 5 else "🍽️ 10 novas sugestões:"
    linhas = [titulo, ""]
    for item in sugestoes:
        tempo = f" ({item['tempo']})" if item.get("tempo") else ""
        linhas.append(f"- {item['nome']} — {item['descricao']}{tempo}")

    linhas.extend(["", "Qual dessas opções você gostaria de fazer?", "", "Fontes de referência:"])
    fontes = []
    for item in sugestoes:
        url = item.get("url", "")
        if url and url not in fontes:
            fontes.append(url)
    linhas.extend(f"- {url}" for url in fontes[:quantidade])
    return "\n".join(linhas)


# ============================================================
# SUGESTÕES — FALLBACK INTERNO CONTROLADO
# ============================================================

RECEITAS_FALLBACK = [
    {"nome": "Bolo de chocolate", "descricao": "clássico, intenso e muito popular para sobremesa.", "tempo": "45 min", "fonte": "conhecimento interno"},
    {"nome": "Torta de limão", "descricao": "refrescante, cítrica e com textura equilibrada.", "tempo": "60 min", "fonte": "conhecimento interno"},
    {"nome": "Arroz de forno", "descricao": "prático, saboroso e excelente para almoço em família.", "tempo": "50 min", "fonte": "conhecimento interno"},
    {"nome": "Frango ao molho de laranja", "descricao": "sabor suave, aromático e muito versátil.", "tempo": "40 min", "fonte": "conhecimento interno"},
    {"nome": "Pudim de leite", "descricao": "cremoso, clássico e perfeito para encerrar a refeição.", "tempo": "70 min", "fonte": "conhecimento interno"},
    {"nome": "Salada de quinoa", "descricao": "leve, nutritiva e ideal para refeições rápidas.", "tempo": "20 min", "fonte": "conhecimento interno"},
    {"nome": "Lasanha de carne", "descricao": "tradicional, reconfortante e muito bem aceita em reuniões.", "tempo": "75 min", "fonte": "conhecimento interno"},
    {"nome": "Mousse de maracujá", "descricao": "fresca, aerada e com sabor marcante.", "tempo": "30 min", "fonte": "conhecimento interno"},
    {"nome": "Feijoada", "descricao": "rica, encorpada e muito característica da culinária brasileira.", "tempo": "150 min", "fonte": "conhecimento interno"},
    {"nome": "Panqueca de carne", "descricao": "saboroso, prático e fácil de servir em família.", "tempo": "35 min", "fonte": "conhecimento interno"},
    {"nome": "Cuscuz paulista", "descricao": "saboroso, tradicional e ótimo para almoço ou jantar.", "tempo": "40 min", "fonte": "conhecimento interno"},
    {"nome": "Moqueca de peixe", "descricao": "refrescante, aromática e muito saborosa.", "tempo": "55 min", "fonte": "conhecimento interno"},
    {"nome": "Brownie", "descricao": "chocolate intenso, textura úmida e bem apreciado.", "tempo": "35 min", "fonte": "conhecimento interno"},
    {"nome": "Sopa de legumes", "descricao": "leve, reconfortante e boa para dias frios.", "tempo": "30 min", "fonte": "conhecimento interno"},
    {"nome": "Pão caseiro", "descricao": "cheiroso, macio e ótimo para acompanhar refeições.", "tempo": "90 min", "fonte": "conhecimento interno"},
]


def validar_sugestoes(sugestoes, quantidade, proibidas=None):
    """Valida quantidade, deduplicação e ausência de receitas proibidas."""
    propostas = []
    nomes_usados = []
    proibidos = proibidas or []

    for item in sugestoes or []:
        nome = str(item.get("nome") or item.get("titulo") or item.get("titulo_busca") or "").strip()
        if not nome:
            continue
        if any(nomes_representam_mesma_receita(nome, atual) for atual in nomes_usados):
            continue
        if any(nomes_representam_mesma_receita(nome, proibido) for proibido in proibidos):
            continue

        nomes_usados.append(nome)
        propostas.append({
            "nome": nome,
            "descricao": str(item.get("descricao", "Receita culinária sugerida.")).strip() or "Receita culinária sugerida.",
            "tempo": str(item.get("tempo") or item.get("tempo_preparo") or "").strip() or "tempo variável",
            "fonte": str(item.get("fonte", "conhecimento interno")).strip() or "conhecimento interno",
            "url": str(item.get("url", "")).strip(),
        })

        if len(propostas) >= quantidade:
            break

    return propostas


def preencher_sugestoes_fallback(quantidade, proibidas=None):
    proibidos = proibidas or []
    resultados = []
    nomes_usados = []

    for item in RECEITAS_FALLBACK:
        nome = str(item.get("nome", "")).strip()
        if not nome:
            continue
        if any(nomes_representam_mesma_receita(nome, atual) for atual in nomes_usados):
            continue
        if any(nomes_representam_mesma_receita(nome, proibido) for proibido in proibidas):
            continue

        nomes_usados.append(nome)
        resultados.append({
            "nome": nome,
            "descricao": str(item.get("descricao", "Receita culinária sugerida.")).strip(),
            "tempo": str(item.get("tempo", "tempo variável")).strip(),
            "fonte": str(item.get("fonte", "conhecimento interno")).strip(),
            "url": "",
        })

        if len(resultados) >= quantidade:
            break

    return resultados


def buscar_referencias_seguras(mensagem, intencao, historico, limite=30):
    try:
        return buscar_referencias_para_sugestoes(mensagem, intencao, historico, limite=limite)
    except Exception as erro:
        print(f"[ChefBot] Falha ao buscar referências externas: {erro}")
        return []


# ============================================================
# BUSCAR ENSINAMENTOS APROVADOS
# ============================================================


# ============================================================
# RECEITAS DO BANCO DE DADOS — FONTE PRINCIPAL DO CHEFBOT
# ============================================================

def extrair_consulta_receita(mensagem):
    """Extrai o nome mais provável da receita a partir da mensagem."""
    texto = str(mensagem or "").strip()
    normal = normalizar_texto(texto)

    padroes = [
        r"receita\s+(?:de|do|da|dos|das)\s+(.+)$",
        r"como\s+(?:faco|fazer|preparo|preparar)\s+(?:a|o|a receita|uma receita)?\s*(.+)$",
        r"quero\s+(?:a|uma)\s+receita(?:\s+(?:de|do|da|dos|das))?\s*(.+)$",
    ]

    # As expressões acima estão escritas sobre o texto já normalizado.
    for padrao in padroes:
        match = re.search(padrao, normal)
        if match:
            candidato = match.group(1).strip(" .!?,-")
            if candidato:
                return candidato

    # Fallback: remove, em camadas, as expressões de pedido e deixa só o prato.
    candidato = normal
    prefixos = [
        r"^(oi|ola|entao|ai|bom|beleza|ok|certo)[,!.\s]+",
        r"^(eu\s+)?(quero|queria|gostaria de|preciso|pretendo|vou|vamos|bora)\s+",
        r"^(me\s+)?(passa|passe|manda|mande|mostra|mostre|ensina|ensine|da|de)\s+",
        r"^(fazer|preparar|cozinhar|aprender a fazer|a fazer)\s+",
        r"^(a|uma?)\s+receita(\s+(de|do|da|dos|das))?\s*",
        r"^(a|o|um|uma|de|do|da|dos|das)\s+",
    ]
    anterior = None
    while anterior != candidato:
        anterior = candidato
        for prefixo in prefixos:
            candidato = re.sub(prefixo, "", candidato).strip()
    return candidato.strip(" .!?,-")


def _campo_receita(item, *nomes):
    """Retorna o primeiro campo existente entre nomes camelCase/snake_case."""
    for nome in nomes:
        valor = item.get(nome)
        if valor is not None and str(valor).strip() != "":
            return valor
    return ""


def buscar_receitas_backend(consulta, limite=20, categoria=None, dificuldade=None, tempo_maximo=None):
    """Consulta as receitas aprovadas do BiteByte pelo Spring Boot."""
    try:
        params = {
            "q": str(consulta or "").strip(),
        }
        if limite:
            params["limite"] = limite
        if categoria:
            params["categoria"] = categoria
        if dificuldade:
            params["dificuldade"] = dificuldade
        if tempo_maximo is not None:
            params["tempoMaximo"] = tempo_maximo

        # O endpoint específico do ChefBot procura também nos ingredientes
        # e ordena os resultados por relevância.
        resposta = requests.get(
            f"{BACKEND_URL}/recipes/chefbot/search",
            params=params,
            timeout=10,
        )

        if resposta.status_code != 200:
            print(
                f"[ChefBot] Erro ao buscar receitas no backend: "
                f"{resposta.status_code} - {resposta.text}"
            )
            return []

        dados = resposta.json()
        if isinstance(dados, list):
            return dados

        # Algumas implementações podem devolver {"content": [...]}.
        if isinstance(dados, dict) and isinstance(dados.get("content"), list):
            return dados["content"]

        return []

    except requests.exceptions.RequestException as erro:
        print(f"[ChefBot] Erro ao conectar ao endpoint de receitas: {erro}")
        return []
    except (ValueError, TypeError) as erro:
        print(f"[ChefBot] Resposta inválida do endpoint de receitas: {erro}")
        return []


def selecionar_receita_backend(receitas, consulta):
    """Escolhe a receita mais próxima da consulta, sem inventar nomes."""
    if not receitas:
        return None

    alvo = tokens_importantes(consulta)
    candidatos = []

    for item in receitas:
        if not isinstance(item, dict):
            continue

        titulo = str(_campo_receita(item, "titulo", "nome", "title") or "").strip()
        if not titulo:
            continue

        titulo_tokens = tokens_importantes(titulo)
        inter = len(alvo & titulo_tokens)
        score = inter / max(len(alvo), 1)

        normal_titulo = normalizar_texto(titulo)
        normal_alvo = normalizar_texto(consulta)
        if normal_titulo == normal_alvo:
            score += 2.0
        elif normal_titulo and normal_titulo in normal_alvo:
            score += 1.0
        elif normal_alvo and normal_alvo in normal_titulo:
            score += 0.8

        candidatos.append((score, titulo, item))

    if not candidatos:
        return None

    # Sem correspondência mínima no TÍTULO, não é a receita pedida
    # (ex.: "pizza" aparece só como ingrediente do Calzone).
    candidatos = [c for c in candidatos if c[0] >= 0.5]
    if not candidatos:
        return None

    candidatos.sort(key=lambda x: (-x[0], normalizar_texto(x[1])))
    return candidatos[0][2]


def montar_resposta_receita_banco(receita):
    """Monta a receita diretamente do MySQL sem renumerar cada linha.

    O banco é a fonte oficial dos dados. As linhas numeradas do campo
    'passos' definem o início de cada etapa; as linhas seguintes pertencem
    à descrição da mesma etapa até aparecer um novo número.
    """
    titulo = str(_campo_receita(receita, "titulo", "nome", "title") or "Receita").strip()
    categoria = str(_campo_receita(receita, "categoria", "category") or "").strip()
    dificuldade = str(_campo_receita(receita, "dificuldade", "difficulty") or "").strip()
    resumo = str(_campo_receita(receita, "resumo", "descricao", "description") or "").strip()
    tempo = str(_campo_receita(receita, "tempo", "tempo_preparo", "totalTime") or "").strip()
    tempo_minutos = _campo_receita(receita, "tempoMinutos", "tempo_minutos", "tempoMin")
    ingredientes = str(_campo_receita(receita, "ingredientes", "ingredients") or "").strip()
    passos = str(_campo_receita(receita, "passos", "modoPreparo", "modo_preparo", "preparo", "instructions") or "").strip()
    fonte = str(_campo_receita(receita, "fonte", "source") or "BiteByte").strip()
    url = str(_campo_receita(receita, "urlFonte", "url_fonte", "url") or "").strip()

    linhas = [f"🍳 **{titulo}**"]

    if resumo:
        linhas.extend(["", resumo])

    detalhes = []
    if categoria:
        detalhes.append(f"**Categoria:** {categoria}")
    if dificuldade:
        detalhes.append(f"**Dificuldade:** {dificuldade}")
    if tempo:
        detalhes.append(f"**Tempo:** {tempo}")
    elif tempo_minutos not in (None, ""):
        detalhes.append(f"**Tempo:** {tempo_minutos} minutos")

    if detalhes:
        linhas.extend(["", " | ".join(detalhes)])

    if ingredientes:
        linhas.extend(["", "### 🧂 Ingredientes:"])
        for item in re.split(r"\r?\n|;", ingredientes):
            item = item.strip(" -*•")
            if item:
                linhas.append(f"- {item}")

    if passos:
        linhas.extend(["", "### 👨‍🍳 Modo de preparo:"])

        # Cada linha numerada inicia uma nova etapa. As linhas seguintes
        # continuam pertencendo à descrição daquela etapa.
        padrao_etapa = re.compile(
            r"^\s*(?:passo|etapa)?\s*(\d+)\s*[.):\-–]\s*(.+?)\s*$",
            re.IGNORECASE,
        )

        # "1. Separe tudo. 2. Misture." numa linha só -> uma etapa por linha.
        if "\n" not in passos and len(re.findall(r"(?:^|\s)\d+[.)]\s", passos)) >= 2:
            passos = re.sub(r"\s+(?=\d+[.)]\s)", "\n", passos)
        etapas = []
        etapa_atual = None

        for linha in re.split(r"\r?\n", passos):
            linha = linha.strip()
            if not linha:
                continue

            match = padrao_etapa.match(linha)

            if match:
                if etapa_atual:
                    etapas.append(etapa_atual)

                etapa_atual = {
                    "numero": match.group(1),
                    "titulo": match.group(2).strip(),
                    "descricao": [],
                }
            elif etapa_atual:
                etapa_atual["descricao"].append(linha)
            else:
                # Texto sem numeração antes da primeira etapa.
                if etapas:
                    etapas[-1]["descricao"].append(linha)
                else:
                    etapa_atual = {
                        "numero": "",
                        "titulo": "",
                        "descricao": [linha],
                    }

        if etapa_atual:
            etapas.append(etapa_atual)

        for etapa in etapas:
            numero = etapa["numero"]
            titulo_etapa = etapa["titulo"]
            descricao = " ".join(etapa["descricao"]).strip()

            if numero and titulo_etapa:
                linhas.append(f"**{numero}. {titulo_etapa}**")
                if descricao:
                    linhas.append(descricao)
            elif descricao:
                linhas.append(descricao)

            linhas.append("")

        if linhas and linhas[-1] == "":
            linhas.pop()

    if fonte:
        linhas.extend(["", f"**Fonte:** {fonte}"])
    if url:
        linhas.append(f"**Fonte original:** {url}")

    return "\n".join(linhas).strip()


def _lista_natural_pt(palavras):
    palavras = list(palavras)
    if len(palavras) <= 1:
        return "".join(palavras)
    return ", ".join(palavras[:-1]) + " e " + palavras[-1]


def reconstruir_pedido_da_sessao(historico, janela=8):
    """Refaz, mensagem por mensagem, o pedido de sugestão em andamento.

    `historico` vem do mais recente para o mais antigo. Uma receita completa
    (intenção RECEITA) encerra a sessão. Pedidos novos recomeçam do zero;
    refinamentos ("e coisas fritas?") ajustam o pedido acumulado.
    """
    if not sessao_de_sugestao_recente(historico):
        return None

    sessao = []
    for item in (historico or [])[:janela]:
        intencao = str(item.get("intencao", ""))
        if intencao == "RECEITA":
            break
        if intencao in _INTENCOES_SUGESTAO:
            sessao.append(item)

    pedido = None
    for item in reversed(sessao):  # do mais antigo para o mais novo
        texto = str(item.get("mensagem", "")).strip()
        if not texto or identificar_mais_opcoes(texto):
            continue
        novo = interpretar_pedido(texto)
        if not novo.tem_filtro:
            continue
        pedido = mesclar_pedidos(pedido, novo) if (pedido and e_refinamento(texto)) else novo
    return pedido


def sugerir_do_banco_filtrado(mensagem, quantidade, historico):
    """Sugestões por categoria + ingredientes + tempo/dificuldade/técnica, direto do banco.

    Retorna None quando o pedido não tem nenhum filtro (aí vale o fluxo antigo).
    Caso contrário devolve um dict com: resultados, texto e expressao.
    """
    mais_opcoes = identificar_mais_opcoes(mensagem)
    herdado = reconstruir_pedido_da_sessao(historico)

    if mais_opcoes:
        pedido = herdado
    else:
        novo = interpretar_pedido(mensagem)
        pedido = mesclar_pedidos(herdado, novo) if (herdado and e_refinamento(mensagem)) else novo
    if pedido is None or not pedido.tem_filtro:
        return None

    # Categoria: o backend filtra. Sem categoria: pré-filtra pelos ingredientes
    # (ordenado por relevância no Spring Boot) e refina aqui.
    def carregar(p):
        if p.categoria:
            return buscar_receitas_backend("", limite=100, categoria=p.categoria)
        termos = " ".join(rad.split()[0] for _, rad in p.ingredientes)
        receitas = buscar_receitas_backend(termos, limite=100) if termos else []
        return receitas or buscar_receitas_backend("", limite=100)

    receitas = carregar(pedido)
    resultado = ranquear(receitas, pedido)

    # O que o usuário acabou de pedir vale mais do que ingredientes herdados de mensagens
    # antigas: se manter esses ingredientes obriga a abrir mão do pedido novo (ou não
    # deixa nenhum resultado), tenta de novo sem eles.
    nota_extra = ""
    ingredientes_novos = [] if mais_opcoes else interpretar_pedido(mensagem).ingredientes
    if pedido.ingredientes and not ingredientes_novos and not mais_opcoes:
        if not resultado.itens or resultado.relaxados:
            antigos = [e for e, _ in pedido.ingredientes]
            sem_antigos = mesclar_pedidos(None, pedido)
            sem_antigos.ingredientes = []
            alternativa = ranquear(carregar(sem_antigos), sem_antigos)
            if alternativa.itens and (
                not resultado.itens or len(alternativa.relaxados) < len(resultado.relaxados)
            ):
                pedido, resultado = sem_antigos, alternativa
                nota_extra = (
                    f"Deixei de lado {_lista_natural_pt(antigos)} para encontrar opções "
                    "que combinam com o seu pedido."
                )

    # "Mais opções" nunca repete o que já foi mostrado. Um pedido novo ou refinado
    # pode mostrar receitas já vistas: o usuário está pedindo outra coisa.
    proibidas = obter_sugestoes_anteriores(historico) if mais_opcoes else []

    itens, nomes = [], []
    for item in resultado.itens:
        receita = item["receita"]
        nome = str(_campo_receita(receita, "titulo", "nome", "title") or "").strip()
        if any(nomes_representam_mesma_receita(nome, antigo) for antigo in proibidas + nomes):
            continue
        resumo = str(_campo_receita(receita, "resumo", "descricao", "description") or "").strip()
        tempo = str(_campo_receita(receita, "tempo", "tempo_preparo") or "").strip()
        nomes.append(nome)
        itens.append({
            "nome": nome,
            "descricao": resumo or "Receita cadastrada no BiteByte.",
            "tempo": tempo or "Não informado",
            "usa": item["usa"],
        })
        if len(itens) >= quantidade:
            break

    print(
        f"[ChefBot] Sugestão filtrada: categoria={pedido.categoria} salgado={pedido.sem_doces} "
        f"tecnica={pedido.tecnica} ingredientes={resultado.ingredientes_pedidos} "
        f"tempo={pedido.tempo_max} dificuldade={pedido.dificuldade} "
        f"herdado={'sim' if herdado else 'não'} -> {len(itens)} item(ns)"
    )

    if itens:
        titulo = montar_titulo(pedido, resultado)
        if mais_opcoes:
            titulo = titulo.replace("Sugestões", "Outras sugestões", 1)
        nota = " ".join(n for n in (nota_extra, montar_nota(pedido, resultado)) if n)
        texto = formatar_sugestoes_filtradas(itens, titulo, nota, len(resultado.ingredientes_pedidos))
        if not resultado.ingredientes_pedidos or resultado.cobertura_total:
            expressao = random.choice(["FELIZ", "APAIXONADO"])
        else:
            expressao = random.choice(["FELIZ", "NEUTRO"])
        return {"resultados": itens, "texto": texto, "expressao": expressao}

    # Nada para mostrar: explica o motivo em vez de inventar receita.
    if resultado.itens:
        texto = (
            "😌 Já te mostrei todas as receitas que encontrei para esse pedido. "
            "Quer tentar outro ingrediente ou outro tipo de prato?"
        )
        return {"resultados": [], "texto": texto, "expressao": "NEUTRO"}

    nota = montar_nota(pedido, resultado)
    filtros = ", ".join(descrever_filtros(pedido))
    detalhe = nota or (
        f"Não encontrei receitas no BiteByte para esse pedido ({filtros})." if filtros
        else "Não encontrei receitas cadastradas no BiteByte para esse pedido."
    )
    return {"resultados": [], "texto": f"😕 {detalhe} Tente outro ingrediente ou tipo de prato.",
            "expressao": "TRISTE"}


def gerar_sugestoes_do_banco(mensagem, quantidade, historico):
    """
    Gera sugestões EXCLUSIVAMENTE a partir das receitas cadastradas no
    banco do BiteByte.

    Regras:
    - Busca pelo endpoint específico do ChefBot, que considera ingredientes.
    - Tenta entregar até 10 receitas.
    - Se houver menos de 10 no banco, entrega todas as disponíveis.
    - Nunca repete uma receita já apresentada nesta conversa/histórico.
    - Quando o usuário pede "mais", reutiliza a última consulta e traz
      somente receitas diferentes das já mostradas.
    - Não cria receitas de fallback quando o banco não encontrar resultados.
    """
    consulta = mensagem

    if identificar_mais_opcoes(mensagem):
        consulta = obter_ultima_consulta_de_sugestao(historico) or mensagem

    # Busca o máximo permitido pelo endpoint para conseguir encontrar
    # opções novas mesmo depois de várias listas de 10.
    receitas = buscar_receitas_backend(consulta, limite=100)
    if not receitas:
        print(f"[ChefBot] Nenhuma receita encontrada no banco para: {consulta}")
        return []

    proibidas = obter_sugestoes_anteriores(historico)
    resultados = []
    nomes = []

    for receita in receitas:
        if not isinstance(receita, dict):
            continue

        nome = str(_campo_receita(receita, "titulo", "nome", "title") or "").strip()
        if not nome:
            continue

        # Impede repetição entre listas.
        if any(nomes_representam_mesma_receita(nome, antigo) for antigo in proibidas):
            continue
        if any(nomes_representam_mesma_receita(nome, atual) for atual in nomes):
            continue

        resumo = str(
            _campo_receita(receita, "resumo", "descricao", "description") or ""
        ).strip()
        tempo = str(
            _campo_receita(receita, "tempo", "tempo_preparo") or ""
        ).strip()

        nomes.append(nome)
        resultados.append({
            "nome": nome,
            "descricao": resumo or "Receita cadastrada no BiteByte.",
            "tempo": tempo or "Não informado",
        })

        if len(resultados) >= quantidade:
            break

    print(
        f"[ChefBot] {len(resultados)} sugestão(ões) novas encontradas no banco "
        f"para a consulta: {consulta}"
    )
    return resultados


def formatar_sugestoes(resultados, titulo="🍽️ Sugestões:"):
    """Formata as sugestões exatamente com título, resumo e tempo."""
    linhas = [titulo, ""]

    for indice, item in enumerate(resultados, 1):
        nome = str(item.get("nome", "")).strip()
        descricao = str(item.get("descricao", "")).strip()
        tempo = str(item.get("tempo", "")).strip()

        linhas.append(f"{indice}. **{nome}**")
        linhas.append(f"   **Resumo:** {descricao}")
        linhas.append(f"   **Tempo:** {tempo}")
        linhas.append("")

    if linhas and linhas[-1] == "":
        linhas.pop()

    return "\n".join(linhas)


# ============================================================
# RECEITAS DO BANCO COMO REFERÊNCIA PARA A RESPOSTA DO MODELO
# ============================================================

TERMOS_GENERICOS = {
    "receita", "receitas", "fazer", "faco", "preparar", "preparo", "cozinhar",
    "quero", "queria", "posso", "pode", "sugestao", "sugestoes", "ideia", "ideias",
    "opcao", "opcoes", "algo", "alguma", "coisa", "dica", "dicas", "sobre",
    "quanto", "quantos", "quantas", "quando", "onde", "porque", "trocar",
    "substituir", "usar", "ficar", "deixar", "muito", "pouco", "mais",
}

MAX_RECEITAS_REFERENCIA = 3
MAX_CHARS_INGREDIENTES = 450
MAX_CHARS_PASSOS = 650


def _radical_token(token):
    if len(token) > 4 and token.endswith("oes"):
        return token[:-3] + "ao"
    if len(token) > 3 and token.endswith("s"):
        return token[:-1]
    return token


def _tokens_radical(texto):
    return {_radical_token(t) for t in tokens_importantes(texto)}


def selecionar_receitas_relevantes(receitas, consulta, maximo=MAX_RECEITAS_REFERENCIA):
    """Escolhe, entre as receitas do banco, só as que têm relação real com a consulta."""
    alvo = {
        _radical_token(t)
        for t in tokens_importantes(consulta)
        if t not in QUALIFICADORES_RECEITA and t not in TERMOS_GENERICOS
    }
    if not alvo:
        return []

    pontuadas = []
    for item in receitas or []:
        if not isinstance(item, dict):
            continue
        titulo = str(_campo_receita(item, "titulo", "nome", "title") or "").strip()
        if not titulo:
            continue

        no_titulo = len(alvo & _tokens_radical(titulo))
        nos_ingredientes = len(
            alvo & _tokens_radical(str(_campo_receita(item, "ingredientes", "ingredients") or ""))
        )

        # Precisa citar o prato no título OU bater em pelo menos 2 ingredientes.
        if no_titulo < 1 and nos_ingredientes < 2:
            continue

        pontuadas.append((no_titulo * 3 + nos_ingredientes, titulo, item))

    pontuadas.sort(key=lambda x: (-x[0], normalizar_texto(x[1])))
    return [x[2] for x in pontuadas[:maximo]]


def _cortar_texto(texto, limite):
    texto = str(texto or "").strip()
    if len(texto) <= limite:
        return texto
    corte = texto[:limite].rsplit("\n", 1)[0].rstrip()
    return corte + "\n[...]"


def montar_contexto_receitas_banco(receitas):
    """Texto com as receitas do banco para entrar no prompt do modelo."""
    if not receitas:
        return ""

    blocos = []
    for indice, receita in enumerate(receitas, 1):
        titulo = str(_campo_receita(receita, "titulo", "nome", "title") or "Receita").strip()
        categoria = str(_campo_receita(receita, "categoria", "category") or "").strip()
        dificuldade = str(_campo_receita(receita, "dificuldade", "difficulty") or "").strip()
        tempo = str(_campo_receita(receita, "tempo", "tempo_preparo") or "").strip()
        resumo = str(_campo_receita(receita, "resumo", "descricao", "description") or "").strip()
        ingredientes = _cortar_texto(
            _campo_receita(receita, "ingredientes", "ingredients"), MAX_CHARS_INGREDIENTES
        )
        passos = _cortar_texto(
            _campo_receita(receita, "passos", "modoPreparo", "preparo", "instructions"),
            MAX_CHARS_PASSOS,
        )

        linhas = [f"[Receita {indice}] {titulo}"]
        meta = [x for x in (
            f"Categoria: {categoria}" if categoria else "",
            f"Dificuldade: {dificuldade}" if dificuldade else "",
            f"Tempo: {tempo}" if tempo else "",
        ) if x]
        if meta:
            linhas.append(" | ".join(meta))
        if resumo:
            linhas.append(f"Resumo: {resumo}")
        if ingredientes:
            linhas.append(f"Ingredientes:\n{ingredientes}")
        if passos:
            linhas.append(f"Modo de preparo:\n{passos}")
        blocos.append("\n".join(linhas))

    return (
        "============================================================\n"
        "REFERÊNCIAS DO BANCO DE RECEITAS DO BITEBYTE\n"
        "============================================================\n\n"
        "As receitas abaixo foram cadastradas no BiteByte e são a BASE FACTUAL da resposta.\n\n"
        "REGRAS:\n"
        "- Ingredientes, quantidades, tempos, temperaturas e etapas devem vir SOMENTE destas receitas.\n"
        "- Se a pergunta for sobre uma destas receitas, responda com base nela e cite o nome.\n"
        "- Se a pergunta for sobre uma técnica ou substituição, use as receitas como contexto e diga o que é da receita do BiteByte.\n"
        "- Se uma receita estiver marcada com [...], o texto foi resumido; não complete o que falta inventando.\n"
        "- Não misture ingredientes de receitas diferentes.\n"
        "- Se nenhuma destas receitas tiver relação com a pergunta, ignore-as.\n\n"
        + "\n\n".join(blocos)
    )


def montar_contexto_sugestoes_banco(sugestoes):
    if not sugestoes:
        return ""
    linhas = [
        "============================================================",
        "RECEITAS DO BITEBYTE DISPONÍVEIS PARA SUGERIR",
        "============================================================",
        "",
        "Priorize estas receitas cadastradas. Só complete a lista com outros pratos se faltar.",
        "",
    ]
    for item in sugestoes:
        nome = str(item.get("nome", "")).strip()
        descricao = str(item.get("descricao", "")).strip()
        linhas.append(f"- {nome}" + (f": {descricao}" if descricao else ""))
    return "\n".join(linhas)


def buscar_contexto_receitas_banco(mensagem, intencao, referencia=None):
    """Busca no MySQL as receitas relacionadas à mensagem e devolve (contexto, receitas)."""
    consulta = f"{referencia} {mensagem}" if referencia else mensagem
    if intencao == "RECEITA":
        consulta = extrair_consulta_receita(mensagem) or consulta

    candidatas = buscar_receitas_backend(consulta, limite=15)
    relevantes = selecionar_receitas_relevantes(candidatas, consulta)

    if relevantes:
        titulos = [str(_campo_receita(r, "titulo", "nome") or "") for r in relevantes]
        print(f"[ChefBot] Receitas do banco usadas como referência: {titulos}")

    return montar_contexto_receitas_banco(relevantes), relevantes


def buscar_ensinamentos_chefbot():
    """Busca no Spring Boot os ensinamentos aprovados do ChefBot."""
    try:
        resposta = requests.get(
            f"{BACKEND_URL}/chat/teachings/approved",
            timeout=10
        )
        if resposta.status_code == 200:
            dados = resposta.json()
            if isinstance(dados, list):
                return dados
            return []
        print(f"[ChefBot] Erro ao buscar ensinamentos: {resposta.status_code}")
        return []
    except requests.exceptions.RequestException as erro:
        print(f"[ChefBot] Erro ao conectar com ensinamentos: {erro}")
        return []


# ============================================================
# MONTAR CONTEXTO DOS ENSINAMENTOS
# ============================================================

def montar_contexto_ensinamentos(ensinamentos):
    """Transforma os ensinamentos aprovados em contexto para o modelo."""
    if not ensinamentos:
        return """
============================================================
CONHECIMENTOS APROVADOS DO CHEFBOT
============================================================

Nenhum ensinamento aprovado foi encontrado.

Responda normalmente usando as demais regras do sistema.
"""

    partes = ["""
============================================================
CONHECIMENTOS APROVADOS DO CHEFBOT
============================================================

Os exemplos abaixo são conhecimentos previamente aprovados
para orientar suas respostas.

Use esses conhecimentos quando forem relevantes para a pergunta.

Não diga ao usuário que recebeu essas informações de um banco
de dados.

Não copie obrigatoriamente a resposta ensinada. Use-a como
referência e adapte a resposta ao contexto, ao nível do usuário
e às regras do modo atual.
"""]

    for ensinamento in ensinamentos:
        pergunta = str(ensinamento.get("pergunta", "")).strip()
        resposta = str(ensinamento.get("resposta", "")).strip()
        categoria = str(ensinamento.get("categoria", "não informada")).strip()

        if not pergunta or not resposta:
            continue

        partes.append(f"""
### Categoria: {categoria}
**Pergunta:** {pergunta}
**Resposta ensinada:** {resposta}
""")

    if len(partes) == 1:
        return """
============================================================
CONHECIMENTOS APROVADOS DO CHEFBOT
============================================================

Nenhum ensinamento válido foi encontrado.

Responda normalmente usando as demais regras do sistema.
"""

    return "\n".join(partes)


# ============================================================
# MONTAR CONTEXTO DO HISTÓRICO
# ============================================================

def _texto_historico_item(item):
    mensagem = str(item.get("mensagem", "") or "").strip()
    resposta = str(item.get("resposta", "") or "").strip()
    intencao = str(item.get("intencao", "") or "").strip()
    return mensagem, resposta, intencao


def selecionar_memorias_relevantes(historico_usuario, mensagem_atual, limite=8):
    """Seleciona memórias dentro do histórico recebido.

    Esta função é mantida para compatibilidade, mas o contexto enviado ao
    modelo usa somente as 10 últimas conversas em montar_contexto_historico().
    O histórico vem do banco via /chat/history/{email}.
    """
    if not historico_usuario:
        return []

    termos_atuais = tokens_importantes(mensagem_atual)
    candidatos = []

    for indice, item in enumerate(historico_usuario):
        mensagem, resposta, intencao = _texto_historico_item(item)
        if not mensagem and not resposta:
            continue

        texto = f"{mensagem} {resposta}"
        termos_item = tokens_importantes(texto)
        relevancia = len(termos_atuais & termos_item)

        # Conversas mais recentes ganham um pequeno bônus.
        bonus_recencia = max(0, 5 - indice) * 0.10
        candidatos.append((relevancia + bonus_recencia, indice, item))

    candidatos.sort(key=lambda x: (-x[0], x[1]))

    resultado = []
    vistos = set()
    for _, _, item in candidatos:
        chave = (
            normalizar_texto(item.get("mensagem", "")),
            normalizar_texto(item.get("resposta", ""))[:180],
        )
        if chave in vistos:
            continue
        vistos.add(chave)
        resultado.append(item)
        if len(resultado) >= limite:
            break

    return resultado


def montar_contexto_historico(historico_usuario, mensagem_atual=""):
    if not historico_usuario:
        return """
============================================================
MEMÓRIA DO USUÁRIO / HISTÓRICO
============================================================

Nenhuma conversa anterior encontrada.
"""

    # A memória do ChefBot é limitada às 10 últimas conversas retornadas
    # pelo histórico do usuário. Não adicionamos memórias relevantes extras,
    # para garantir que o modelo nunca receba mais de 10 registros como memória.
    recentes = historico_usuario[:10]

    itens = []
    vistos = set()

    for item in recentes:
        mensagem, resposta, intencao = _texto_historico_item(item)
        chave = (
            normalizar_texto(mensagem),
            normalizar_texto(resposta)[:180],
        )
        if chave in vistos:
            continue
        vistos.add(chave)

        bloco = []
        if intencao:
            bloco.append(f"INTENÇÃO: {intencao}")
        if mensagem:
            bloco.append(f"USUÁRIO: {mensagem}")
        if resposta:
            bloco.append(f"CHEFBOT: {resposta}")

        if bloco:
            itens.append("\n".join(bloco))

    if not itens:
        return """
============================================================
MEMÓRIA DO USUÁRIO / HISTÓRICO
============================================================

Nenhuma conversa anterior encontrada.
"""

    return """
============================================================
MEMÓRIA DO USUÁRIO / HISTÓRICO
============================================================

As informações abaixo vieram do histórico de chat do usuário.
Use-as para manter continuidade e lembrar o que o usuário já disse.

REGRAS DA MEMÓRIA:
- Considere como verdade apenas o que aparece no histórico ou no perfil.
- Se o usuário informou uma preferência, objetivo, ingrediente, restrição,
  receita escolhida ou outra informação relevante, use-a quando ela tiver
  relação com o pedido atual.
- Se uma informação antiga entrar em conflito com uma informação mais recente,
  dê prioridade à informação mais recente.
- Não diga que possui uma "memória interna" e não mencione banco de dados.
- Não invente lembranças.
- Não revele o histórico inteiro ao usuário; use-o apenas para responder.

CONVERSAS RECUPERADAS:

""" + "\n\n------------------------------\n\n".join(itens)


# ============================================================
# PÁGINA
# ============================================================

@app.route("/")
def home():
    return render_template("index.html")


# Endpoint aberto pelo botão do chat no index do front-end
@app.route("/chefbot")
def chefbot():
    return render_template("index.html")


# ============================================================
# HEALTH CHECK
# ============================================================

@app.route("/health")
def health():
    return {
        "status": "ok",
        "modelo": MODELO,
        "ollama": OLLAMA_URL
    }


# ============================================================
# CHAT
# ============================================================

@app.route("/chat", methods=["POST"])
def chat():
    dados = request.get_json(silent=True)

    if not dados:
        return Response(
            stream_local("❌ Não consegui receber sua mensagem.", expressao="ERRO"),
            mimetype="text/event-stream"
        )

    mensagem = dados.get("mensagem", "").strip()
    email = dados.get("email", "").strip().lower()
    nivel = dados.get("nivel", "").lower()
    # Quando o chat for aberto fora do fluxo de login, não bloqueia:
    # usa identidade de visitante. O fluxo normal do site envia o e-mail via URL.
    if not email:
        email = "visitante@bitebyte.local"

    if not mensagem:
        return Response(
            stream_local("Digite alguma coisa para conversar comigo.", expressao="NEUTRO"),
            mimetype="text/event-stream"
        )

    # ========================================================
    # 1) RESPOSTA LOCAL INSTANTÂNEA (sem backend e sem Ollama)
    #    Saudações, agradecimentos, despedidas e perguntas já cadastradas,
    #    com tolerância a erros ("oii", "obrigadooo", "xicra"...).
    #    Cada resposta traz a própria expressão facial.
    # ========================================================
    resposta_local = buscar_resposta_local(mensagem, email)
    if resposta_local:
        intencao = (
            identificar_intencao(mensagem)
            if resposta_local.origem == "conhecimento"
            else "PERGUNTA"
        )
        print(
            f"[ChefBot] ⚡ Resposta local ({resposta_local.origem}: "
            f"{resposta_local.chave}) -> {resposta_local.expressao}"
        )
        salvar_historico_em_segundo_plano(email, mensagem, resposta_local.texto, intencao)
        return Response(
            stream_local(resposta_local.texto, mensagem, resposta_local.expressao),
            mimetype="text/event-stream",
        )

    # Fora da culinária: também é local e instantâneo.
    if verificar_palavra_fora(mensagem):
        resposta = buscar_resposta_fora(mensagem)
        if not resposta:
            resposta = (
                "😌 Eu sou o ChefBot, não o Google. "
                "Meu território é a cozinha. "
                "Tente perguntar algo sobre comida, receitas ou ingredientes."
            )
        salvar_historico_em_segundo_plano(email, mensagem, resposta, "PERGUNTA")
        return Response(
            stream_local(resposta, mensagem, expressao_por_emoji(resposta, ["NEUTRO"])),
            mimetype="text/event-stream",
        )

    # ========================================================
    # 2) SÓ AQUI consulta backend e Ollama
    # ========================================================
    preferencias = buscar_preferencias_usuario(email)
    historico_usuario = buscar_historico_usuario(email)
    ensinamentos_chefbot = buscar_ensinamentos_chefbot()

    print(f"[ChefBot] Usuário: {email}")
    print(f"[ChefBot] Histórico encontrado: {len(historico_usuario)} registros")
    print(f"[ChefBot] Ensinamentos aprovados encontrados: {len(ensinamentos_chefbot)} registros")

    if preferencias:
        habilidade = preferencias.get("habilidade")
        if habilidade:
            nivel = str(habilidade).lower()
            nivel = normalizar_texto(nivel)

    if nivel not in PROMPTS_NIVEL:
        nivel = "iniciante"

    intencao = identificar_intencao(mensagem, historico_usuario)
    print(f"[ChefBot] Mensagem: {mensagem}")
    print(f"[ChefBot] Intenção: {intencao}")

    # ========================================================
    # RECEITA VEM PRIMEIRO DO MYSQL / SPRING BOOT
    # ========================================================
    referencia = None
    if intencao not in {"SUGESTÃO", "NOVAS_SUGESTÕES"}:
        referencia = resolver_referencia_receita(mensagem, historico_usuario)
        if referencia and intencao == "PERGUNTA" and identificar_pedido_de_fazer(mensagem):
            intencao = "RECEITA"
            print(f"[ChefBot] Pedido contextual -> RECEITA ({referencia})")

    if (
        intencao == "PERGUNTA"
        and identificar_pedido_de_fazer(mensagem)
        and not referencia
        and obter_ultima_lista_de_sugestoes(historico_usuario)
        and re.search(r"(?<!\w)(essa|esse|ela)(?!\w)", normalizar_texto(mensagem))
    ):
        resposta = "Qual delas você quer fazer? Me diga o número ou o nome da receita. 😊"
        salvar_historico_usuario(email, mensagem, resposta, "PERGUNTA")
        return Response(stream_local(resposta, mensagem), mimetype="text/event-stream")

    if intencao == "RECEITA":
        consulta_receita = extrair_consulta_receita(mensagem)
        # "essa receita", "a primeira": usa o título resolvido pelo histórico.
        if referencia and (
            not tokens_importantes(consulta_receita)
            or normalizar_texto(consulta_receita) in {"essa receita", "essa", "esse", "ela"}
            or precisa_de_contexto_anterior(consulta_receita)
        ):
            consulta_receita = referencia
        print(f"[ChefBot] Consulta de receita: {consulta_receita}")

        receitas_banco = buscar_receitas_backend(
            consulta_receita or mensagem,
            limite=20,
        )
        receita_banco = selecionar_receita_backend(
            receitas_banco,
            consulta_receita or mensagem,
        )

        if receita_banco:
            titulo_banco = str(_campo_receita(receita_banco, "titulo", "nome", "title") or "").strip()
            resposta_banco = montar_resposta_receita_banco(receita_banco)

            print(
                f"[ChefBot] ✅ Receita usada diretamente do MySQL: {titulo_banco}"
            )

            salvar_historico_usuario(
                email,
                mensagem,
                resposta_banco,
                intencao,
            )

            return Response(
                stream_local(resposta_banco, mensagem),
                mimetype="text/event-stream",
            )

        print(
            "[ChefBot] ⚠️ Receita não encontrada no banco. "
            "Usando o conhecimento do ChefBot como fallback."
        )

    # ========================================================
    # SUGESTÕES VÊM PRIMEIRO DO BANCO
    # ========================================================
    if intencao in {"SUGESTÃO", "NOVAS_SUGESTÕES"}:
        # O padrão agora é SEMPRE até 10 receitas.
        # Se o banco tiver menos, entregamos somente as disponíveis.
        quantidade = 10

        plano = sugerir_do_banco_filtrado(mensagem, quantidade, historico_usuario)
        if plano is not None:
            salvar_historico_usuario(email, mensagem, plano["texto"], intencao)
            return Response(
                stream_local(plano["texto"], mensagem, plano["expressao"]),
                mimetype="text/event-stream",
            )

        sugestoes_banco = gerar_sugestoes_do_banco(
            mensagem,
            quantidade,
            historico_usuario,
        )

        if sugestoes_banco:
            titulo = (
                "🍽️ Outras sugestões:"
                if intencao == "NOVAS_SUGESTÕES"
                else "🍽️ Sugestões:"
            )

            resposta_sugestoes = formatar_sugestoes(
                sugestoes_banco,
                titulo,
            )

            salvar_historico_usuario(
                email,
                mensagem,
                resposta_sugestoes,
                intencao,
            )

            print(
                f"[ChefBot] ✅ {len(sugestoes_banco)} sugestão(ões) entregues "
                "diretamente do banco."
            )

            return Response(
                stream_local(resposta_sugestoes, mensagem),
                mimetype="text/event-stream",
            )

        # Se não houver nenhuma receita compatível, NÃO deixa o modelo
        # inventar sugestões. A resposta informa que não há resultados.
        resposta_sem_resultado = (
            "😕 Não encontrei receitas cadastradas no BiteByte que correspondam "
            "ao que você pediu. Tente outro ingrediente ou tipo de prato."
        )

        salvar_historico_usuario(
            email,
            mensagem,
            resposta_sem_resultado,
            intencao,
        )

        return Response(
            stream_local(resposta_sem_resultado, mensagem),
            mimetype="text/event-stream",
        )

    # ========================================================
    # REFERÊNCIAS DO BANCO PARA O MODELO (RECEITA sem match / PERGUNTA / SUGESTÃO curta)
    # ========================================================
    contexto_banco = ""
    if intencao in {"SUGESTÃO", "NOVAS_SUGESTÕES"}:
        contexto_banco = montar_contexto_sugestoes_banco(sugestoes_banco)
    elif intencao in {"RECEITA", "PERGUNTA"}:
        contexto_banco, receitas_ref = buscar_contexto_receitas_banco(
            mensagem, intencao, referencia
        )
        if intencao == "RECEITA" and not receitas_ref:
            contexto_banco = (
                "============================================================\n"
                "RECEITA NÃO ENCONTRADA NO BANCO DO BITEBYTE\n"
                "============================================================\n\n"
                "Avise o usuário, no início da resposta, que essa receita ainda não está "
                "cadastrada no BiteByte. Em seguida dê uma versão simples e tradicional, "
                "sem inventar quantidades, tempos ou temperaturas que você não tenha certeza."
            )

    contexto_perfil = montar_contexto_usuario(preferencias)
    contexto_historico = montar_contexto_historico(historico_usuario, mensagem)
    contexto_ensinamentos = montar_contexto_ensinamentos(ensinamentos_chefbot)
    sugestoes_anteriores = obter_sugestoes_anteriores(historico_usuario)

    prompt_nivel = PROMPTS_NIVEL.get(nivel, PROMPTS_NIVEL["iniciante"])

    system_content = (
        PROMPT_BASE + "\n\n" + prompt_nivel + "\n\n" + 
        contexto_perfil + "\n\n" + contexto_historico + "\n\n" + contexto_ensinamentos
    )
    if contexto_banco:
        system_content += "\n\n" + contexto_banco

    instrucao_intencao = f"""
============================================================
INTENÇÃO DESTA MENSAGEM
============================================================

MODO = {intencao}

Você DEVE obedecer exatamente este modo.

============================================================
SUGESTÕES JÁ APRESENTADAS
============================================================

As seguintes receitas já foram sugeridas anteriormente:

{sugestoes_anteriores}

NÃO repita nenhuma delas.

Se o usuário pediu NOVAS_SUGESTÕES,
escolha receitas que NÃO estejam nessa lista.

============================================================
REGRA ABSOLUTA
============================================================

Se MODO = SUGESTÃO:

NÃO forneça receita.

NÃO forneça ingredientes.

NÃO forneça quantidades.

NÃO forneça modo de preparo.

NÃO forneça temperatura.

NÃO forneça etapas.

APENAS sugestões.

Se MODO = NOVAS_SUGESTÕES:

APENAS novas sugestões.

NÃO repita nenhuma sugestão anterior.

Se MODO = RECEITA:

Aí sim forneça a receita solicitada.

Se MODO = PERGUNTA:

Responda somente à dúvida apresentada.
"""

    mensagens_envio = [
        {"role": "system", "content": system_content},
        {"role": "user", "content": mensagem},
        {"role": "system", "content": instrucao_intencao}
    ]

    def gerar():
        resposta_completa = ""
        for evento in stream_resposta(mensagens_envio, intencao, mensagem):
            yield evento
            if "historico" in evento:
                try:
                    dados_evento = json.loads(evento.replace("data: ", "").strip())
                    resposta_completa = dados_evento.get("historico", "")
                except Exception:
                    pass

        if resposta_completa:
            salvar_historico_usuario(email, mensagem, resposta_completa, intencao)

    return Response(gerar(), mimetype="text/event-stream")


# ============================================================
# INICIAR
# ============================================================

if __name__ == "__main__":
    app.run(debug=True, threaded=True)