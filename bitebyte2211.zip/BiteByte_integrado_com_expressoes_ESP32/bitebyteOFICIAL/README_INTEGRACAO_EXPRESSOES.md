# BiteByte integrado com expressões faciais na ESP32

A IA e o fluxo de conversa do projeto integrado foram preservados. A integração acrescenta a seleção contextual de expressões pela IA e a ligação com o firmware facial da ESP32.

## O que foi integrado

- `IA/app.py`: orienta o modelo ChefBot a escolher uma expressão contextual e envia essa escolha como metadado separado do texto. O marcador interno é removido antes da resposta ser exibida ou salva no histórico.
- `IA/static/script.js`: recebe a expressão escolhida pela IA, atualiza o robô virtual e envia à ESP32 o comando serial compatível com o firmware.
- `IA/templates/index.html` e `IA/static/style.css`: acrescentam as faces virtuais de bravo, apaixonado e susto.
- `esp32_firmware/`: contém o firmware de expressões do projeto sem microfone, sem trazer a IA/simulador antigo.

`IA/app.py` é o arquivo principal da IA integrado à página `/chefbot`. O `app1.py` original foi mantido sem alterações.

## Uso com a ESP32

1. Grave o firmware de `esp32_firmware/` na ESP32 usando PlatformIO.
2. Inicie o BiteByte e o serviço Ollama como já eram iniciados no projeto integrado.
3. Abra o ChefBot no Chrome ou Edge por `localhost` ou HTTPS.
4. Clique em **Conectar ESP32** e selecione a porta USB da placa.
5. Envie mensagens normalmente. A IA escolhe a expressão; a página transmite o comando à tela TFT.

A comunicação usa 115200 baud e comandos terminados em nova linha. Não mantenha o Monitor Serial do PlatformIO aberto ao mesmo tempo que a página está conectada.

## Expressões

A IA pode escolher `NEUTRO`, `FELIZ`, `TRISTE`, `BRAVO`, `APAIXONADO`, `ERRO` ou `SUSTO`. Os estados `SONOLENTO` e `DORMINDO`, a piscada e as animações de olhar são administrados pelo firmware da ESP32. A página virtual espelha os temporizadores de sonolência.

Sem a ESP32 conectada, o robô virtual continua funcionando normalmente.
