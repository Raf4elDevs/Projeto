# Firmware facial BiteByte (ESP32 + TFT)

Este projeto contém somente o firmware das expressões faciais do BiteByte.
A inteligência artificial permanece no serviço `IA/app.py` do projeto principal.

## Gravar na ESP32

1. Abra esta pasta (`esp32_firmware`) no VS Code com PlatformIO.
2. Confira os pinos e o controlador da tela no `platformio.ini` para o seu hardware.
3. Conecte a ESP32 e use **PlatformIO: Upload**.
4. O firmware escuta comandos pela USB/serial em **115200 baud**, terminados por `\n`.

## Protocolo serial usado pela IA

| Comando | Expressão/ação |
|---|---|
| `NEUTRO` / `INTERACAO` / `PING` | acorda e volta ao estado neutro/atento |
| `FELIZ` | feliz |
| `TRISTE` | triste |
| `BRAVO` / `RAIVA` | bravo |
| `APAIXONADO` | olhos de coração |
| `ERRO` | olhos em X |
| `SUSTO` | animação breve de surpresa |
| `SONOLENTO` / `DORMINDO` | estados de inatividade |

O firmware mantém piscadas, olhar, animações, sonolência e transições localmente.
A página web envia apenas a expressão escolhida pela IA; `piscada` é feita
automaticamente pelo firmware e não é enviada como comando.

## Conexão com a página do BiteByte

Abra o ChefBot em Chrome ou Edge em `localhost` ou em uma origem HTTPS, clique
em **Conectar ESP32** e escolha a porta serial da placa. A página usa Web Serial
API; mantenha a porta livre de outros monitores seriais enquanto estiver conectada.
