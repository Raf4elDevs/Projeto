#include <SPI.h>
#include <TFT_eSPI.h>

/* =====================================================================
 *  ROBÔ - SISTEMA DE EXPRESSÕES (ESP32)
 *
 *  Atualizado para integração total com o Cérebro em Python (Voz/Texto).
 *  Comandos pela serial (terminam com \n):
 *    NEUTRO, FELIZ, TRISTE, BRAVO, APAIXONADO, ERRO  -> emoções
 *    NAO_ENTENDI / DIRETRIZES                        -> expressão de erro
 *    INTERACAO / PING / ACORDAR                      -> zera temporizador / acorda
 *    DORMINDO, SONOLENTO, SUSTO                      -> controle de estado
 *
 * ===================================================================== */

// ======================== CONFIGURAÇÃO ===============================
#define SPRITE_DEPTH 8        // 8 = ~56 KB de RAM.

const uint32_t FRAME_MS = 33;                 // ~30 FPS
const uint32_t T_SONOLENTO_MS = 270000UL;     // 4:30 min
const uint32_t T_DORMIR_MS    = 300000UL;     // 5:00 min

// TEMPOS DE ALTERNÂNCIA (em milissegundos)
const uint32_t T_NEUTRO_MIN_MS     = 3500;
const uint32_t T_NEUTRO_MAX_MS     = 8500;
const uint32_t T_MEIO_FELIZ_MIN_MS = 1200;
const uint32_t T_MEIO_FELIZ_MAX_MS = 2800;

// Geometria (tela 480x320, rotação 1)
const int SPR_W = 200, SPR_H = 280, SPR_Y = 20;   
const int OLHO_ESQ_X = 140, OLHO_DIR_X = 340;     
const int OLHO_CY = 160;                          

// Cores
const uint16_t COR_OLHO    = TFT_CYAN;
const uint16_t COR_CORACAO = 0xF9F2;              // rosa
const uint16_t COR_ERRO    = TFT_RED;

// ======================== TIPOS ======================================
enum RobotState : uint8_t {
  DORMINDO, ACORDANDO, NEUTRO, FELIZ, TRISTE, BRAVO,
  APAIXONADO, ERRO, SONOLENTO, SUSTO, CHACOALHANDO
};

enum EyeKind : uint8_t { K_CAPSULA, K_ARCO_CIMA, K_ARCO_BAIXO, K_CORACAO, K_X };

struct Pose {
  EyeKind kind;
  float w, h;     // cápsula: largura/altura | arco: raios rx/ry | coração/X: w = tamanho
  float lid;      // 0..1  pálpebra de cima cobrindo o olho
  float tilt;     // px    inclinação da pálpebra (+ triste: "/ \", - bravo: "\ /")
  float cheek;    // 0..1  "bochecha" que corta embaixo (meio feliz)
  float open;     // 0..1  abertura
};

// ======================== VARIÁVEIS GLOBAIS ==========================
TFT_eSPI    tft = TFT_eSPI();
TFT_eSprite spr = TFT_eSprite(&tft);

Pose cur, want;
RobotState currentState = DORMINDO;
RobotState pending      = NEUTRO;     

uint32_t stateStart      = 0;         
uint32_t lastInteraction = 0;
uint32_t lastFrame       = 0;
uint32_t gNow            = 0;

// Olhar e Alternância de Expressão
float lookX = 0, lookY = 0, tLookX = 0, tLookY = 0, lookTau = 90;
uint8_t  lookIdx  = 0;
uint32_t lookTimer = 0;
bool     meioFeliz = false;
uint32_t trocouExpressaoTimer = 0;

// Piscar
bool     blinking = false;
uint32_t blinkStart = 0, blinkDur = 160, blinkTimer = 0;
float    blinkOpen = 1.0f;

// Corpo / cabeça
float bobY = 0, tiltHead = 0, shakeX = 0, breath = 1.0f;
float faceTau = 110;

// Efeitos
float zAlpha = 0, exclAlpha = 0;

// Sonolento (cabeceio)
bool     nodando = false;
uint32_t nodStart = 0, nodTimer = 0;

bool wakeBlink = false;

char     rxBuf[96];
uint8_t rxLen = 0;

// ======================== HELPERS ====================================
static inline float suave(float c, float t, float dt, float tau) {
  return c + (t - c) * (1.0f - expf(-dt / tau));   
}
static inline float smoothstep01(float x) {
  x = constrain(x, 0.0f, 1.0f);
  return x * x * (3.0f - 2.0f * x);
}
uint16_t escurecer(uint16_t c, float a) {           
  a = constrain(a, 0.0f, 1.0f);
  uint8_t r = ((c >> 11) & 31) * a, g = ((c >> 5) & 63) * a, b = (c & 31) * a;
  return (r << 11) | (g << 5) | b;
}
bool ehEmocao(RobotState s) {
  return s == FELIZ || s == TRISTE || s == BRAVO || s == APAIXONADO || s == ERRO;
}

// ======================== POSES (dados) ==============================
Pose basePose(RobotState s) {
  switch (s) {
    case DORMINDO:     return {K_ARCO_BAIXO, 46, 26, 0.00f,   0, 0, 1}; // U
    case FELIZ:        return {K_ARCO_CIMA,  46, 40, 0.00f,   0, 0, 1}; // ∩
    case TRISTE:       return {K_CAPSULA,    76, 100, 0.06f,  36, 0, 1}; // /  \ 
    case BRAVO:        return {K_CAPSULA,    76, 100, 0.06f, -36, 0, 1}; // \  /
    case APAIXONADO:   return {K_CORACAO,    38, 0,  0.00f,   0, 0, 1};
    case ERRO:         return {K_X,          36, 0,  0.00f,   0, 0, 1}; 
    case SONOLENTO:    return {K_CAPSULA,    80, 100, 0.45f,  0, 0, 1};
    case ACORDANDO:    return {K_CAPSULA,    80, 100, 0.75f,  0, 0, 1};
    case SUSTO:        return {K_CAPSULA,    94, 132, 0.00f,  0, 0, 1};
    case CHACOALHANDO: return {K_CAPSULA,    80, 110, 0.00f,  0, 0, 0}; 
    default:           return {K_CAPSULA,    80, 110, 0.00f,  0, 0, 1}; // NEUTRO
  }
}

// ======================== DESENHO (dentro do sprite) =================
void drawOlhoCapsula(int cx, int cy, const Pose& p, float open, bool esq) {
  float W = p.w;
  float H = fmaxf(p.h * open, 10.0f);              
  int w = (int)W, h = (int)H;
  int x = cx - w / 2, y = cy - h / 2;
  int r = (int)fminf(W * 0.44f, H / 2);

  spr.fillRoundRect(x, y, w, h, r, COR_OLHO);
  if (h <= 12) return;

  // brilhos
  float s  = W / 80.0f;
  float hk = constrain((H - 36.0f) / 40.0f, 0.0f, 1.0f);
  int r1 = (int)(11 * s * hk), r2 = (int)(5 * s * hk);
  if (r1 >= 2) spr.fillCircle(cx + (int)(W * 0.175f), cy - (int)(H * 0.25f), r1, TFT_WHITE);
  if (r2 >= 1) spr.fillCircle(cx + (int)(W * 0.275f), cy - (int)(H * 0.13f), r2, TFT_WHITE);

  // pálpebra de cima
  int yTop = y;
  float lidPx = p.lid * H;
  if (lidPx > 0.5f) {
    spr.fillRect(x - 2, y - 2, w + 4, (int)lidPx + 2, TFT_BLACK);
    yTop = y + (int)lidPx;
  }

  // inclinação: TRISTE (tilt > 0) -> / \ | BRAVO (tilt < 0) -> \ /
  if (fabsf(p.tilt) > 0.5f) {
    int t = (int)(fabsf(p.tilt) * fminf(open, 1.0f));
    bool corteTopLeft = (p.tilt > 0.5f && esq) || (p.tilt < -0.5f && !esq);
    if (corteTopLeft) spr.fillTriangle(x - 2, yTop - 2, x + w + 2, yTop - 2, x - 2, yTop + t, TFT_BLACK);
    else             spr.fillTriangle(x - 2, yTop - 2, x + w + 2, yTop - 2, x + w + 2, yTop + t, TFT_BLACK);
  }

  // bochecha (meio feliz)
  if (p.cheek > 0.02f) {
    float R    = 48.0f * s;
    float bite = 35.0f * (H / 110.0f) * p.cheek;
    spr.fillCircle(cx, y + h + (int)(R - bite), (int)R, TFT_BLACK);
  }
}

void drawOlhoArco(int cx, int cy, const Pose& p, float open, bool cima) {
  const int t = 11;                                
  int rx = (int)p.w, ry = (int)(p.h * open);

  if (ry <= t) {                                   
    spr.fillRoundRect(cx - rx, cy - t / 2, 2 * rx, t, t / 2, COR_OLHO);
    return;
  }
  int cyc = cima ? cy + ry / 2 : cy - ry / 2;      

  spr.fillEllipse(cx, cyc, rx, ry, COR_OLHO);
  spr.fillEllipse(cx, cyc, rx - t, ry - t, TFT_BLACK);
  if (cima) spr.fillRect(cx - rx - 2, cyc + 1, 2 * rx + 4, ry + 3, TFT_BLACK);
  else      spr.fillRect(cx - rx - 2, cyc - ry - 3, 2 * rx + 4, ry + 2, TFT_BLACK);
  spr.fillCircle(cx - (rx - t / 2), cyc, t / 2, COR_OLHO);   
  spr.fillCircle(cx + (rx - t / 2), cyc, t / 2, COR_OLHO);
}

void drawCoracao(int cx, int cy, float size, uint16_t cor) {
  int sz = (int)size;
  if (sz < 3) return;
  cy -= sz / 8;                                    
  int r = sz / 2;
  spr.fillCircle(cx - r, cy - sz / 4, r, cor);
  spr.fillCircle(cx + r, cy - sz / 4, r, cor);
  spr.fillTriangle(cx - sz, cy - sz / 4, cx + sz, cy - sz / 4, cx, cy + sz, cor);
  if (sz > 14) spr.fillCircle(cx - (int)(r * 0.75f), cy - (int)(sz * 0.42f), max(2, sz / 8), TFT_WHITE);
}

void drawX(int cx, int cy, float size, uint16_t cor) {
  int L = (int)size;
  if (L < 3) return;
  int t = max(2, L / 9);
  for (int i = -t; i <= t; i++) {
    spr.drawLine(cx - L + i, cy - L, cx + L + i, cy + L, cor);
    spr.drawLine(cx + L + i, cy - L, cx - L + i, cy + L, cor);
  }
  spr.fillCircle(cx - L, cy - L, t + 1, cor);
  spr.fillCircle(cx + L, cy + L, t + 1, cor);
  spr.fillCircle(cx + L, cy - L, t + 1, cor);
  spr.fillCircle(cx - L, cy + L, t + 1, cor);
}

void drawZ(int x, int y, int s, uint16_t cor) {
  int t = max(2, s / 5);
  spr.fillRoundRect(x, y, s, t, t / 2, cor);
  spr.fillRoundRect(x, y + s - t, s, t, t / 2, cor);
  for (int i = -t / 2; i <= t / 2; i++)
    spr.drawLine(x + s - t / 2 + i, y + t / 2, x + t / 2 + i, y + s - t / 2, cor);
}

void drawZzz() {                                   
  if (zAlpha < 0.03f) return;
  for (int i = 0; i < 3; i++) {
    float ph = fmodf(gNow / 3600.0f + i / 3.0f, 1.0f);
    float a  = sinf(PI * ph) * zAlpha;
    if (a < 0.05f) continue;
    int s = 10 + (int)(ph * 16);
    drawZ(108 + (int)(ph * 38), 62 - (int)(ph * 54), s, escurecer(COR_OLHO, a));
  }
}

void drawExclamacao() {                            
  if (exclAlpha < 0.05f) return;
  uint16_t c = escurecer(COR_OLHO, exclAlpha);
  spr.fillRoundRect(146, 6, 10, 32, 5, c);
  spr.fillCircle(151, 50, 5, c);
}

void renderEye(bool esq) {
  spr.fillSprite(TFT_BLACK);

  float ox = lookX + shakeX;
  float oy = lookY + bobY + (esq ? tiltHead : -tiltHead);   
  int cx = SPR_W / 2 + (int)roundf(ox);
  int cy = OLHO_CY + (int)roundf(oy);
  float open = constrain(cur.open * blinkOpen * breath, 0.0f, 1.0f);

  switch (cur.kind) {
    case K_CAPSULA:    drawOlhoCapsula(cx, cy, cur, open, esq); break;
    case K_ARCO_CIMA:  drawOlhoArco(cx, cy, cur, open, true);   break;
    case K_ARCO_BAIXO: drawOlhoArco(cx, cy, cur, open, false);  break;
    case K_CORACAO: {
      float v = 0.5f - 0.5f * cosf(2.0f * PI * (gNow % 800) / 800.0f);
      drawCoracao(cx, cy, cur.w * open * (1.0f + 0.32f * v * v), COR_CORACAO);
      break;
    }
    case K_X: {
      float v = 0.5f - 0.5f * cosf(2.0f * PI * (gNow % 700) / 700.0f);
      drawX(cx, cy, cur.w * open * (1.0f + 0.22f * v), COR_ERRO);
      break;
    }
  }
  if (!esq) { drawZzz(); drawExclamacao(); }

  spr.pushSprite((esq ? OLHO_ESQ_X : OLHO_DIR_X) - SPR_W / 2, SPR_Y);
}

void renderFace() {
  renderEye(true);
  renderEye(false);
}

// ======================== ANIMAÇÕES ==================================
const int8_t SEQ_OLHAR[9][2] = {
  {0, 0}, {0, -1}, {0, 0}, {0, 1}, {0, 0}, {-1, 0}, {0, 0}, {1, 0}, {0, 0}
};  

void updateMeioFeliz(uint32_t now) {
  if (now >= trocouExpressaoTimer) {
    if (meioFeliz) {
      meioFeliz = false; 
      trocouExpressaoTimer = now + random(T_NEUTRO_MIN_MS, T_NEUTRO_MAX_MS + 1);
    } else {
      meioFeliz = true;  
      trocouExpressaoTimer = now + random(T_MEIO_FELIZ_MIN_MS, T_MEIO_FELIZ_MAX_MS + 1);
    }
  }
}

void animateLooking(uint32_t now) {
  if (now < lookTimer) return;
  lookIdx = (lookIdx + 1) % 9;
  int gx = SEQ_OLHAR[lookIdx][0], gy = SEQ_OLHAR[lookIdx][1];

  if (gx == 0 && gy == 0) {                         
    tLookX = random(-2, 3);
    tLookY = random(-2, 3);
    lookTimer = now + random(700, 1900);
    lookTau = random(80, 130);
  } else {
    float k = random(75, 110) / 100.0f;             
    tLookX = gx * 30 * k + random(-3, 4);
    tLookY = gy * 18 * k + random(-2, 3);
    lookTimer = now + random(800, 1700);
    lookTau = random(60, 110);
  }
}

void startBlink(uint32_t now, uint32_t dur) {
  blinking = true; blinkStart = now; blinkDur = dur;
}

void scheduleBlink(uint32_t now, bool lento) {
  if (!lento && random(100) < 18) blinkTimer = now + random(120, 260);   
  else blinkTimer = now + (lento ? random(1800, 4200) : random(2200, 5600));
}

void animateBlink(uint32_t now, float dt, bool automatico, bool lento) {
  if (blinking) {
    float t = (now - blinkStart) / (float)blinkDur;
    if (t >= 1.0f) { blinking = false; blinkOpen = 1.0f; scheduleBlink(now, lento); }
    else blinkOpen = 1.0f - 0.94f * sinf(PI * t);   
  } else {
    blinkOpen = suave(blinkOpen, 1.0f, dt, 40);
    if (automatico && now >= blinkTimer) startBlink(now, lento ? random(380, 560) : random(130, 190));
  }
}

float pulo(uint32_t t) {                            
  if (t < 260) return -22.0f * sinf(PI * t / 260.0f);
  if (t < 440) return -8.0f * sinf(PI * (t - 260) / 180.0f);
  return 0.0f;
}

void updateAnimations(uint32_t now, float dt) {
  uint32_t t = now - stateStart;
  want = basePose(currentState);

  float tBob = 0, tTilt = 0, tZ = 0;
  bool bobDireto = false, tiltDireto = false;
  float bobDir = 0, tiltDir = 0;
  bool autoBlink = false, lento = false;
  breath = 1.0f; shakeX = 0; exclAlpha = 0; faceTau = 110; lookTau = 140;

  switch (currentState) {
    case NEUTRO:
      updateMeioFeliz(now);                         
      want.cheek = meioFeliz ? 1.0f : 0.0f;
      animateLooking(now);                          
      autoBlink = true;
      break;

    case FELIZ:
      tLookX = tLookY = 0;
      tBob = -5.0f * fabsf(sinf(now / 280.0f));     
      break;

    case TRISTE:
      tLookX = 6.0f * sinf(now / 1000.0f); tLookY = 0;
      tBob = 9; lookTau = 200;                      
      break;

    case BRAVO:
      tLookX = tLookY = 0;
      shakeX = 2.0f * sinf(now / 40.0f);             // tremor de irritação
      break;

    case APAIXONADO:
      tLookX = tLookY = 0;
      tBob = -2.0f * sinf(now / 420.0f);
      break;

    case ERRO:
      tLookX = tLookY = 0;
      break;

    case DORMINDO:
      tLookX = tLookY = 0;
      tBob = 2.0f * sinf(now / 1100.0f);
      breath = 0.95f + 0.05f * sinf(now / 900.0f);  
      tZ = 1; faceTau = 160;
      break;

    case SONOLENTO: {
      tLookX = 7.0f * sinf(now / 2100.0f); tLookY = 0;
      lookTau = 300; faceTau = 160; lento = true; autoBlink = true;

      float depth = 0;                              
      if (!nodando && now >= nodTimer) { nodando = true; nodStart = now; }
      if (nodando) {
        float u = (now - nodStart) / 1500.0f;
        if (u >= 1.0f) { nodando = false; nodTimer = now + random(3500, 7000); }
        else depth = (u < 0.7f) ? smoothstep01(u / 0.7f)
                   : (u < 0.8f) ? 1.0f : 1.0f - smoothstep01((u - 0.8f) / 0.2f);
      }
      want.lid = 0.38f + 0.12f * sinf(now / 1500.0f) + 0.45f * depth;
      tBob = 14.0f * depth;
      tTilt = 7.0f * depth;

      float prog = ((float)(now - lastInteraction) - T_SONOLENTO_MS) / (float)(T_DORMIR_MS - T_SONOLENTO_MS);
      prog = constrain(prog, 0.0f, 1.0f);
      tZ = (sinf(now / 2500.0f) > -0.3f) ? prog : 0.0f;
      break;
    }

    case ACORDANDO:                                 
      tLookX = tLookY = 0; tZ = 0; faceTau = 130;
      if (t >= 500 && t < 1000) { want.lid = 0.35f; tBob = -6; }
      else if (t >= 1000)       { want.lid = 0.0f; }
      if (t >= 850 && !wakeBlink) { wakeBlink = true; startBlink(now, 230); }
      break;

    case SUSTO:                                     
      tLookX = tLookY = 0;
      bobDireto = true; bobDir = pulo(t);
      shakeX = (t < 650) ? 3.0f * sinf(t * 0.09f) : 0;
      if (t > 50 && t < 800) exclAlpha = sinf(PI * (t - 50) / 750.0f);
      if (t >= 650) want = basePose(NEUTRO);        
      if (t < 300) faceTau = 45;                    
      break;

    case CHACOALHANDO: {                            
      tLookX = tLookY = 0;
      if (t > 300) {
        float u = t - 300.0f;
        float env = (u < 450) ? 1.0f : fmaxf(0.0f, 1.0f - (u - 450.0f) / 250.0f);
        shakeX = 13.0f * sinf(u * 0.052f) * env;
        tiltDireto = true; tiltDir = 4.0f * cosf(u * 0.052f) * env;
      }
      break;
    }
  }

  animateBlink(now, dt, autoBlink, lento);
  lookX    = suave(lookX, tLookX, dt, lookTau);
  lookY    = suave(lookY, tLookY, dt, lookTau);
  bobY     = bobDireto  ? bobDir  : suave(bobY, tBob, dt, 70);
  tiltHead = tiltDireto ? tiltDir : suave(tiltHead, tTilt, dt, 80);
  zAlpha   = suave(zAlpha, tZ, dt, 350);
}

void updateFace(float dt) {
  if (cur.kind != want.kind) {
    cur.open = suave(cur.open, 0.0f, dt, 55);
    if (cur.open < 0.14f) { float o = cur.open; cur = want; cur.open = o; }
  } else {
    cur.w     = suave(cur.w,     want.w,     dt, faceTau);
    cur.h     = suave(cur.h,     want.h,     dt, faceTau);
    cur.lid   = suave(cur.lid,   want.lid,   dt, faceTau);
    cur.tilt  = suave(cur.tilt,  want.tilt,  dt, faceTau);
    cur.cheek = suave(cur.cheek, want.cheek, dt, faceTau);
    cur.open  = suave(cur.open,  want.open,  dt, want.open > cur.open ? 90.0f : 60.0f);
  }
}

// ======================== MÁQUINA DE ESTADOS =========================
void enterState(RobotState s) {
  uint32_t now = millis();
  currentState = s;
  stateStart = now;

  if (s == NEUTRO) {
    lookIdx = 0; tLookX = tLookY = 0;
    lookTimer = now + random(900, 1600);
    meioFeliz = false;                              
    trocouExpressaoTimer = now + random(T_NEUTRO_MIN_MS, T_NEUTRO_MAX_MS);
    if (!blinking) blinkTimer = now + random(1200, 3000);
  } else if (s == SONOLENTO) {
    nodando = false; nodTimer = now + random(2500, 5000);
    if (!blinking) blinkTimer = now + random(1000, 2500);
  } else if (s == ACORDANDO) {
    wakeBlink = false;
  }
}

void finalizarDespertar() {
  RobotState p = pending;
  pending = NEUTRO;
  enterState(p);                                    
}

void updateState(uint32_t now) {
  uint32_t t = now - stateStart;
  switch (currentState) {
    case NEUTRO:
      if (now - lastInteraction >= T_SONOLENTO_MS) enterState(SONOLENTO);
      break;
    case SONOLENTO:
      if (now - lastInteraction >= T_DORMIR_MS) enterState(DORMINDO);
      break;
    case FELIZ:
    case TRISTE:
    case BRAVO:
    case APAIXONADO:
    case ERRO:
      // Permanece até o Python enviar NEUTRO após a fala do robô
      break;
    case CHACOALHANDO:
      if (t >= 1050) enterState(NEUTRO);
      break;
    case ACORDANDO:
      if (t >= 1400) finalizarDespertar();
      break;
    case SUSTO:
      if (t >= 1000) finalizarDespertar();
      break;
    default: break;
  }
}

void tratarRequisicao(RobotState req) {
  uint32_t now = millis();

  if (req == DORMINDO)  { enterState(DORMINDO); return; }
  if (req == SONOLENTO) { lastInteraction = now - T_SONOLENTO_MS; enterState(SONOLENTO); return; }

  lastInteraction = now;                            
  if (req == SUSTO) { enterState(SUSTO); return; }

  RobotState p = ehEmocao(req) ? req : NEUTRO;      
  switch (currentState) {
    case DORMINDO:   pending = p; enterState(ACORDANDO); break;   
    case SONOLENTO:  pending = p; enterState(SUSTO);     break;   
    case ACORDANDO:
    case SUSTO:      if (p != NEUTRO) pending = p; break;         
    default:
      if (p != NEUTRO) enterState(p);                             
      else if (currentState != NEUTRO) enterState(NEUTRO);
      break;
  }
}

// ======================== COMANDOS SERIAIS ============================
void processarComando(const char* c) {
  if        (!strcasecmp(c, "NEUTRO") || !strcasecmp(c, "INTERACAO") || !strcasecmp(c, "PING") ||
             !strcasecmp(c, "ACORDAR") || !strcasecmp(c, "ACORDANDO")) tratarRequisicao(NEUTRO);
  else if (!strcasecmp(c, "FELIZ"))       tratarRequisicao(FELIZ);
  else if (!strcasecmp(c, "TRISTE"))      tratarRequisicao(TRISTE);
  else if (!strcasecmp(c, "BRAVO") || !strcasecmp(c, "RAIVA")) tratarRequisicao(BRAVO);
  else if (!strcasecmp(c, "APAIXONADO"))  tratarRequisicao(APAIXONADO);
  else if (!strcasecmp(c, "ERRO") ||
             !strcasecmp(c, "ERRO_SISTEMA") ||
             !strcasecmp(c, "NAO_ENTENDI") ||
             !strcasecmp(c, "NAO ENTENDI") ||
             !strcasecmp(c, "DIRETRIZES") ||
             !strcasecmp(c, "FORA_DAS_DIRETRIZES")) tratarRequisicao(ERRO);
  else if (!strcasecmp(c, "DORMINDO"))    tratarRequisicao(DORMINDO);
  else if (!strcasecmp(c, "SONOLENTO"))   tratarRequisicao(SONOLENTO);
  else if (!strcasecmp(c, "SUSTO"))       tratarRequisicao(SUSTO);
}

void lerSerial() {
  while (Serial.available() > 0) {
    char ch = Serial.read();
    if (ch == '\n' || ch == '\r') {
      if (rxLen > 0) { rxBuf[rxLen] = 0; processarComando(rxBuf); rxLen = 0; }
    } else if (rxLen < sizeof(rxBuf) - 1) {
      rxBuf[rxLen++] = ch;
    }
  }
}

// ======================== SETUP / LOOP ===============================
void setup() {
  Serial.begin(115200);
  randomSeed(analogRead(0));

  tft.init();
  tft.setRotation(1);                               
  tft.fillScreen(TFT_BLACK);                        

  spr.setColorDepth(SPRITE_DEPTH);
  if (!spr.createSprite(SPR_W, SPR_H)) {
    Serial.println(F("ERRO: sem memoria para o sprite"));
    while (true) delay(1000);
  }

  cur = basePose(DORMINDO);
  cur.open = 0.0f;
  want = cur;
  lastInteraction = millis();
  enterState(DORMINDO);
  lastFrame = millis();
}

void loop() {
  lerSerial();

  uint32_t now = millis();
  if (now - lastFrame < FRAME_MS) return;
  float dt = fminf((float)(now - lastFrame), 100.0f);
  lastFrame = now;
  gNow = now;

  updateState(now);            
  updateAnimations(now, dt);   
  updateFace(dt);              
  renderFace();                
}