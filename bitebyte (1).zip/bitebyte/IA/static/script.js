// ======================================================
// CHEFBOT - script da página de conversa
// ------------------------------------------------------
// - Histórico guardado em sessionStorage: permite rolar
//   a conversa e sobrevive a recarregar a página, mas é
//   apagado quando a aba/site é fechado.
// - Botão "Voltar ao site" usa o endereço enviado pelo
//   front-end (?voltar=...).
// ======================================================

const CHAVE_HISTORICO = "chefbotHistorico:";
const CHAVE_VOLTAR = "chefbotVoltar";
const CHAVE_LOGADO = "chefbotUsuarioLogado";
const SITE_PADRAO = "http://localhost:3000/html/index.html";

const MENSAGEM_BOAS_VINDAS =
    "Olá! Eu sou o **Chef IA** do BiteByte 🍳\n\n" +
    "Me diga o que você tem na geladeira ou o que quer cozinhar, " +
    "e eu te ajudo com receitas e dicas.";

let historico = [];


// ======================================================
// UTILITÁRIOS
// ======================================================

function emailAtual() {
    return document.getElementById("email").value.trim().toLowerCase();
}


function rolarParaFim() {
    const chat = document.getElementById("chat");
    chat.scrollTop = chat.scrollHeight;
}


function urlHttpValida(url) {
    try {
        const u = new URL(url);
        return u.protocol === "http:" || u.protocol === "https:";
    } catch (e) {
        return false;
    }
}


// ======================================================
// HISTÓRICO (sessionStorage)
// ======================================================

function carregarHistorico() {
    try {
        const salvo = sessionStorage.getItem(
            CHAVE_HISTORICO + emailAtual()
        );
        historico = salvo ? JSON.parse(salvo) : [];
    } catch (e) {
        historico = [];
    }
}


function salvarHistorico() {
    try {
        sessionStorage.setItem(
            CHAVE_HISTORICO + emailAtual(),
            JSON.stringify(historico)
        );
    } catch (e) {
        console.error("Não foi possível salvar o histórico:", e);
    }
}


// ======================================================
// RENDERIZAÇÃO
// ======================================================

function criarMensagemUsuario(texto) {
    const div = document.createElement("div");
    div.className = "user-message";
    div.textContent = texto;
    return div;
}


function criarMensagemBot(markdown) {
    const div = document.createElement("div");
    div.className = "bot-message";
    div.innerHTML =
        "<strong>ChefBot:</strong> " +
        (markdown ? marked.parse(markdown) : "");
    return div;
}


function renderizarHistorico() {
    const chat = document.getElementById("chat");
    chat.innerHTML = "";

    chat.appendChild(criarMensagemBot(MENSAGEM_BOAS_VINDAS));

    for (const msg of historico) {
        chat.appendChild(
            msg.role === "user"
                ? criarMensagemUsuario(msg.text)
                : criarMensagemBot(msg.text)
        );
    }

    // rola direto para a última mensagem (sem animação)
    chat.style.scrollBehavior = "auto";
    rolarParaFim();
    chat.style.scrollBehavior = "";
}


// ======================================================
// INICIALIZAÇÃO
// ======================================================

document.addEventListener("DOMContentLoaded", function () {

    const params = new URLSearchParams(window.location.search);


    // ---------- EMAIL ----------
    const emailInput = document.getElementById("email");

    const emailSalvo =
        params.get("email") ||
        localStorage.getItem("emailUsuario");

    if (emailSalvo) {
        emailInput.value = emailSalvo;
    }


    // ---------- NÍVEL ----------
    const nivelURL = params.get("nivel");
    const nivelSelect = document.getElementById("nivel");

    if (
        nivelURL &&
        nivelSelect.querySelector('option[value="' + nivelURL + '"]')
    ) {
        nivelSelect.value = nivelURL;
    }


    // ---------- VOLTAR AO SITE ----------
    let destino = params.get("voltar");

    if (destino && urlHttpValida(destino)) {
        sessionStorage.setItem(CHAVE_VOLTAR, destino);
    } else {
        destino = sessionStorage.getItem(CHAVE_VOLTAR);
    }

    if (!destino || !urlHttpValida(destino)) {
        destino = SITE_PADRAO;
    }

    // páginas do site (mesma pasta /html/ da página de onde o usuário veio)
    const paginaSite = (arquivo) => new URL(arquivo, destino).href;

    // botão "Voltar ao site" (opcional: só existe se estiver no HTML)
    const btnVoltar = document.getElementById("voltar-site");
    if (btnVoltar) btnVoltar.href = destino;

    // logo -> index.html, igual ao resto do site
    document.getElementById("logo-home").addEventListener(
        "click",
        function () {
            window.location.href = paginaSite("index.html");
        }
    );


    // ---------- BOTÃO DO HEADER (Entrar/Cadastrar -> Perfil) ----------
    // O site (porta 3000) e a IA (porta 5000) são origens diferentes, então a IA
    // não enxerga o localStorage do site. O login chega pela URL (?email=...),
    // enviada pelo openChefBot() do front-end, e fica guardado nesta aba.
    let usuarioLogado = params.get("email");

    if (usuarioLogado) {
        sessionStorage.setItem(CHAVE_LOGADO, usuarioLogado);
    } else if (params.has("voltar")) {
        // veio do site sem email = deslogado lá
        sessionStorage.removeItem(CHAVE_LOGADO);
    } else {
        usuarioLogado = sessionStorage.getItem(CHAVE_LOGADO);
    }

    const authLink = document.getElementById("authLink");

    if (authLink) {
        if (usuarioLogado) {
            const nome = usuarioLogado.split("@")[0];
            authLink.href = paginaSite("perfil.html");
            authLink.innerHTML = '<i class="fas fa-user"></i> ';
            authLink.appendChild(document.createTextNode("Olá, " + nome));
        } else {
            authLink.href = paginaSite("cadastro.html");
        }
    }


    // ---------- HISTÓRICO ----------
    carregarHistorico();
    renderizarHistorico();

    // se trocar o email, mostra a conversa daquele usuário
    emailInput.addEventListener("change", function () {
        carregarHistorico();
        renderizarHistorico();
    });


    // ---------- ENTER ----------
    document.getElementById("mensagem").addEventListener(
        "keypress",
        function (event) {
            if (event.key === "Enter") {
                event.preventDefault();
                enviar();
            }
        }
    );

});


// ======================================================
// ENVIAR MENSAGEM
// ======================================================

async function enviar() {

    let inputMensagem = document.getElementById("mensagem");
    let nivelSelect = document.getElementById("nivel");
    let emailInput = document.getElementById("email");

    let mensagem = inputMensagem.value.trim();
    let nivel = nivelSelect.value;
    let email = emailInput.value.trim();


    // ---------- VALIDAR EMAIL ----------
    if (email === "") {
        alert("Digite o email do usuário antes de enviar.");
        emailInput.focus();
        return;
    }


    // ---------- VALIDAR MENSAGEM ----------
    if (mensagem === "") {
        return;
    }


    // ---------- SALVAR EMAIL ----------
    localStorage.setItem("emailUsuario", email);


    let chat = document.getElementById("chat");


    // ---------- MENSAGEM DO USUÁRIO ----------
    chat.appendChild(criarMensagemUsuario(mensagem));

    historico.push({ role: "user", text: mensagem });
    salvarHistorico();

    inputMensagem.value = "";


    // ---------- RESPOSTA DO CHEFBOT ----------
    let respostaDiv = criarMensagemBot("");
    chat.appendChild(respostaDiv);
    rolarParaFim();

    let textoFinal = "";
    let textoErro = "";


    try {

        // ---------- ENVIAR PARA FLASK ----------
        let response = await fetch("/chat", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                email: email,
                mensagem: mensagem,
                nivel: nivel
            })

        });


        if (!response.ok) {
            throw new Error("Erro HTTP: " + response.status);
        }


        // ---------- STREAM ----------
        const reader = response.body.getReader();
        const decoder = new TextDecoder("utf-8");

        let buffer = "";

        while (true) {

            const { done, value } = await reader.read();

            if (done) {
                break;
            }

            buffer += decoder.decode(value, { stream: true });


            // separar eventos SSE
            let linhas = buffer.split("\n\n");
            buffer = linhas.pop();


            for (let linha of linhas) {

                linha = linha.trim();

                if (!linha.startsWith("data: ")) {
                    continue;
                }

                try {

                    let dados = JSON.parse(linha.substring(6));


                    // erro do Flask
                    if (dados.error) {

                        textoErro = "❌ " + dados.error;

                        respostaDiv.innerHTML =
                            "<strong>ChefBot:</strong> " + textoErro;

                        continue;

                    }


                    // token
                    if (dados.token) {

                        textoFinal += dados.token;

                        respostaDiv.innerHTML =
                            "<strong>ChefBot:</strong> " +
                            marked.parse(textoFinal);

                        rolarParaFim();

                    }

                }
                catch (erroJSON) {

                    console.error(
                        "Erro ao interpretar JSON:",
                        erroJSON
                    );

                }

            }

        }

    }
    catch (erro) {

        textoErro = "❌ Erro ao conectar com a IA.";

        respostaDiv.innerHTML =
            "<strong>ChefBot:</strong> " + textoErro;

        console.error("Erro:", erro);

    }


    // ---------- GUARDAR RESPOSTA NO HISTÓRICO ----------
    const textoParaSalvar = textoFinal || textoErro;

    if (textoParaSalvar) {
        historico.push({ role: "bot", text: textoParaSalvar });
        salvarHistorico();
    }

}
