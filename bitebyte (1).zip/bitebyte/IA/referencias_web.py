import json
import re
from html.parser import HTMLParser
from urllib.parse import parse_qs, quote_plus, unquote, urlparse

import requests

# Fonte estruturada principal. A API oficial do TheMealDB oferece busca por nome,
# filtro por ingrediente e consulta detalhada de receitas.
THEMEALDB_BASE = "https://www.themealdb.com/api/json/v1/1"
THEMEALDB_FONTE = "TheMealDB"

# Fontes culinárias usadas somente como fallback para descoberta de referências.
# O sistema não depende de uma única página.
FONTES_WEB = {
    "www.tudogostoso.com.br": "TudoGostoso",
    "receitasnestle.com.br": "Receitas Nestlé",
    "www.receitasnestle.com.br": "Receitas Nestlé",
    "www.panelinha.com.br": "Panelinha",
    "www.receiteria.com.br": "Receiteria",
    "www.cybercook.com.br": "CyberCook",
    "www.allrecipes.com": "Allrecipes",
}

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/153.0 Safari/537.36"
)

# Traduções úteis para o filtro de ingrediente da API.
INGREDIENTES_PT_EN = {
    "frango": "chicken",
    "peito de frango": "chicken_breast",
    "carne": "beef",
    "carne bovina": "beef",
    "carne moida": "beef",
    "carne moída": "beef",
    "porco": "pork",
    "bacon": "bacon",
    "peixe": "fish",
    "salmao": "salmon",
    "salmão": "salmon",
    "camarao": "shrimp",
    "camarão": "shrimp",
    "ovo": "egg",
    "ovos": "egg",
    "queijo": "cheese",
    "leite": "milk",
    "manteiga": "butter",
    "arroz": "rice",
    "batata": "potatoes",
    "tomate": "tomato",
    "cebola": "onion",
    "alho": "garlic",
    "cogumelo": "mushrooms",
    "cogumelos": "mushrooms",
    "massa": "pasta",
    "macarrao": "pasta",
    "macarrão": "pasta",
    "chocolate": "chocolate",
    "morango": "strawberries",
    "banana": "banana",
    "maca": "apple",
    "maçã": "apple",
    "limao": "lemon",
    "limão": "lemon",
    "coco": "coconut",
    "chantilly": "cream",
}


class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self._href = None
        self._text = []
        self._attrs = {}

    def handle_starttag(self, tag, attrs):
        if tag != "a":
            return
        attrs_dict = dict(attrs)
        href = attrs_dict.get("href")
        if href:
            self._href = href
            self._text = []
            self._attrs = attrs_dict

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag != "a" or self._href is None:
            return
        texto = re.sub(r"\s+", " ", " ".join(self._text)).strip()
        self.links.append((self._href, texto, self._attrs))
        self._href = None
        self._text = []
        self._attrs = {}


class MetaParser(HTMLParser):
    """Lê apenas metadados/JSON-LD de uma página.

    Para receitas, quando a fonte possui JSON-LD Recipe, aproveitamos os campos
    estruturados em vez de copiar o HTML inteiro.
    """

    def __init__(self):
        super().__init__()
        self.title = ""
        self.description = ""
        self._inside_title = False
        self._title_parts = []
        self._inside_jsonld = False
        self._jsonld_parts = []
        self._jsonld_blocks = []

    def handle_starttag(self, tag, attrs):
        attrs_dict = dict(attrs)
        if tag == "title":
            self._inside_title = True
        elif tag == "meta":
            nome = (attrs_dict.get("name") or attrs_dict.get("property") or "").lower()
            if nome in {"description", "og:description"} and not self.description:
                self.description = (attrs_dict.get("content") or "").strip()
        elif tag == "script":
            tipo = (attrs_dict.get("type") or "").lower()
            if "application/ld+json" in tipo:
                self._inside_jsonld = True
                self._jsonld_parts = []

    def handle_data(self, data):
        if self._inside_title:
            self._title_parts.append(data)
        if self._inside_jsonld:
            self._jsonld_parts.append(data)

    def handle_endtag(self, tag):
        if tag == "title":
            self._inside_title = False
            self.title = re.sub(r"\s+", " ", " ".join(self._title_parts)).strip()
        elif tag == "script" and self._inside_jsonld:
            self._inside_jsonld = False
            bruto = "\n".join(self._jsonld_parts).strip()
            if bruto:
                try:
                    self._jsonld_blocks.append(json.loads(bruto))
                except json.JSONDecodeError:
                    pass

    def jsonld_blocks(self):
        return self._jsonld_blocks


def _headers():
    return {
        "User-Agent": USER_AGENT,
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.7",
        "Accept": "text/html,application/json;q=0.9,*/*;q=0.8",
    }


def _normalizar_host(host):
    host = (host or "").lower().split(":", 1)[0]
    return host[4:] if host.startswith("www.") else host


def _fonte_por_url(url):
    host = _normalizar_host(urlparse(url).netloc)
    for permitido, fonte in FONTES_WEB.items():
        if _normalizar_host(permitido) == host:
            return fonte
    return ""


def _url_web_permitida(url):
    try:
        host = _normalizar_host(urlparse(url).netloc)
        return host in {_normalizar_host(x) for x in FONTES_WEB}
    except Exception:
        return False


def _desembrulhar_url_busca(href):
    """Converte links de resultados de Bing/DDG para a URL final."""
    href = unquote(href or "")
    if href.startswith("//"):
        href = "https:" + href

    parsed = urlparse(href)
    query = parse_qs(parsed.query)

    for chave in ("uddg", "url", "target"):
        valores = query.get(chave)
        if valores:
            candidato = unquote(valores[0])
            if candidato.startswith("http"):
                return candidato

    # Alguns resultados do Bing carregam o destino codificado em `u=`.
    if parsed.netloc.endswith("bing.com") and query.get("u"):
        candidato = unquote(query["u"][0])
        if candidato.startswith("http"):
            # Nem todo formato do Bing é direto; só aceitamos se já resultar
            # em um host de fonte culinária.
            return candidato

    return href


def _extrair_links_busca(html, limite=30):
    parser = LinkParser()
    parser.feed(html)

    resultados = []
    vistos = set()

    for href, texto, attrs in parser.links:
        url = _desembrulhar_url_busca(href)
        if not _url_web_permitida(url):
            continue

        host = _normalizar_host(urlparse(url).netloc)
        if not host:
            continue

        url = url.split("#", 1)[0]
        if "?" in url:
            url = url.split("?", 1)[0]

        chave = url.rstrip("/").lower()
        if chave in vistos:
            continue
        vistos.add(chave)

        titulo = texto.strip()
        if not titulo:
            titulo = urlparse(url).path.strip("/").split("/")[-1].replace("-", " ")

        resultados.append({
            "url": url,
            "titulo_busca": titulo,
            "titulo": titulo,
            "fonte": FONTES_WEB.get(urlparse(url).netloc.lower(), _fonte_por_url(url) or "Fonte culinária"),
            "tipo": "web",
        })

        if len(resultados) >= limite:
            break

    return resultados


def _buscar_em_duckduckgo(consulta, limite=20):
    url = "https://html.duckduckgo.com/html/?q=" + quote_plus(consulta)
    try:
        resposta = requests.get(url, headers=_headers(), timeout=15)
        if resposta.status_code != 200:
            return []
        return _extrair_links_busca(resposta.text, limite=limite)
    except requests.RequestException:
        return []


def _buscar_em_bing(consulta, limite=20):
    url = "https://www.bing.com/search?q=" + quote_plus(consulta)
    try:
        resposta = requests.get(url, headers=_headers(), timeout=15)
        if resposta.status_code != 200:
            return []
        return _extrair_links_busca(resposta.text, limite=limite)
    except requests.RequestException:
        return []


def _themealdb_get(caminho, params=None):
    try:
        resposta = requests.get(
            f"{THEMEALDB_BASE}/{caminho}",
            params=params or {},
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
            timeout=12,
        )
        resposta.raise_for_status()
        dados = resposta.json()
        return dados if isinstance(dados, dict) else {}
    except (requests.RequestException, ValueError):
        return {}


def _mapear_themealdb_resumo(item):
    meal_id = str(item.get("idMeal", "")).strip()
    nome = str(item.get("strMeal", "")).strip()
    return {
        "id": meal_id,
        "titulo": nome,
        "titulo_busca": nome,
        "descricao": "",
        "ingredientes": [],
        "instrucoes": [],
        "tempo_preparo": "",
        "rendimento": "",
        "categoria": item.get("strCategory") or "",
        "area": item.get("strArea") or "",
        "url": f"https://www.themealdb.com/api/json/v1/1/lookup.php?i={meal_id}" if meal_id else "https://www.themealdb.com/",
        "fonte": THEMEALDB_FONTE,
        "tipo": "themealdb",
    }


def _buscar_themealdb_por_nome(consulta, limite=20):
    dados = _themealdb_get("search.php", {"s": consulta})
    meals = dados.get("meals") or []
    return [_mapear_themealdb_resumo(item) for item in meals[:limite]]


def _buscar_themealdb_por_ingrediente(ingrediente, limite=20):
    dados = _themealdb_get("filter.php", {"i": ingrediente})
    meals = dados.get("meals") or []
    return [_mapear_themealdb_resumo(item) for item in meals[:limite]]


def _ingredientes_detectados(consulta):
    texto = str(consulta or "").lower()
    encontrados = []
    for pt, en in sorted(INGREDIENTES_PT_EN.items(), key=lambda x: len(x[0]), reverse=True):
        if re.search(rf"(?<!\w){re.escape(pt.lower())}(?!\w)", texto):
            if en not in encontrados:
                encontrados.append(en)
    return encontrados


def _detalhar_themealdb(item):
    meal_id = str(item.get("id") or "").strip()
    if not meal_id:
        return item

    dados = _themealdb_get("lookup.php", {"i": meal_id})
    meals = dados.get("meals") or []
    if not meals:
        return item

    receita = meals[0]
    ingredientes = []
    for n in range(1, 21):
        nome = str(receita.get(f"strIngredient{n}") or "").strip()
        medida = str(receita.get(f"strMeasure{n}") or "").strip()
        if nome:
            ingredientes.append(f"{medida} {nome}".strip())

    instrucoes = str(receita.get("strInstructions") or "").strip()
    passos = [
        parte.strip()
        for parte in re.split(r"\r?\n+", instrucoes)
        if parte.strip()
    ]

    source = str(receita.get("strSource") or "").strip()
    return {
        **item,
        "titulo": str(receita.get("strMeal") or item.get("titulo") or "").strip(),
        "descricao": f"Categoria: {receita.get('strCategory') or 'não informada'} | Área: {receita.get('strArea') or 'não informada'}",
        "ingredientes": ingredientes,
        "instrucoes": passos,
        "categoria": receita.get("strCategory") or "",
        "area": receita.get("strArea") or "",
        "source_url": source,
        "video_url": str(receita.get("strYoutube") or "").strip(),
        "url": source or item.get("url") or f"https://www.themealdb.com/meal.php?c={meal_id}",
        "fonte": THEMEALDB_FONTE,
        "tipo": "themealdb",
    }


def _normalizar_jsonld(obj):
    if isinstance(obj, list):
        saida = []
        for item in obj:
            saida.extend(_normalizar_jsonld(item))
        return saida
    if isinstance(obj, dict):
        if isinstance(obj.get("@graph"), list):
            return _normalizar_jsonld(obj["@graph"])
        return [obj]
    return []


def _recipe_jsonld(parser):
    receitas = []
    for bloco in parser.jsonld_blocks():
        for item in _normalizar_jsonld(bloco):
            tipos = item.get("@type")
            tipos = tipos if isinstance(tipos, list) else [tipos]
            if "Recipe" in tipos:
                receitas.append(item)
    return receitas


def _detalhar_web(item):
    url = item.get("url", "")
    if not _url_web_permitida(url):
        return item

    try:
        resposta = requests.get(url, headers=_headers(), timeout=15)
        resposta.raise_for_status()

        parser = MetaParser()
        parser.feed(resposta.text)
        receitas = _recipe_jsonld(parser)
        receita = receitas[0] if receitas else {}

        ingredientes = receita.get("recipeIngredient") or []
        instrucoes_raw = receita.get("recipeInstructions") or []
        if isinstance(instrucoes_raw, str):
            instrucoes = [instrucoes_raw.strip()] if instrucoes_raw.strip() else []
        else:
            instrucoes = []
            for passo in instrucoes_raw:
                if isinstance(passo, dict):
                    texto = str(passo.get("text") or "").strip()
                else:
                    texto = str(passo).strip()
                if texto:
                    instrucoes.append(texto)

        titulo = str(receita.get("name") or parser.title or item.get("titulo") or "").strip()
        descricao = str(receita.get("description") or parser.description or "").strip()

        return {
            **item,
            "titulo": titulo,
            "descricao": descricao,
            "ingredientes": [str(x).strip() for x in ingredientes if str(x).strip()],
            "instrucoes": instrucoes,
            "tempo_preparo": str(receita.get("totalTime") or receita.get("cookTime") or receita.get("prepTime") or ""),
            "rendimento": str(receita.get("recipeYield") or ""),
        }
    except (requests.RequestException, ValueError, TypeError):
        return item


def _deduplicar(referencias, limite):
    saida = []
    vistos = set()

    for item in referencias:
        titulo = str(item.get("titulo") or item.get("titulo_busca") or "").strip()
        url = str(item.get("url") or "").strip()
        chave = (re.sub(r"\W+", " ", titulo.lower()).strip(), url.lower())
        if not titulo and not url:
            continue
        if chave in vistos:
            continue
        vistos.add(chave)
        saida.append(item)
        if len(saida) >= limite:
            break

    return saida


def buscar_referencias_culinarias(consulta, limite=20, detalhar=False, somente_receitas=False):
    """Busca referências culinárias em uma fonte estruturada + fallback web.

    A prioridade é o TheMealDB, que possui API oficial para desenvolvimento/uso
    educacional. Depois usamos resultados de fontes culinárias conhecidas para
    ampliar a cobertura de termos e receitas que não existirem na base principal.
    """
    consulta = str(consulta or "").strip()
    if not consulta:
        return []

    resultados = []

    # 1) Fonte estruturada principal.
    resultados.extend(_buscar_themealdb_por_nome(consulta, limite=limite))

    # 2) Filtro por ingrediente, quando conseguimos identificar um ingrediente.
    for ingrediente in _ingredientes_detectados(consulta)[:3]:
        if len(resultados) >= limite * 2:
            break
        resultados.extend(_buscar_themealdb_por_ingrediente(ingrediente, limite=limite))

    # 3) Fallback para fontes culinárias na web.
    termos_busca = [
        f"receita {consulta} culinária",
        f"como preparar {consulta} receita",
        f"{consulta} receita culinária",
    ]
    if somente_receitas:
        termos_busca = [f"receita {consulta}"]

    for termo in termos_busca:
        if len(resultados) >= limite * 2:
            break

        resultados.extend(_buscar_em_duckduckgo(termo, limite=max(10, limite)))
        if len(resultados) < limite * 2:
            resultados.extend(_buscar_em_bing(termo, limite=max(10, limite)))

    resultados = _deduplicar(resultados, max(limite * 2, limite))

    if detalhar:
        detalhados = []
        for item in resultados:
            if item.get("tipo") == "themealdb":
                detalhados.append(_detalhar_themealdb(item))
            else:
                detalhados.append(_detalhar_web(item))
        resultados = detalhados

    return resultados[:limite]


def buscar_referencia_receita(nome_receita, limite=8):
    referencias = buscar_referencias_culinarias(
        nome_receita,
        limite=limite,
        detalhar=True,
        somente_receitas=True,
    )

    alvo = re.sub(r"\s+", " ", str(nome_receita or "").strip().lower())
    exatos = []
    aproximados = []

    for item in referencias:
        titulo = re.sub(r"\s+", " ", str(item.get("titulo") or "").strip().lower())
        if not titulo:
            continue
        if titulo == alvo:
            exatos.append(item)
        elif alvo in titulo or titulo in alvo:
            aproximados.append(item)

    return (exatos or aproximados or referencias)[:limite]


def detalhar_referencia(referencia):
    if not referencia:
        return referencia
    if referencia.get("tipo") == "themealdb":
        return _detalhar_themealdb(referencia)
    return _detalhar_web(referencia)


def resumir_referencias_para_modelo(referencias, limite=20):
    linhas = []
    for i, item in enumerate(referencias[:limite], 1):
        titulo = item.get("titulo") or item.get("titulo_busca") or "Referência sem título"
        descricao = str(item.get("descricao") or "").strip()
        fonte = item.get("fonte") or "Fonte culinária"
        url = item.get("url") or ""
        linhas.append(
            f"[{i}] {titulo}\n"
            f"Fonte: {fonte}\n"
            f"URL: {url}\n"
            f"Descrição: {descricao[:700]}"
        )
    return "\n\n".join(linhas)
