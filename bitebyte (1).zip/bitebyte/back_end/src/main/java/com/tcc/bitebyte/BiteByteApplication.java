package com.tcc.bitebyte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiteByteApplication {

    public static void main(String[] args) {
        SpringApplication.run(BiteByteApplication.class, args);
    }

}
