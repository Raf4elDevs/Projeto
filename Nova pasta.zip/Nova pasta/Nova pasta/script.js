// Configurações do Carrossel
let currentSlide = 0;
const slides = document.querySelectorAll('.carousel-slide');

function showSlide(index) {
    if (slides.length === 0) return;
    slides.forEach(s => s.classList.remove('active'));
    
    if (index >= slides.length) currentSlide = 0;
    else if (index < 0) currentSlide = slides.length - 1;
    else currentSlide = index;
    
    slides[currentSlide].classList.add('active');
}

function moveSlide(step) {
    showSlide(currentSlide + step);
}

// Troca automática do carrossel a cada 5 segundos
if (slides.length > 0) {
    setInterval(() => moveSlide(1), 5000);
}

// Chatbot IA
function toggleChat() {
    const chat = document.getElementById('ai-chat-window');
    chat.classList.toggle('chat-hidden');
}

// Lógica de Busca e Filtro de Receitas
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('recipe-search');
    const searchBtn = document.getElementById('search-btn');
    const recipes = document.querySelectorAll('.recipe-card');

    function filterRecipes() {
        const query = searchInput.value.toLowerCase().trim();

        recipes.forEach(recipe => {
            const title = recipe.querySelector('h4').innerText.toLowerCase();
            const category = recipe.querySelector('.category').innerText.toLowerCase();

            if (title.includes(query) || category.includes(query)) {
                recipe.style.display = 'block';
                recipe.style.animation = 'fadeIn 0.5s';
            } else {
                recipe.style.display = 'none';
            }
        });
    }

    if (searchBtn) searchBtn.addEventListener('click', filterRecipes);
    if (searchInput) {
        searchInput.addEventListener('input', filterRecipes);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') filterRecipes();
        });
    }
});

// Escuta de cliques globais para navegação via atributo onclick
document.addEventListener('click', (e) => {
    const target = e.target.closest('[onclick]');
    if (target) {
        const attr = target.getAttribute('onclick');
        if (attr && attr.includes('window.location.href')) {
            const url = attr.match(/'([^']+)'/)[1];
            window.location.href = url;
        }
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const recipes = document.querySelectorAll('.recipe-card');

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove a classe 'active' de todos os botões e adiciona no clicado
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            const filterValue = button.textContent.toLowerCase();

            recipes.forEach(recipe => {
                // Pega os tipos definidos no data-type do HTML
                const recipeTypes = recipe.getAttribute('data-type') || "";
                
                if (filterValue === 'todas') {
                    recipe.style.display = 'block';
                } 
                // Verifica se o texto do botão está contido no data-type ou na categoria
                else if (recipeTypes.includes(filterValue) || 
                         recipe.querySelector('.category').textContent.toLowerCase().includes(filterValue)) {
                    recipe.style.display = 'block';
                    recipe.style.animation = 'fadeIn 0.5s';
                } 
                else {
                    recipe.style.display = 'none';
                }
            });
        });
    });
});